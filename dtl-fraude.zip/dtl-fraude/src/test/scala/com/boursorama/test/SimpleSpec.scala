package com.boursorama.test

import com.boursorama.utils.AppConf
import org.scalatest.concurrent.Eventually
import org.scalatest._

/**
 * Created by ubuntu on 02/06/16.
 */
trait SimpleSpec extends FlatSpec with GivenWhenThen with BeforeAndAfterEach with BeforeAndAfterAll with Eventually with ShouldMatchers {

}
