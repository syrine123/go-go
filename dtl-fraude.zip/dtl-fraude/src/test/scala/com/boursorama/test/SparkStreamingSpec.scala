package com.boursorama.test

import java.text.SimpleDateFormat

import com.boursorama.utils.AppConf
import com.datastax.driver.core.Cluster
import org.apache.spark.streaming.{Seconds, StreamingContext}
import org.apache.spark.{SparkConf, SparkContext}

/**
 * Created by ubuntu on 02/06/16.
 */
trait SparkStreamingSpec extends SimpleSpec {

  private var _ssc: StreamingContext = _
  private var _sc: SparkContext = _
  private val appName = this.getClass.getSimpleName + System.currentTimeMillis()
  private val master = "local[2]"
  private val batchWindow = Seconds(1)
  def ssc = _ssc
  def sc = _sc

  def sparkConf(appName: String, master: String) : SparkConf = {
    new SparkConf()
      .setAppName(appName)
      .setMaster(master)
      .set("spark.cassandra.connection.host", AppConf.CassandraNodes)
  }

  override def beforeEach {
    _sc = new SparkContext(sparkConf(appName, master))
    _ssc = new StreamingContext(_sc, batchWindow)
  }

  override def afterEach {
    if(_ssc != null) {
      _ssc.stop()
    }
  }
}
