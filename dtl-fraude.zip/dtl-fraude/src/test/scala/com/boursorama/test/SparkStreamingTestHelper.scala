package com.boursorama.test

import org.apache.spark.rdd.RDD
import org.apache.spark.streaming.StreamingContext
import org.apache.spark.streaming.dstream.DStream

import scala.collection.mutable
import scala.reflect.ClassTag

/**
 * Created by ubuntu on 09/06/16.
 */
class SparkStreamingTestHelper[T: ClassTag] {

  var lines: mutable.Queue[RDD[T]] = _

  def initInputStream(ssc: StreamingContext): DStream[T] = {
    println(">> getActionInputStream")

    lines = mutable.Queue[RDD[T]]()
    val dStream = ssc.queueStream(lines)
    println("<< getActionInputStream")
    dStream
  }

  def pushToStream(ssc: StreamingContext, dataList: List[T]): Unit = {
    val sc = ssc.sparkContext
    lines.synchronized {
      lines += sc.makeRDD(dataList)
    }
  }
}
