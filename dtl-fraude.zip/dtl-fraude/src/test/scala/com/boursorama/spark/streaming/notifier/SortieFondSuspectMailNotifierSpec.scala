package com.boursorama.spark.streaming.notifier

import com.boursorama.dtl.business.SortieFondSuspect
import com.boursorama.test.SimpleSpec
import com.boursorama.utils.Conversion._
import com.boursorama.utils.Constants._

class SortieFondSuspectMailNotifierSpec extends SimpleSpec {
/*
  val sortieFondSuspect: SortieFondSuspect = SortieFondSuspect(
                                "CIS",
                                201604,
                                20160430,
                                getDateTime(2016,4,30,19,37,30),
                                "W01K02570878784",
                                68656476,
                                "80.12.59.179",
                                30.0,
                                "-",
                                "OTRANSFR",
                                "40618",
                                "20000",
                                "00040327669",
                                "978",
                                "406182000000040327669978",
                                "40618-80263-00040695894-978",
                                "CN",
                                None,
                                0.0,
                                TYPE_FRAUDE_EXT_PAYS_SUSPECT,
                                Map("listePaysARisque" -> "HR,MC,LT,RO,CH,LI,BG,EE,CZ,CY"),
                                0
  )

  "La méthode ActionInterneSuspectNotifier.process" should "envoyer un mail" in {
    
    Given("Une action interne suspecte")

    val suspectNotifier = SortieFondSuspectMailNotifierMock

    suspectNotifier.clearMails()

    When("On apelle la méthode process")
    suspectNotifier.notifySuspect(sortieFondSuspect)

    Then("Doit retourner 1 mail")
    suspectNotifier.getMails should have size (1)

    Then("Le mail doit être conforme au modèle")
    suspectNotifier.getMails should contain (
       "{\"smtpHost\": \"10.4.1.12:25\"," +
         " \"sender\": \"admin.cognos@boursorama.fr\"," +
         " \"to\": \"DTL-Risque@boursorama.fr\"," +
         " \"subject\": \""  + SortieFondSuspectMailNotifier.formatMailSubject(sortieFondSuspect) + "\"," +
         " \"body\": \"" + SortieFondSuspectMailNotifier.formatMailBody(sortieFondSuspect) + "\"" +
         "}"
    )

  }
  */
}

