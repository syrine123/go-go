package com.boursorama.spark.streaming.detector

import com.boursorama.spark.persistance.cassandra.CassandraHelper
import com.boursorama.utils.Constants.SUSPECT_CONNECTION_COUNTRIES

object SortieFondPaysSuspectDetectorMock extends SortieFondPaysSuspectDetector {
/*
  val codePaysSuspects = List("NR", "IR", "CU", "BW", "MH", "SS", "TN", "GT", "BN", "UA", "LY", "SY", "NU", "SD", "PA", "TR")

  override def getFraudeParamsFromDb: List[String] = {
    val codePaysSuspects = CassandraHelper.getAllPaysSuspects
      codePaysSuspects match {
        case None => SUSPECT_CONNECTION_COUNTRIES
        case Some(codes) => codes
      }
  }

  override def getFraudeParams() : List[String] = {
    if (lastRefrech + refreshDelaySec * 1000 < System.currentTimeMillis()) {
        cachedParamsMap = getFraudeParamsFromDb
        lastRefrech = System.currentTimeMillis()
      }
      cachedParamsMap
    }
    */
 }
