package com.boursorama.spark.streaming.detector

import com.boursorama.dtl.business.{SortieFondSuspect, SortieFond}

object SortieFondSuspectDetectorMock extends SortieFondSuspectDetector {
/*
  override val suspect1: (SortieFond) => Option[SortieFondSuspect] = SortieFondCavalerieDetectorMock.suspect
  override val suspect2: (SortieFond) => Option[SortieFondSuspect] = SortieFondPaysSuspectDetectorMock.suspect
  */
}
