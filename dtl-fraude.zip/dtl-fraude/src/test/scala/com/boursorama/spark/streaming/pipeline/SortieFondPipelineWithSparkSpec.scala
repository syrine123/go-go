package com.boursorama.spark.streaming.pipeline

import com.boursorama.cassandra.{CassandraClientSpec, CassandraInitTablespace}
import com.boursorama.dtl.business.{Client, SortieFondSuspect}
import com.boursorama.spark.streaming.notifier.SortieFondSuspectMailNotifier
import com.boursorama.test.SimpleSpec
import com.boursorama.utils.AppConf._
import com.boursorama.utils.Constants._
import com.boursorama.utils.Conversion._
import org.apache.spark.SparkConf
import org.apache.spark.streaming.{Seconds, StreamingContext}
import org.scalatest.GivenWhenThen


class SortieFondPipelineWithSparkSpec extends CassandraClientSpec with GivenWhenThen {
/*
  val sortieFondSuspect1 = SortieFondSuspect (
                              "CIS",
                              201604,
                              20160430,
                              getDateTime(2016, 4, 30, 19, 37, 30, ParisTimeZone),
                              "W01K02570878784",
                              32354028,
                              "80.12.59.179",
                              2000.0,
                              "-",
                              "OTRANSFR",
                              "40618",
                              "20000",
                              "00040327669",
                              "978",
                              "406182000000040327669978",
                              "40618-80263-00040695894-978",
                              "CH",
                              Some(Client(32354028,32354028, Some(getDateTime(2016,1,4,10,25,15)), 1500.5, 500.0, 5)),
                              -999.5,
                              TYPE_FRAUDE_EXT_PAYS_SUSPECT,
                              Map("listePaysARisque" -> "HR,MC,LT,RO,CH,LI,BG,EE,CZ,CY"),
                              0
                            )

  val sortieFondSuspect2 = SortieFondSuspect (
                            "CIS",
                            201604,
                            20160430,
                            getDateTime(2016, 4, 30, 19, 37, 30, ParisTimeZone),
                            "W01K02570878787",
                            68656476,
                            "80.12.59.179",
                            10000.0,
                            "-",
                            "OTRANSFR",
                            "40618",
                            "20000",
                            "00040327669",
                            "978",
                            "406182000000040327669978",
                            "40618-80263-00040695894-978",
                            "FR",
                            Some(Client(68656476,68656476, Some(getDateTime(2016,1,4,10,25,15)), 1500.5, 5000.0, 2)),
                            -13499.5,
                            TYPE_FRAUDE_EXT_CAVALERIE,
                            Map(
                              "seuilSoldeCumulMoinsEgalQue" -> "-5000",
                              "seuilCumulRmcPlusEgalQue" -> "1000",
                              "seuilMontantPlusEgalQue" -> "1000",
                              "seuilAncienneteMoinsEgalQue" -> "730"
                            ),
                            0
                          )

  val sortieFondSuspect3 = SortieFondSuspect (
                            "CIS",
                            201604,
                            20160430,
                            getDateTime(2016, 4, 30, 19, 37, 30, ParisTimeZone),
                            "W01K02570878788",
                            68656476,
                            "80.12.59.179",
                            12550.0,
                            "-",
                            "OTRANSFR",
                            "40618",
                            "20000",
                            "00040327669",
                            "978",
                            "406182000000040327669978",
                            "40618-80263-00040695894-978",
                            "CH",
                            Some(Client(68656476,68656476, Some(getDateTime(2016,1,4,10,25,15)), 1500.5, 5000.0, 2)),
                            -16049.5,
                            TYPE_FRAUDE_EXT_CAVALERIE,
                            Map(
                              "seuilSoldeCumulMoinsEgalQue" -> "-5000",
                              "seuilCumulRmcPlusEgalQue" -> "1000",
                              "seuilMontantPlusEgalQue" -> "1000",
                              "seuilAncienneteMoinsEgalQue" -> "730"
                            ),
                            0
                          )

  val sortieFondSuspect4 = SortieFondSuspect(
                            "CIS",
                            201604,
                            20160430,
                            getDateTime(2016, 4, 30, 19, 37, 30, ParisTimeZone),
                            "W01K02570878788",
                            68656476,
                            "80.12.59.179",
                            12550.0,
                            "-",
                            "OTRANSFR",
                            "40618",
                            "20000",
                            "00040327669",
                            "978",
                            "406182000000040327669978",
                            "40618-80263-00040695894-978",
                            "CH",
                            Some(Client(68656476, 68656476, Some(getDateTime(2016, 1, 4, 10, 25, 15)), 1500.5, 5000.0, 2)),
                            -16049.5,
                            TYPE_FRAUDE_EXT_PAYS_SUSPECT,
                            Map("listePaysARisque" -> "HR,MC,LT,RO,CH,LI,BG,EE,CZ,CY"),
                            0
                          )


  def getSparkConf() : SparkConf = {

    new SparkConf()
      .setMaster("local[2]")
      .setAppName("test-pipeline")
      .set("spark.cassandra.connection.host", CassandraNodes)
      .set("spark.streaming.concurrentJobs", "5")
  }

   "Le pipeline ActionInternePipeline" should "trangit pull" +
     "sforme les donnes de log en ActionInterne correctement" in {
     Given("Une implementation du ActionInternePipelineMock fournissant des lignes de log")

     val pipeline = SortieFondPipelineMockAll

     val logLines = pipeline.getJsonSamplesSet

     pipeline.clearSortieFondList()

     When("On lance spark streaming par la methode process et tempo de 5sec")

     val sparkConf = getSparkConf()
     val ssc = new StreamingContext(sparkConf, Seconds(1))
     //ssc.checkpoint("/tmp/spark-checkpoint")

     pipeline.process(ssc, 5000)

     //ssc.scheduler.clock.asInstanceOf[ManualClock]

     Then("Une liste de 5 sortiee fond est retournée")
     pipeline.getSortieFondList should have size (5)

     When("On applique la detection des actions suspectes")

     Then("Une liste de 4 sorties de fond suspectes est retournée")
     pipeline.getSuspectList should have size (4)

     Then("Une sortie fond pays suspect est retournée")
     pipeline.getSuspectList should contain allOf ( sortieFondSuspect1, sortieFondSuspect2, sortieFondSuspect3, sortieFondSuspect4 )

     Then("4 notifications de sortie de fond suspectes devrées être envoyées par mail")
     pipeline.getMails should have size (4)

     Then("Des notifications de sortie de fond suspectes devrées être envoyées par mail")
     pipeline.getMails should contain (
       "{\"smtpHost\": \"10.4.1.12:25\"," +
       " \"sender\": \"admin.cognos@boursorama.fr\"," +
       " \"to\": \"DTL-Risque@boursorama.fr\"," +
       " \"subject\": \""  + SortieFondSuspectMailNotifier.formatMailSubject(sortieFondSuspect1) + "\"," +
       " \"body\": \"" + SortieFondSuspectMailNotifier.formatMailBody(sortieFondSuspect1) + "\"" +
       "}"
     )

    ssc.stop()
   }
   */
 }

