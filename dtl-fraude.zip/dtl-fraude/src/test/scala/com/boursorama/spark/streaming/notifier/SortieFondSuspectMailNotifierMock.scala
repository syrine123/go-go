package com.boursorama.spark.streaming.notifier

import com.boursorama.dtl.business.SortieFondSuspect

import scala.collection.mutable
import scala.collection.mutable.ArrayBuffer

object SortieFondSuspectMailNotifierMock extends SortieFondSuspectMailNotifier {

  val mails = new ArrayBuffer[String] with mutable.SynchronizedBuffer[String]

  override def notifySuspect(sortieFondSuspect: SortieFondSuspect): Unit = {
    //mails += sendMail(sortieFondSuspect, true)
  }

  def clearMails() = {
    mails.clear()
  }

  def getMails : List[String] = {
    mails.toList
  }
 }

