package com.boursorama.spark.streaming.pipeline

import com.boursorama.dtl.business.{Client, SortieFond, SortieFondSuspect}
import com.boursorama.spark.streaming.detector.{SortieFondSuspectDetector, SortieFondSuspectDetectorMock}
import com.boursorama.spark.streaming.parser.ActionExterneCisParser
import com.boursorama.utils.AppConf
import com.boursorama.utils.Conversion._
import org.apache.spark.rdd.RDD
import org.apache.spark.streaming.StreamingContext
import org.apache.spark.streaming.dstream.DStream

import scala.collection.mutable
import scala.collection.mutable.ArrayBuffer

object SortieFondPipelineMockAll extends SortieFondPipelineMockKafka {

  val sortieFondList = new ArrayBuffer[SortieFond] with mutable.SynchronizedBuffer[SortieFond]

  override def getTopicSet: Set[String] = Set(AppConf.KafkaTopicCis)

  override def getCheckpointDir: String = AppConf.SparkCisCheckpointDirectory

  override def getAppName(): String = "sp-strm-sortie-fond-cis-mockall"

  override def getGroupId : String = "dtl-fraude"

  override def process(ssc: StreamingContext, timeout: Long): Unit = {

    val logDStream: DStream[String] = getInputStream(ssc)

    val sortieFondDStream: DStream[SortieFond] = parseToSortieFond(logDStream)

    processSortieFond(sortieFondDStream)
  }

  override def parseToSortieFond: String => Option[SortieFond] = ActionExterneCisParser.parseLine

  override val suspectDetector: SortieFondSuspectDetector = SortieFondSuspectDetectorMock

  override def detectSortieFondSuspect(sortieFond: SortieFond) : List[SortieFondSuspect] = {
    println(s"-- detectSortieFondSuspect $sortieFond")
    val listSuspect = super.detectSortieFondSuspect(sortieFond)
    listSuspect.foreach( suspect => println(s"  -- detected : $suspect") )
    listSuspect
  }

  override def persisteSortieFond(sortieFondDStream: DStream[SortieFond]): Unit = {
    sortieFondDStream.foreachRDD(rdd => storeSortieFond(rdd))
  }

  def clearSortieFondList() = {
    sortieFondList.clear()
  }

  def storeSortieFond(rdd: RDD[SortieFond]): Unit = {
    rdd.foreach(action => {
        sortieFondList += action
        println(">>>>> storeSortieFond " + action.toString)
    } )
  }

  def getSortieFondList: List[SortieFond] = {
    sortieFondList.toList
  }

  override def persisteSortieFondSuspect(sortieFondSuspectDStream: DStream[SortieFondSuspect]): Unit = {
    sortieFondSuspectDStream.foreachRDD(rdd => storeSuspect(rdd))
  }

  val suspectList = new ArrayBuffer[SortieFondSuspect] with mutable.SynchronizedBuffer[SortieFondSuspect]

  def storeSuspect(rdd: RDD[SortieFondSuspect]): Unit = {
    rdd.foreach( action => {
        suspectList += action
        println(">>>>> storeSortieFondSuspect " + action.toString)
    } )
  }

  def getSuspectList: List[SortieFondSuspect] = {
    suspectList.toList
  }

  override def getClientInformation(idWeb: Long): Option[Client] = {

    println("-- getUserInformation (id_web=" + idWeb + ")")
    if (68656476l.equals(idWeb)) {
      Some(
        Client(
          68656476,
          68656476,
          Some(getDateTime(2016, 1, 4, 10, 25, 15)),
          1500.50,
          5000.0,
          2
        )
      )
    } else if (32354028l.equals(idWeb)) {
      Some(
        Client(
          32354028,
          32354028,
          Some(getDateTime(2016, 1, 4, 10, 25, 15)),
          1500.50,
          500.0,
          5
        )
      )
    } else {
      Some(
        Client(
          idWeb,
          idWeb,
          Some(getDateTime(2013, 1, 4, 10, 25, 15)),
          -10000.0,
          5000.0,
          1
        )
      )
    }
  }

}

