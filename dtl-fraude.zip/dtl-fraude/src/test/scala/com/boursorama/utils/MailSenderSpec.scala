package com.boursorama.utils

import javax.mail.internet.InternetAddress

import com.boursorama.test.SimpleSpec
import org.scalatest._

class MailSenderSpec extends SimpleSpec {
/*
  val SenderAuditMail = "admin.cognos@boursorama.fr"
  val recipientAuditMail = "jacky.robert@boursorama.fr;marc.lamberti@boursorama.fr;fares.oueslati@boursorama.fr;francois.goumard@boursorama.fr;RedhaNabil.BELKHOUS@boursorama.fr;Sabrine.LAZRAK@boursorama.fr;"
  val RecipientSortieFondMail = recipientAuditMail.split(";").map(new InternetAddress(_))
  "A MailSender" should "send mail" in {
    Given("the sender, recipient, subject and body")

    When("MailSender.send is called")

    val message = MailSender.send(SenderAuditMail, RecipientSortieFondMail, "MailSender test subject", "MailSender test body", true)

    Then("message is OK")
    message should be( "{\"smtpHost\": \"10.4.1.12:25\", \"sender\": \"admin.cognos@boursorama.fr\", \"to\": \"marc.lamberti@boursorama.fr\", \"subject\": \"MailSender test subject\", \"body\": \"MailSender test body\"}" )
  }*/
}
