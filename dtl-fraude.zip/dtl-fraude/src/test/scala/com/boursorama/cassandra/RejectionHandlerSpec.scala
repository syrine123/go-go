package com.boursorama.cassandra

import com.boursorama.dtl.business.{Client, FraudeParams}
import com.boursorama.test.SimpleSpec
import com.boursorama.utils.Constants._
import com.boursorama.utils.Conversion._
import org.scalatest.GivenWhenThen

class RejectionHandlerSpec extends SimpleSpec with GivenWhenThen {
/*
  override def beforeAll = {
    CassandraInitTablespace.initAll()
  }

  override def afterAll = {

  }

  "L'object RejectionHandler" should "ecrire les rejection dans la table des rejections" in {

    Given("L'object RejectionHandler")

    val rejectionHandler = RejectionHandler

    When("On appelle handleRejection")

    rejectionHandler.handleRejection("TEST-SYS", 1, "Test stackTrace", "TESTUSER", "logline|testfield1|testfield2|testfield3|testfield4")

    Then("L'ecriture devraie être effectuée")

    true should be (true)
    //CassandraClient.getRejectionData() should be (
    //  "logline..."
    //)
  }
  */
}
