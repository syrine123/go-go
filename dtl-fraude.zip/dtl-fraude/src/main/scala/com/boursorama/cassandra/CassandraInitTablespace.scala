package com.boursorama.cassandra

import com.boursorama.utils.AppConf._
import com.boursorama.utils.Constants._
import com.datastax.driver.core.policies.{ExponentialReconnectionPolicy, DefaultRetryPolicy}
import com.datastax.driver.core.{SocketOptions, ConsistencyLevel, QueryOptions, Cluster}

/**
 * Created by ubuntu on 02/06/16.
 */
object CassandraInitTablespace  extends Serializable {

  private val nodes = CassandraNodes.split(",").map(_.trim())
  private val cluster = Cluster.builder()
                          .addContactPoints(nodes.toArray: _*)
                          .withRetryPolicy(DefaultRetryPolicy.INSTANCE)
                          .withReconnectionPolicy(new ExponentialReconnectionPolicy(100, 60000))
                          .build()

  private val session = cluster.connect()

  def initAll(): Unit = {
    initKeyspaces()
    initTables()
    initData()
  }

  def initKeyspaces(): Unit = {

    // DROP


    session.execute(s"DROP KEYSPACE IF EXISTS $CassandraReferentielKeySpace;")
    println(s"Dropped from Cassandra KeySpace $CassandraReferentielKeySpace")

    session.execute(s"DROP KEYSPACE IF EXISTS $CassandraExternalRiskKeySpace;")
    println(s"Dropped from Cassandra KeySpace $CassandraExternalRiskKeySpace")

    session.execute(s"DROP KEYSPACE IF EXISTS $CassandraInternalRiskKeySpace;")
    println(s"Dropped from Cassandra KeySpace $CassandraInternalRiskKeySpace")

    session.execute(s"DROP KEYSPACE IF EXISTS $CassandraAuditDtlKeySpace;")
    println(s"Dropped from Cassandra KeySpace $CassandraAuditDtlKeySpace")

    // CREATE

    session.execute(s"CREATE KEYSPACE IF NOT EXISTS $CassandraReferentielKeySpace WITH replication = {'class': 'SimpleStrategy', 'replication_factor' : 1}")
    println(s"Created in Cassandra keyspace $CassandraReferentielKeySpace")

    session.execute(s"CREATE KEYSPACE IF NOT EXISTS $CassandraExternalRiskKeySpace WITH replication = {'class': 'SimpleStrategy', 'replication_factor' : 1}")
    println(s"Created in Cassandra keyspace $CassandraExternalRiskKeySpace")

    session.execute(s"CREATE KEYSPACE IF NOT EXISTS $CassandraInternalRiskKeySpace WITH replication = {'class': 'SimpleStrategy', 'replication_factor' : 1}")
    println(s"Created in Cassandra keyspace $CassandraInternalRiskKeySpace")

    session.execute(s"CREATE KEYSPACE IF NOT EXISTS $CassandraAuditDtlKeySpace WITH replication = {'class': 'SimpleStrategy', 'replication_factor' : 1}")
    println(s"Created in Cassandra keyspace $CassandraAuditDtlKeySpace")


    println("Init cassandra keyspaces terminated")
  }

  def initTables(): Unit = {

    // DROP

    session.execute(s"DROP TABLE IF EXISTS  $CassandraReferentielKeySpace.ref_pays_suspect")
    println(s"Dropped from Cassandra table $CassandraReferentielKeySpace.ref_pays_suspect")

    session.execute(s"DROP TABLE IF EXISTS $CassandraReferentielKeySpace.ref_contact_infos_cavalerie")
    println(s"Dropped from Cassandra table $CassandraReferentielKeySpace.ref_contact_infos_cavalerie")

    session.execute(s"DROP TABLE IF EXISTS $CassandraReferentielKeySpace.ref_contact_infos_cavalerie_contact_id")
    println(s"Dropped from Cassandra table $CassandraReferentielKeySpace.ref_contact_infos_cavalerie_contact_id")

    session.execute(s"DROP TABLE IF EXISTS $CassandraReferentielKeySpace.ref_utilisateur")
    println(s"Dropped from Cassandra table $CassandraReferentielKeySpace.ref_utilisateur")

    session.execute(s"DROP TABLE IF EXISTS $CassandraExternalRiskKeySpace.sortie_fond")
    println(s"Dropped from Cassandra table $CassandraReferentielKeySpace.sortie_fond")

    session.execute(s"DROP TABLE IF EXISTS $CassandraExternalRiskKeySpace.sortie_fond_suspect")
    println(s"Dropped from Cassandra table $CassandraExternalRiskKeySpace.sortie_fond_suspect")

    session.execute(s"DROP TABLE IF EXISTS $CassandraExternalRiskKeySpace.action_externe")
    println(s"Dropped from Cassandra table $CassandraExternalRiskKeySpace.action_externe")

    session.execute(s"DROP TABLE IF EXISTS $CassandraAuditDtlKeySpace.rejet_fraude")
    println(s"Dropped from Cassandra table $CassandraAuditDtlKeySpace.rejet_fraude")

    // CREATE

    session.execute(s"CREATE TABLE IF NOT EXISTS $CassandraReferentielKeySpace.ref_pays_suspect (code_pays text, lib_pays text, statut_suspect int, PRIMARY KEY (code_pays))")
    println(s"Create in Cassandra table $CassandraReferentielKeySpace.ref_pays_suspect")

    session.execute(s"CREATE TABLE IF NOT EXISTS $CassandraReferentielKeySpace.ref_contact_infos_cavalerie (id_web bigint, contact_id bigint, date_entree_relation timestamp, encours double, encours_cash_cav double, encours_cash_epargne double, mt_cumule_rc double, nom text, prenom text, nombre_rc int, PRIMARY KEY (id_web, contact_id))")
    println(s"Create in Cassandra table $CassandraReferentielKeySpace.ref_contact_infos_cavalerie")

    session.execute(s"""CREATE MATERIALIZED VIEW $CassandraReferentielKeySpace.ref_contact_infos_cavalerie_contact_id AS
      SELECT contact_id, id_web, date_entree_relation, encours, encours_cash_cav, encours_cash_epargne, mt_cumule_rc, nom, nombre_rc, prenom
      FROM $CassandraReferentielKeySpace.ref_contact_infos_cavalerie
      WHERE contact_id IS NOT NULL AND id_web IS NOT NULL
      PRIMARY KEY (contact_id, id_web)""")
    println(s"Create in Cassandra table $CassandraReferentielKeySpace.ref_contact_infos_cavalerie_contact_id")

    session.execute(s"""CREATE TABLE IF NOT EXISTS $CassandraReferentielKeySpace.ref_utilisateur (
      login_user text,
      statut_utilisateur int,
      login_web_pcc text,
      id_user_crm bigint,
      code_operateur_cis int,
      code_operateur_sgss text,
      date_creation timestamp,
      date_desactivation timestamp,
      fonction_utilisateur text,
      libelle_customer_range text,
      nom_service_utilisateur text,
      nom_utilisateur text,
      prenom_utilisateur text,
      PRIMARY KEY (login_user, statut_utilisateur, login_web_pcc, id_user_crm, code_operateur_cis))
      """)
    println(s"Create in Cassandra table $CassandraReferentielKeySpace.ref_utilisateur")

    session.execute(s"CREATE TABLE IF NOT EXISTS $CassandraExternalRiskKeySpace.sortie_fond (sys_origine text, annee_mois  bigint, date_operation  timestamp, id_transaction text, id_web bigint, adresse_ip  text, montant double, code_operation  text, iban_source text, iban_cible text, code_pays_cible text, contact_id   bigint, date_entree_relation timestamp, encours  double, mt_cumule_rc double, nombre_rc bigint, solde_previsionnel double, PRIMARY KEY (id_web, date_operation, id_transaction)  ) WITH CLUSTERING ORDER BY (date_operation DESC, id_transaction ASC)")
    println(s"Create in Cassandra table $CassandraExternalRiskKeySpace.sortie_fond")

    session.execute(s"CREATE TABLE IF NOT EXISTS $CassandraExternalRiskKeySpace.sortie_fond_suspect (sys_origine text, annee_mois  bigint, date_operation  timestamp, id_transaction text, id_web bigint, adresse_ip  text, montant double, iban_source text, iban_cible text, code_pays_cible text, contact_id   bigint, date_entree_relation timestamp, encours double, mt_cumule_rc double, nombre_rc bigint, solde_previsionnel double, type_fraude text, param_fraude text, PRIMARY KEY (id_web, date_operation, id_transaction, type_fraude)) WITH CLUSTERING ORDER BY (date_operation DESC, id_transaction ASC, type_fraude ASC)")
    println(s"Create in Cassandra table $CassandraExternalRiskKeySpace.sortie_fond_suspect")

    session.execute(s"CREATE TABLE IF NOT EXISTS $CassandraExternalRiskKeySpace.action_externe (sys_origine text, annee_mois  bigint, date_operation  timestamp, id_transaction text, id_web bigint, adresse_ip  text, montant text, code_operation text, iban_source text, iban_cible text, code_pays_cible text, client_contact_id bigint, client_nom text, client_prenom text, client_date_entree_relation timestamp, client_encours  double, client_mt_cumule_rc  double, client_nombre_rc bigint, solde_previsionnel double, PRIMARY KEY (id_web, date_operation, id_transaction)  ) WITH CLUSTERING ORDER BY (date_operation DESC, id_transaction ASC)")
    println(s"Create in Cassandra table $CassandraExternalRiskKeySpace.action_externe")

    session.execute(s"CREATE TABLE IF NOT EXISTS $CassandraAuditDtlKeySpace.rejet_fraude (sys_origine text, timestamp timestamp, code_cause int, cause text, stack_trace text, login_user text, log text, PRIMARY KEY (code_cause, sys_origine, cause, login_user))")
    println(s"Create in Cassandra table $CassandraAuditDtlKeySpace.rejet_fraude")

    println("Init cassandra tables terminated")
  }

  def initData(): Unit = {

    // TRUNCATE

    session.execute(s"TRUNCATE $CassandraReferentielKeySpace.ref_pays_suspect")
    println(s"Truncated table in Cassandra $CassandraReferentielKeySpace.ref_pays_suspect")

    session.execute(s"TRUNCATE $CassandraReferentielKeySpace.ref_contact_infos_cavalerie")
    println(s"Truncated table in Cassandra $CassandraReferentielKeySpace.ref_contact_infos_cavalerie")

    session.execute(s"TRUNCATE $CassandraReferentielKeySpace.prm_fraude")
    println(s"Truncated table in Cassandra $CassandraReferentielKeySpace.prm_fraude")

    session.execute(s"TRUNCATE $CassandraExternalRiskKeySpace.sortie_fond")
    println(s"Truncated table in Cassandra $CassandraExternalRiskKeySpace.sortie_fond")

    session.execute(s"TRUNCATE $CassandraExternalRiskKeySpace.sortie_fond_suspect")
    println(s"Truncated table in Cassandra $CassandraExternalRiskKeySpace.sortie_fond_suspect")

    session.execute(s"TRUNCATE $CassandraExternalRiskKeySpace.action_externe")
    println(s"Truncated table in Cassandra $CassandraExternalRiskKeySpace.action_externe")

    session.execute(s"TRUNCATE $CassandraInternalRiskKeySpace.action_interne")
    println(s"Truncated table in Cassandra $CassandraInternalRiskKeySpace.action_interne")

    session.execute(s"TRUNCATE $CassandraAuditDtlKeySpace.rejet_fraude")
    println(s"Truncated table in Cassandra $CassandraAuditDtlKeySpace.rejet_fraude")

    // INSERTIONS

    session.execute(s"INSERT INTO $CassandraReferentielKeySpace.ref_pays_suspect (code_pays, lib_pays, statut_suspect) VALUES ('CU','CUBA',1)")
    session.execute(s"INSERT INTO $CassandraReferentielKeySpace.ref_pays_suspect (code_pays, lib_pays, statut_suspect) VALUES ('IR','IRAN',1)")
    session.execute(s"INSERT INTO $CassandraReferentielKeySpace.ref_pays_suspect (code_pays, lib_pays, statut_suspect) VALUES ('LY','LIBYA',1)")
    session.execute(s"INSERT INTO $CassandraReferentielKeySpace.ref_pays_suspect (code_pays, lib_pays, statut_suspect) VALUES ('SS','SOUDAN DU SUD',1)")
    session.execute(s"INSERT INTO $CassandraReferentielKeySpace.ref_pays_suspect (code_pays, lib_pays, statut_suspect) VALUES ('SD','SOUDAN',1)")
    session.execute(s"INSERT INTO $CassandraReferentielKeySpace.ref_pays_suspect (code_pays, lib_pays, statut_suspect) VALUES ('SY','SYRIE',1)")
    session.execute(s"INSERT INTO $CassandraReferentielKeySpace.ref_pays_suspect (code_pays, lib_pays, statut_suspect) VALUES ('TN','TUNISIE',1)")
    session.execute(s"INSERT INTO $CassandraReferentielKeySpace.ref_pays_suspect (code_pays, lib_pays, statut_suspect) VALUES ('UA','UKRAINE',1)")
    session.execute(s"INSERT INTO $CassandraReferentielKeySpace.ref_pays_suspect (code_pays, lib_pays, statut_suspect) VALUES ('BW','BOTSWANA',1)")
    session.execute(s"INSERT INTO $CassandraReferentielKeySpace.ref_pays_suspect (code_pays, lib_pays, statut_suspect) VALUES ('BN','BRUNEI',1)")

    session.execute(s"INSERT INTO $CassandraReferentielKeySpace.ref_pays_suspect (code_pays, lib_pays, statut_suspect) VALUES ('GT','GUATEMALA',1)")
    session.execute(s"INSERT INTO $CassandraReferentielKeySpace.ref_pays_suspect (code_pays, lib_pays, statut_suspect) VALUES ('MH','ILES MARSHALL',1)")
    session.execute(s"INSERT INTO $CassandraReferentielKeySpace.ref_pays_suspect (code_pays, lib_pays, statut_suspect) VALUES ('NR','NAURU',1)")
    session.execute(s"INSERT INTO $CassandraReferentielKeySpace.ref_pays_suspect (code_pays, lib_pays, statut_suspect) VALUES ('NU','NIUE',1)")
    session.execute(s"INSERT INTO $CassandraReferentielKeySpace.ref_pays_suspect (code_pays, lib_pays, statut_suspect) VALUES ('PA','PANAMA',1)")
    session.execute(s"INSERT INTO $CassandraReferentielKeySpace.ref_pays_suspect (code_pays, lib_pays, statut_suspect) VALUES ('TR','TURQUIE',1)")

    println(s"Inserted data in Cassandra table $CassandraReferentielKeySpace.ref_pays_suspect")

    session.execute(s"INSERT INTO $CassandraReferentielKeySpace.ref_contact_infos_cavalerie (id_web, contact_id,nom,prenom, date_entree_relation, encours, mt_cumule_rc, nombre_rc ) VALUES (68656476,68656476,'Oueslati','fares','2015-11-20T14:22:54.000Z',10000,1000,5)")
    println(s"Inserted data in Cassandra table $CassandraReferentielKeySpace.ref_contact_infos_cavalerie")

    session.execute(s"INSERT INTO $CassandraReferentielKeySpace.prm_fraude (type_fraude, statut, param_fraude) VALUES ('$TYPE_FRAUDE_EXT_CAVALERIE', 1, {'seuilAncienneteMoinsEgalQue': '730', 'seuilCumulRmcPlusEgalQue': '1000', 'seuilMontantPlusEgalQue': '1000', 'seuilSoldeCumulMoinsEgalQue': '-5000'})")
    session.execute(s"INSERT INTO $CassandraReferentielKeySpace.prm_fraude (type_fraude, statut, param_fraude) VALUES ('$TYPE_FRAUDE_EXT_CAVALERIE_BOOSTER', 1, {'seuilAncienneteMoinsEgalQue': '730', 'seuilCumulRmcPlusEgalQue': '1000', 'seuilMontantPlusEgalQue': '0', 'seuilSoldeCumulMoinsEgalQue': '0'})")
    session.execute(s"INSERT INTO $CassandraReferentielKeySpace.prm_fraude (type_fraude, statut, param_fraude) VALUES ('$TYPE_FRAUDE_INT_HEURE_SUSPECTE', 1, {'seuilHeureSuspecteMoinsQue': '5', 'seuilHeureSuspectePlusQue': '22'});")
    session.execute(s"INSERT INTO $CassandraReferentielKeySpace.prm_fraude (type_fraude, statut, param_fraude) VALUES ('$TYPE_FRAUDE_INT_ENCOURS_SUPERIEUR', 1, {'seuilEncoursPlusEgalQue': '100000'});")
    session.execute(s"INSERT INTO $CassandraReferentielKeySpace.prm_fraude (type_fraude, statut, param_fraude) VALUES ('$TYPE_FRAUDE_INT_CLIENT_VIP', 1, {'listeClientsVip': '211305599,3465874018,5717861858,3189051330,250569,5805145920,35021359'});")

    println(s"Inserted data in Cassandra table $CassandraReferentielKeySpace.prm_fraude")

    println("Init cassandra data terminated")
  }
}
