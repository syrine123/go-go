package com.boursorama.cassandra

object RejectionHandler extends Serializable {

  val UNKNOWN_LOGIN_IN_DWH_ERROR = 0
  val PARSING_ERROR = 1
  val TYPE_PARSING_ERROR = 2
  val NONE_VALUE = 3
  val UNKNOWN_CONTACT_ID_IN_REF_RISQUE_CLIENT = 4
  val UNKNOWN_CONTACT_ID_IN_REF_CLIENT_360 = 5

  val causes = Map[Int, String](
    UNKNOWN_LOGIN_IN_DWH_ERROR -> "Login non trouvé dans le DWH",
    PARSING_ERROR -> "Erreur de parsing",
    TYPE_PARSING_ERROR -> "Parsing du type provenant de logstash non trouvé",
    NONE_VALUE -> "Valeur nulle",
    UNKNOWN_CONTACT_ID_IN_REF_RISQUE_CLIENT -> "Contact id introuvable dans ref risque client",
    UNKNOWN_CONTACT_ID_IN_REF_CLIENT_360 -> "Contact id introuvable dans ref client 360")

  def handleRejection(sysOrigine: String, erroCode: Int, stackTrace: String, loginUser: String, log: String): Unit = {
    val errorMess: String = causes.getOrElse(erroCode, "UNKNOWN")
    CassandraClient.writeRejection(sysOrigine, erroCode, errorMess.trim, stackTrace.trim, loginUser, log.trim)
  }
}
