package com.boursorama.cassandra

import com.boursorama.dtl.business._
import com.boursorama.utils.AppConf._
import com.boursorama.utils.Conversion
import com.boursorama.utils.Conversion._
import com.boursorama.utils.Constants._
import com.datastax.driver.core._
import scala.collection.JavaConverters._
import java.util.Date
import com.datastax.driver.core.policies.{ DefaultRetryPolicy, ExponentialReconnectionPolicy }
import org.joda.time.DateTime
import scala.collection.mutable.ArrayBuffer

object CassandraClient extends Serializable {

  private val auth_provider = new PlainTextAuthProvider(CassandraUsername, CassandraPassword)
  private val nodes = CassandraNodes.split(",").map(_.trim())

  private val cluster = Cluster.builder()
    .addContactPoints(nodes.toArray: _*)
    .withAuthProvider(auth_provider)
    .withQueryOptions(new QueryOptions().setConsistencyLevel(ConsistencyLevel.LOCAL_QUORUM))
    .withRetryPolicy(DefaultRetryPolicy.INSTANCE)
    .withReconnectionPolicy(new ExponentialReconnectionPolicy(100, 60000))
    .withSocketOptions(new SocketOptions().setKeepAlive(true))
    .build()

  private val session = cluster.connect()

  private val statementGetFraudParameters = session.prepare(s"SELECT * FROM $CassandraReferentielKeySpace.prm_fraude WHERE type_fraude = ? AND statut = 1")
  private val statementGetAllPaysSuspectsFlagBlanchiment = session.prepare(s"SELECT id_dim_pays FROM $CassandraReferentielKeySpace.ref_pays where flag_blanchiment = 1 ALLOW FILTERING")
  private val statementGetAllPaysSuspectsFlagEmbargo = session.prepare(s"SELECT id_dim_pays FROM $CassandraReferentielKeySpace.ref_pays where flag_embargo_sanctions = 1 ALLOW FILTERING")
  private val statementGetAllPaysSuspectsFlagNonCooperatif = session.prepare(s"SELECT id_dim_pays FROM $CassandraReferentielKeySpace.ref_pays where flag_non_cooperatif = 1 ALLOW FILTERING")
  private val statementGetClientInformationByIdWeb = session.prepare(s"SELECT * FROM $CassandraReferentielKeySpace.ref_contact_infos_cavalerie WHERE id_web = ?")
  private val statementGetClientInformationByContactId = session.prepare(s"SELECT * FROM $CassandraReferentielKeySpace.ref_contact_infos_cavalerie_contact_id WHERE contact_id = ?")
  private val statementWriteRejection = session.prepare(s"INSERT INTO $CassandraAuditDtlKeySpace.rejet (sys_origine, timestamp, code_cause, cause, stack_trace, login_user, log) VALUES (?, ?, ?, ?, ?, ?, ?)")
  private val statementGetTodayClientSumSortieFondMontant = session.prepare(s"SELECT sum(montant) AS sum_montant FROM $CassandraExternalRiskKeySpace.sortie_fond WHERE id_web = ? AND id_dim_temps = ?")
  private val statementGetLastMonthClientSumSortieFondTiers = session.prepare(s"SELECT sum(montant) AS sum_montant FROM $CassandraExternalRiskKeySpace.sortie_fond WHERE id_web = ? AND id_dim_temps > ? AND iban_cible = ? ALLOW FILTERING")
  private val statementGetLastMonthClientSortieFondTiers = session.prepare(s"SELECT count(*) AS count_client, sum(montant) AS sum_montant FROM $CassandraExternalRiskKeySpace.sortie_fond WHERE id_web = ? AND id_dim_temps > ? AND iban_cible = ? ALLOW FILTERING")
  private val getNumContratClient = session.prepare(s"select numero_contrat AS numContrat from $CassandraReferentielKeySpace.ref_contrat where identifiant_web = ? ")
  private val statementGetLastMonthClientEntreeFondTiers = session.prepare(s"SELECT count(*) AS count_client FROM $CassandraExternalRiskKeySpace.sortie_fond WHERE id_web = ? AND id_dim_temps > ? AND iban_source = ? ALLOW FILTERING")
  private val statementGetSuspectConnectionsInLast3Weeks = session.prepare(s"SELECT id_web FROM $CassandraExternalRiskKeySpace.connexion WHERE id_dim_temps < ? AND id_web=? AND type_fraude=? ALLOW FILTERING")
  private val statementGetClientSumSortieFondMontant = session.prepare(s"SELECT sum(montant) AS sum_montant FROM $CassandraExternalRiskKeySpace.sortie_fond WHERE id_web = ? AND id_dim_temps >= ? ALLOW FILTERING")
  private val statementMailsChangeIdContact = session.prepare(s"SELECT count(*) AS count_changes FROM $CassandraReferentielValorizationKeySpace.mail_changes WHERE contact_id = ? AND id_dim_temps > ? ALLOW FILTERING")
  private val statementMailsChangeIdWeb = session.prepare(s"SELECT count(*) AS count_changes FROM $CassandraReferentielValorizationKeySpace.mail_changes WHERE web_id = ? AND id_dim_temps > ? ALLOW FILTERING")
  private val statementTelsChangeIdWeb = session.prepare(s"SELECT count(*) AS count_changes FROM $CassandraReferentielValorizationKeySpace.tel_changes WHERE web_id = ? AND id_dim_temps > ?  ALLOW FILTERING")
  private val statementTelsChangeIdContact = session.prepare(s"SELECT count(*) AS count_changes FROM $CassandraReferentielValorizationKeySpace.tel_changes WHERE contact_id = ? AND id_dim_temps > ?  ALLOW FILTERING")

  private val statementIbanAddIdWeb = session.prepare(s"SELECT id_dim_temps FROM $CassandraReferentielValorizationKeySpace.iban_changes WHERE web_id = ? AND id_dim_temps > ? and infos = ? ALLOW FILTERING")
  private val statementIbanAddIdContact = session.prepare(s"SELECT id_dim_temps FROM $CassandraReferentielValorizationKeySpace.iban_changes WHERE contact_id = ? AND id_dim_temps > ? and infos = ? ALLOW FILTERING")

  private val statementMailDateChangeIdWeb = session.prepare(s"SELECT id_dim_temps, infos FROM $CassandraReferentielValorizationKeySpace.mail_changes WHERE web_id = ? AND id_dim_temps >= ? AND id_dim_temps <= ? limit 1 ALLOW FILTERING")
  private val statementMailDateChangeIdContact = session.prepare(s"SELECT id_dim_temps, infos FROM $CassandraReferentielValorizationKeySpace.mail_changes WHERE contact_id = ? AND id_dim_temps >= ? AND id_dim_temps <= ? limit 1 ALLOW FILTERING")

  private val statementTelDateChangeIdWeb = session.prepare(s"SELECT id_dim_temps, infos FROM $CassandraReferentielValorizationKeySpace.tel_changes WHERE web_id = ? AND id_dim_temps >= ? AND id_dim_temps <= ? limit 1 ALLOW FILTERING")
  private val statementTelDateChangeIdContact = session.prepare(s"SELECT id_dim_temps, infos FROM $CassandraReferentielValorizationKeySpace.tel_changes WHERE contact_id = ? AND id_dim_temps >= ? AND id_dim_temps <= ? limit 1 ALLOW FILTERING")

  private val statementGetEmailClient = session.prepare(s"select email from $CassandraReferentielKeySpace.ref_client where id_dim_personne = ? ")
  private val statementGetTelClient = session.prepare(s"select telephone_portable from $CassandraReferentielKeySpace.ref_client where id_dim_personne = ? ")

  private val statementGetIdClient = session.prepare(s"select id_dim_personne from $CassandraReferentielKeySpace.ref_client_contact where identifiant_web = ? ")

  def execute(query: String): ResultSet = {
    session.execute(query)
  }

  def getSession: Session = {
    session
  }

  def getCountMailsChangeDaysBeforeIdWeb(idWeb: Long, duration: Int): Long = {
    val timestampDaysAgo = getPreviousDaysDate(duration)
    val result = session.execute(statementMailsChangeIdWeb.bind(idWeb: java.lang.Long, timestampDaysAgo: java.lang.Integer)).all
    if (result.size() > 0) {
      val row = result.get(0)
      row.getLong("count_changes")
    } else {
      0
    }
  }

  def getCountTelsChangeDaysBeforePerIdWeb(idWeb: Long, duration: Int): Long = {
    val timestampDaysAgo = getPreviousDaysDate(duration)
    val result = session.execute(statementTelsChangeIdWeb.bind(idWeb: java.lang.Long, timestampDaysAgo: java.lang.Integer)).all
    if (result.size() > 0) {
      val row = result.get(0)
      row.getLong("count_changes")
    } else {
      0
    }
  }

  def getCountMailsChangeDaysBeforePerIdContact(idContact: Long, duration: Int): Long = {
    val timestampDaysAgo = getPreviousDaysDate(duration)
    val result = session.execute(statementMailsChangeIdContact.bind(idContact: java.lang.Long, timestampDaysAgo: java.lang.Integer)).all
    if (result.size() > 0) {
      val row = result.get(0)
      row.getLong("count_changes")
    } else {
      0
    }
  }

  def getCountTelsChangeDaysBeforePerIdContact(idContact: Long, duration: Int): Long = {
    val timestampDaysAgo = getPreviousDaysDate(duration)
    val result = session.execute(statementTelsChangeIdContact.bind(idContact: java.lang.Long, timestampDaysAgo: java.lang.Integer)).all
    if (result.size() > 0) {
      val row = result.get(0)
      row.getLong("count_changes")
    } else {
      0
    }
  }

  def getTodayClientSumSortieFondMontantJ_1(idWeb: Long): Double = {
    val day = Conversion.getPreviousDaysDate(1)
    val result = session.execute(statementGetTodayClientSumSortieFondMontant.bind(idWeb: java.lang.Long, day: java.lang.Integer)).all
    if (result.size() > 0) {
      val row = result.get(0)
      row.getDouble("sum_montant")
    } else {
      0
    }
  }

  def getTodayClientSumSortieFondMontantJ_2(idWeb: Long): Double = {
    val day = Conversion.getPreviousDaysDate(2)
    val result = session.execute(statementGetTodayClientSumSortieFondMontant.bind(idWeb: java.lang.Long, day: java.lang.Integer)).all
    if (result.size() > 0) {
      val row = result.get(0)
      row.getDouble("sum_montant")
    } else {
      0
    }
  }

  def getTodayClientSumSortieFondMontantJ_3(idWeb: Long): Double = {
    val day = Conversion.getPreviousDaysDate(3)
    val result = session.execute(statementGetTodayClientSumSortieFondMontant.bind(idWeb: java.lang.Long, day: java.lang.Integer)).all
    if (result.size() > 0) {
      val row = result.get(0)
      row.getDouble("sum_montant")
    } else {
      0
    }
  }

  def getTodayClientSumSortieFondMontant(idWeb: Long): Double = {
    val today = Conversion.getYearMonthDay(Conversion.nowToDateTime())
    val result = session.execute(statementGetTodayClientSumSortieFondMontant.bind(idWeb: java.lang.Long, today: java.lang.Integer)).all
    if (result.size() > 0) {
      val row = result.get(0)
      row.getDouble("sum_montant")
    } else {
      0
    }
  }

  def getLastMonthClientSumSortieFondTiers(idWeb: Long, ibanCible: String): Double = {
    val timestamp1MonthAgo = get1MonthAgoDate().toInt
    val result = session.execute(statementGetLastMonthClientSumSortieFondTiers.bind(idWeb: java.lang.Long, timestamp1MonthAgo: java.lang.Integer, ibanCible: String)).all
    if (result.size() > 0) {
      val row = result.get(0)
      row.getDouble("sum_montant")
    } else {
      0
    }
  }

  def getLast3MonthsClientSumSortieFondTiers(idWeb: Long, ibanCible: String): Double = {
    val timestamp1MonthAgo = get3MonthsAgoDate().toInt
    val result = session.execute(statementGetLastMonthClientSumSortieFondTiers.bind(idWeb: java.lang.Long, timestamp1MonthAgo: java.lang.Integer, ibanCible: String)).all
    if (result.size() > 0) {
      val row = result.get(0)
      row.getDouble("sum_montant")
    } else {
      0
    }
  }

  def getLastMonthClientSortieFondTiers(idWeb: Long, ibanCible: String): (Long, Double) = {
    val timestamp1MonthAgo = get1MonthAgoDate().toInt
    val result = session.execute(statementGetLastMonthClientSortieFondTiers.bind(idWeb: java.lang.Long, timestamp1MonthAgo: java.lang.Integer, ibanCible: String)).all
    if (result.size() > 0) {
      val row = result.get(0)
      (row.getLong("count_client"), row.getDouble("sum_montant"))
    } else {
      (0, 0.0)
    }
  }

  def getLastMonthClientEntreeFondTiers(idWeb: Long, ibanCible: String): Long = {
    val timestamp1MonthAgo = get1MonthAgoDate().toInt
    val result = session.execute(statementGetLastMonthClientEntreeFondTiers.bind(idWeb: java.lang.Long, timestamp1MonthAgo: java.lang.Integer, ibanCible: String)).all
    if (result.size() > 0) {
      val row = result.get(0)
      row.getLong("count_client")
    } else {
      0
    }
  }

  def getNumContratClient(idWeb: Long): List[String] = {
    val result = session.execute(getNumContratClient.bind(idWeb: java.lang.Long)).all
    var nums_contrat = List[String]()
    if (result.size() > 0) {
      var i = 0
      while (i < result.size()) {
        val row = result.get(i)
        nums_contrat = row.getString("numContrat") :: nums_contrat
        i = i + 1
      }
      nums_contrat
    } else {
      nums_contrat = "" :: nums_contrat
      nums_contrat
    }
  }

  def getFraudeParams(fraud_type: String): Option[FraudeParams] = {

    val result = session.execute(statementGetFraudParameters.bind(fraud_type)).all
    if (result.size() > 0) {
      val row = result.get(0)
      val param_fraude: scala.collection.mutable.Map[String, String] = row.getObject("param_fraude").asInstanceOf[java.util.LinkedHashMap[String, String]].asScala
      Some(FraudeParams(
        row.getString("type_fraude"),
        row.getInt("statut"),
        param_fraude.toMap))
    } else {
      None
    }
  }

  def getAllPaysSuspectsFlagBlanchiment: Option[List[String]] = {
    val result = session.execute(statementGetAllPaysSuspectsFlagBlanchiment.bind()).all().asScala
    if (result.nonEmpty) {
      Some(result.map(row => row.getString("id_dim_pays")).toList)
    } else {
      None
    }
  }

  def getAllPaysSuspectsFlagEmbargo: Option[List[String]] = {
    val result = session.execute(statementGetAllPaysSuspectsFlagEmbargo.bind()).all().asScala
    if (result.nonEmpty) {
      Some(result.map(row => row.getString("id_dim_pays")).toList)
    } else {
      None
    }
  }

  def getAllPaysSuspectsNonCooperatif: Option[List[String]] = {
    val result = session.execute(statementGetAllPaysSuspectsFlagNonCooperatif.bind()).all().asScala
    if (result.nonEmpty) {
      Some(result.map(row => row.getString("id_dim_pays")).toList)
    } else {
      None
    }
  }

  def getClientInformationByKey(clientId: java.lang.Long): Option[Client] = {
    var result = session.execute(statementGetClientInformationByIdWeb.bind(clientId)).all
    if (result.size() <= 0) {
      result = session.execute(statementGetClientInformationByContactId.bind(clientId)).all
    }
    if (result.size() > 0) {
      val row = result.get(0)
      val timestamp = Option(row.getTimestamp("date_entree_relation")) match {
        case Some(t) => Some(getDateTime(t.getTime))
        case _       => None
      }
      Some(Client(
        row.getLong("id_web"),
        row.getLong("contact_id"),
        timestamp,
        row.getDouble("encours"),
        row.getDouble("mt_cumule_rc"),
        row.getInt("nombre_rc")))
    } else {
      None
    }
  }


  def getSuspectConnectionsInLast3Weeks(id_web: java.lang.Long): Boolean = {
    val timestamp3WeeksAgo = getPreviousDaysDate(21)
    //val timestamp3WeeksAgo: java.lang.Long = System.currentTimeMillis() / 1000 - ( 60 * 60 * 24 * 7 * 3 ) //timestamp 3 weeks ago
    val result = session.execute(statementGetSuspectConnectionsInLast3Weeks.bind(timestamp3WeeksAgo: java.lang.Integer, id_web, TYPE_FRAUDE_EXT_EMBARGO)).all().asScala
    if (result.nonEmpty) {
      true
    } else {
      false
    }
  }

  def writeRejection(sysOrigine: String, errorCode: Int, errorMess: String, stackTrace: String, loginUser: String, log: String): Unit = {
    session.executeAsync(statementWriteRejection.bind(
      sysOrigine,
      nowToDateTime().toDate,
      errorCode: Integer,
      errorMess,
      stackTrace,
      loginUser,
      log))
  }

  def getClientSumSortieFondMontant(idWeb: Long, previousDay: Int): Double = {
    val result = session.execute(statementGetClientSumSortieFondMontant.bind(idWeb: java.lang.Long, previousDay: java.lang.Integer)).all
    if (result.size() > 0) {
      val row = result.get(0)
      row.getDouble("sum_montant")
    } else {
      0
    }
  }

  def getIbanAddInPreviousDay(idWeb: Long, idContact: Long, previousDay: Integer, ibanCible: String): Integer = {
    val row1 = session.execute(statementIbanAddIdWeb.bind(idWeb: java.lang.Long, previousDay: java.lang.Integer, ibanCible)).all
    if (row1.size() > 0) {
      row1.get(0).getInt("id_dim_temps")
    } else {
      val row2 = session.execute(statementIbanAddIdContact.bind(idContact: java.lang.Long, previousDay: java.lang.Integer, ibanCible)).all
      if (row2.size() > 0) {
        row2.get(0).getInt("id_dim_temps")
      } else {
        -1
      }
    }
  }

  /**
   * getDateMailChangeDaysBefore allows to get the date of the changing mail and the old mail
   * @param idWeb
   * @param idContact
   * @param dateAddIban
   * @param duration
   * @return Integer,String
   */
  def getDateMailChangeDaysBefore(idWeb: Long, idContact: Long, dateAddIban: Integer, duration: Int): (Integer, String, String) = {
    val timestampDaysAgo = getPreviousDaysDate(duration)
    if (dateAddIban != -1) {
      val row1 = session.execute(statementMailDateChangeIdWeb.bind(idWeb: java.lang.Long, timestampDaysAgo: java.lang.Integer, dateAddIban: java.lang.Integer)).all
      if (row1.size() > 0) {
        // get the id_dim_personne from the id_web
        val row = session.execute(statementGetIdClient.bind(idWeb: java.lang.Long)).all

        // get the old mail of the costumer
        val row3 = session.execute(statementGetEmailClient.bind(row.get(0).getLong("id_dim_personne"): java.lang.Long)).all()
        if (row3.size() > 0) {
          (row1.get(0).getInt("id_dim_temps"), row3.get(0).getString("email"), row1.get(0).getString("infos"))
        } else {
          (row1.get(0).getInt("id_dim_temps"), "undefined on client 360", row1.get(0).getString("infos"))
        }
      } else {
        val row2 = session.execute(statementMailDateChangeIdContact.bind(idContact: java.lang.Long, timestampDaysAgo: java.lang.Integer, dateAddIban: java.lang.Integer)).all()
        if (row2.size() > 0) {
          // get the old mail of the costumer
          val row = session.execute(statementGetEmailClient.bind(idContact: java.lang.Long)).all()
          if (row.size() > 0) {
            (row2.get(0).getInt("id_dim_temps"), row.get(0).getString("email"), row2.get(0).getString("infos"))
          } else {
            (row2.get(0).getInt("id_dim_temps"), "undefined on ref client", row2.get(0).getString("infos"))
          }
        } else {
          (-1, "-", "-")
        }
      }
    } else {
      (-1, "-", "-")
    }
  }

  /**
   * getDateTelChangeDaysBefore allows to get the date of the changing tel number and the old tel number
   * @param idWeb
   * @param idContact
   * @param dateAddIban
   * @param duration
   * @return Integer,String
   */
  def getDateTelChangeDaysBefore(idWeb: Long, idContact: Long, dateAddIban: Integer, duration: Int): (Integer, String, String) = {
    val timestampDaysAgo = getPreviousDaysDate(duration)
    if (dateAddIban != -1) {
      val row1 = session.execute(statementTelDateChangeIdWeb.bind(idWeb: java.lang.Long, timestampDaysAgo: java.lang.Integer, dateAddIban: java.lang.Integer)).one
      if (row1 != null) {
        // get the id_dim_personne from the id_web
        val row = session.execute(statementGetIdClient.bind(idWeb: java.lang.Long)).one

        // get the old tel number of the costumer
        val row3 = session.execute(statementGetTelClient.bind(row.getLong("id_dim_personne"): java.lang.Long)).one()
        if (row3 != null) {
          (row1.getInt("id_dim_temps"), row3.getString("telephone_portable"), row1.getString("infos"))
        } else {
          (row1.getInt("id_dim_temps"), "undefined on ref  client", row1.getString("infos"))
        }
      } else {
        val row2 = session.execute(statementTelDateChangeIdContact.bind(idContact: java.lang.Long, timestampDaysAgo: java.lang.Integer, dateAddIban: java.lang.Integer)).one()
        if (row2 != null) {
          // get the old tel number of the costumer
          val row = session.execute(statementGetTelClient.bind(idContact: java.lang.Long)).one()
          if (row != null) {
            (row2.getInt("id_dim_temps"), row.getString("telephone_portable"), row2.getString("infos"))
          } else {
            (row2.getInt("id_dim_temps"), "undefined on client 360", row2.getString("infos"))
          }
        } else {
          (-1, "-", "-")
        }
      }
    } else {
      (-1, "-", "-")
    }
  }

}
