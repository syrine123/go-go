package com.boursorama.dtl.business.cassandra

import org.joda.time.DateTime

import scala.beans.BeanProperty

class ConnectionCassDto (
  @BeanProperty var id_web: Long,
  @BeanProperty var annee_mois: Int,
  @BeanProperty var id_dim_temps: Int,
  @BeanProperty var timestamp : DateTime,
  @BeanProperty var client_contact_id: Long,
  @BeanProperty var log: String,
  @BeanProperty var pays: String,
  @BeanProperty var code_pays: String,
  @BeanProperty var ip: String,
  @BeanProperty var type_fraude: String,
  @BeanProperty var libelle_operation: String,
  @BeanProperty var honey_pot: String
                          )
