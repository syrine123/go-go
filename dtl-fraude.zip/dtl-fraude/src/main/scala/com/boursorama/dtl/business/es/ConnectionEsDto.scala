package com.boursorama.dtl.business.es

import scala.beans.BeanProperty

class ConnectionEsDto(
  @BeanProperty var id_web: Long,
  @BeanProperty var annee_mois: Int,
  @BeanProperty var id_dim_temps: Int,
  @BeanProperty var timestamp: String,
  @BeanProperty var client_contact_id: Long,
  @BeanProperty var log: String,
  @BeanProperty var pays: String,
  @BeanProperty var code_pays: String,
  @BeanProperty var ip: String,
  @BeanProperty var coordinates: Array[Double],
  @BeanProperty var type_fraude: String,
  @BeanProperty var libelle_operation: String,
  @BeanProperty var honey_pot: String) extends Serializable
