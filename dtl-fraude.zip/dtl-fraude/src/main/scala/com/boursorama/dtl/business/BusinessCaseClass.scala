package com.boursorama.dtl.business

import java.util.Date

import org.joda.time.DateTime

import scala.beans.BeanProperty

case class Client (
  id_web : Long,
  contact_id : Long,
  date_entree_relation: Option[DateTime],
  encours : Double,
  mt_cumule_rc: Double,
  nombre_rc : Int
)

case class SuspectSequence(
  id_web: Long,
  annee_mois: Int,
  service: String,
  id_dim_temps: Int,
  timestamp: DateTime,
  client_contact_id: Long,
  log: String,
  tel_changed: Boolean,
  iban_changed: Boolean
)

case class SortieFond(
  sys_origine :String,
  annee_mois : Int,
  id_dim_temps: Int,
  date_operation : DateTime,
  id_transaction: String,
  id_web: Long,
  adresse_ip : String,
  montant: Double,
  status :String,
  error_message:String,
  code_operation : String,
  banque_source:String,
  agence_source:String,
  compte_source:String,
  cle_rib_source:String,
  iban_source : String = null,
  iban_cible : String = null,
  code_pays_cible : String,
  // Client
  client: Option[Client] = None,
  solde_previsionnel : Double,
  log: String
)

class SortieFondSuspect (
  @BeanProperty var sys_origine: String,
  @BeanProperty var annee_mois: Int,
  @BeanProperty var id_dim_temps: Int,
  @BeanProperty var date_operation: DateTime,
  @BeanProperty var id_transaction: String,
  @BeanProperty var id_web: Long,
  @BeanProperty var adresse_ip: String,
  @BeanProperty var montant: Double,
  @BeanProperty var error_message: String,
  @BeanProperty var code_operation: String,
  @BeanProperty var banque_source: String,
  @BeanProperty var agence_source: String,
  @BeanProperty var compte_source: String,
  @BeanProperty var cle_rib_source: String,
  @BeanProperty var iban_source: String = null,
  @BeanProperty var iban_cible: String = null,
  @BeanProperty var code_pays_cible: String,
  // Client
  @BeanProperty var client: Option[Client] = None,
  @BeanProperty var solde_previsionnel : Double,
  // Fraude
  @BeanProperty var type_fraude: String,
  @BeanProperty var param_fraude: Map[String, String],
  @BeanProperty var valide_statut_fraude: Int,
  @BeanProperty var valide_username_fraude: String,
  @BeanProperty var valide_date_fraude: DateTime
)

case class FraudeParams (
  typeFraude: String,
  statut: Int,
  params: Map[String, String]
)

case class Connection(
  id_web: Long,
  annee_mois: Int,
  id_dim_temps: Int,
  timestamp: DateTime,
  contact_id: Long,
  log: String,
  pays: String,
  code_pays: String,
  ip: String,
  coords: Array[Double],
  var type_fraude: String,
  libelleOperation : String,
  honeyPot : String
)
