package com.boursorama.dtl.business.cassandra

import org.joda.time.DateTime

import scala.beans.BeanProperty

/**
 * Created by ubuntu on 22/06/16.
 */
class SortieFondSuspectCassDto(
                            @BeanProperty var sys_origine :String,
                            @BeanProperty var annee_mois : Int,
                            @BeanProperty var id_dim_temps: Int,
                            @BeanProperty var date_operation : DateTime,
                            @BeanProperty var id_transaction: String,
                            @BeanProperty var id_web: Long,
                            @BeanProperty var adresse_ip : String,
                            @BeanProperty var montant: Double,
                            //@BeanProperty var status :String,
                            //@BeanProperty var error_message:String,
                            @BeanProperty var code_operation : String,
                            //@BeanProperty var banque_source:String,
                            //@BeanProperty var agence_source:String,
                            //@BeanProperty var compte_source:String,
                            //@BeanProperty var cle_rib_source:String,
                            @BeanProperty var iban_source : String = null,
                            @BeanProperty var iban_cible : String = null,
                            @BeanProperty var code_pays_cible : String,
                            @BeanProperty var client_contact_id : Long,
                            @BeanProperty var client_date_entree_relation: DateTime,
                            @BeanProperty var client_encours : Double,
                            @BeanProperty var client_mt_cumule_rc: Double,
                            @BeanProperty var client_nombre_rc : Int,
                            @BeanProperty var solde_previsionnel:Double,
                            @BeanProperty var type_fraude: String,
                            @BeanProperty var param_fraude: String,
                            @BeanProperty var valide_statut_fraude: Int,
                            @BeanProperty var valide_username_fraude: String,
                            @BeanProperty var valide_date_fraude: DateTime
                            )
