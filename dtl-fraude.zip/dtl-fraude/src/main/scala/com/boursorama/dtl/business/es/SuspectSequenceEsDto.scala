package com.boursorama.dtl.business.es

import scala.beans.BeanProperty

class SuspectSequenceEsDto(
  @BeanProperty var id_web: Long,
  @BeanProperty var annee_mois: Int,
  @BeanProperty var service: String,
  @BeanProperty var id_dim_temps: Int,
  @BeanProperty var timestamp: String,
  @BeanProperty var client_contact_id: Long,
  @BeanProperty var log: String,
  @BeanProperty var tel_changed: Boolean,
  @BeanProperty var iban_changed: Boolean,
  @BeanProperty var type_fraude: String) extends Serializable
