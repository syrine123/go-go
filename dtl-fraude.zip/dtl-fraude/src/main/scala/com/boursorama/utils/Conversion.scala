package com.boursorama.utils

import java.sql.Timestamp
import java.text.SimpleDateFormat
import com.boursorama.utils.Constants._
import org.joda.time._
import org.joda.time.format.{ DateTimeFormat, DateTimeFormatter, ISODateTimeFormat }
import java.util.{ Calendar, Date }

import scala.util.{ Failure, Success, Try }

object Conversion {

  DateTimeZone.setDefault(DateTimeZone.UTC)
  val timestampFormatWithTZ: DateTimeFormatter = DateTimeFormat.forPattern("yyyy-MM-dd'T'HH:mm:ss.SSSZ").withZoneUTC()
  val timestampFormat: DateTimeFormatter = DateTimeFormat.forPattern("yyyy-MM-dd'T'HH:mm:ss").withZoneUTC()
  val yearMonthFormat: DateTimeFormatter = DateTimeFormat.forPattern("yyyyMM").withZoneUTC()
  val yearMonthDayFormat: DateTimeFormatter = DateTimeFormat.forPattern("yyyyMMdd").withZoneUTC()
  val hoursFormat: DateTimeFormatter = DateTimeFormat.forPattern("HH").withZoneUTC()
  val HourMinuteFormat: DateTimeFormatter = DateTimeFormat.forPattern("HHmm").withZoneUTC()
  val ParisTimeZone: DateTimeZone = DateTimeZone.forID("Europe/Paris")
  val yearMonthDayProspectFormat: DateTimeFormatter = DateTimeFormat.forPattern("dd/MM/yyyy")

  def cleanTimeZone(timestamp: String): String = {
    timestamp.split('.')(0)
  }

  protected def now(): DateTime = {
    new DateTime(new Date(), DateTimeZone.UTC)
  }

  def nowToDateTime(): DateTime = {
    now()
  }

  def nowToString(): String = {
    timestampFormat.print(now())
  }

  def getBeforeDay(minusDay: Int): LocalDate = {
    LocalDate.now.minus(Period.days(minusDay))
  }

  def nowToString(format: String): String = {
    val formatter = DateTimeFormat.forPattern(format).withZoneUTC()
    formatter.print(now())
  }

  def dateToDateTime(date: Date): DateTime = {
    new DateTime(date, DateTimeZone.UTC)
  }

  def dateToDateTime(date: Date, dateTimeZone: DateTimeZone): DateTime = {
    new DateTime(date, dateTimeZone).withZone(DateTimeZone.UTC)
  }

  def getDateTime(time: Long): DateTime = {
    new DateTime(time, DateTimeZone.UTC)
  }

  def getDateTime(time: Long, dateTimeZone: DateTimeZone): DateTime = {
    new DateTime(time, dateTimeZone).withZone(DateTimeZone.UTC)
  }

  def getDateTime(year: Int, month: Int, day: Int, hour: Int, min: Int, sec: Int): DateTime = {
    new DateTime(year, month, day, hour, min, sec, DateTimeZone.UTC)
  }

  def getDateTime(year: Int, month: Int, day: Int, hour: Int, min: Int, sec: Int, millis: Int): DateTime = {
    new DateTime(year, month, day, hour, min, sec, millis, DateTimeZone.UTC)
  }

  def getDateTime(year: Int, month: Int, day: Int, hour: Int, min: Int, sec: Int, dateTimeZone: DateTimeZone): DateTime = {
    new DateTime(year, month, day, hour, min, sec, dateTimeZone).withZone(DateTimeZone.UTC)
  }

  def getDateTime(year: Int, month: Int, day: Int, hour: Int, min: Int, sec: Int, millis: Int, dateTimeZone: DateTimeZone): DateTime = {
    new DateTime(year, month, day, hour, min, sec, millis, dateTimeZone).withZone(DateTimeZone.UTC)
  }

  def getDateTimeIgnoreMsAndTZ(timestamp: String): DateTime = {
    timestampFormat.parseDateTime(cleanTimeZone(timestamp))
  }

  def getDateTime(timestamp: String): DateTime = {
    timestampFormatWithTZ.parseDateTime(timestamp)
  }

  def getDateTimeProspect(timestamp: String): DateTime = {
    yearMonthDayProspectFormat.parseDateTime(timestamp)
  }

  def getDateTimeIgnoreMsAndTZ(timestamp: String, format: String): DateTime = {
    val formatter = DateTimeFormat.forPattern(format).withZoneUTC()
    formatter.parseDateTime(cleanTimeZone(timestamp))
  }

  def getDateTime(timestamp: String, format: String): DateTime = {
    val formatter = DateTimeFormat.forPattern(format).withZoneUTC()
    formatter.parseDateTime(timestamp)
  }

  def getDateTimeFromISO(isoTimestamp: String): DateTime = {
    DateTime.parse(isoTimestamp, ISODateTimeFormat.dateTimeParser().withZoneUTC())
  }

  def dateTimeToString(timestamp: DateTime): String = {
    timestampFormat.print(timestamp)
  }

  def dateTimeToString(timestamp: DateTime, format: String): String = {
    val formatter = DateTimeFormat.forPattern(format).withZoneUTC()
    formatter.print(timestamp)
  }

  def getYearMonth(timestamp: String): Int = {
    yearMonthFormat.print(timestampFormat.parseDateTime(timestamp)).toInt
  }

  def getYearMonth(date: DateTime): Int = {
    yearMonthFormat.print(date).toInt
  }

  def getYearMonth(date: LocalDateTime): Int = {
    yearMonthFormat.print(date).toInt
  }

  def getYearMonthDay(timestamp: String): Int = {
    yearMonthDayFormat.print(timestampFormat.parseDateTime(timestamp)).toInt
  }

  def getYearMonthDay(date: DateTime): Int = {
    yearMonthDayFormat.print(date).toInt
  }

  def getYearMonthDay(date: LocalDateTime): Int = {
    yearMonthDayFormat.print(date).toInt
  }

  def getYearMonthDayWithTZ(timestamp: String): String = {
    yearMonthDayFormat.print(timestampFormatWithTZ.parseDateTime(timestamp))
  }

  def getYesterdaysDate(): Int = {
    val ft = new SimpleDateFormat("yyyyMMdd")
    val cal = Calendar.getInstance()
    cal.add(Calendar.DATE, -1)
    val timestamp = cal.getTime
    ft.format(timestamp).toInt
  }

  def getPreviousDaysDate(jr: Int): Int = {
    val ft = new SimpleDateFormat("yyyyMMdd")
    val cal = Calendar.getInstance()
    cal.add(Calendar.DATE, -jr)
    val timestamp = cal.getTime
    ft.format(timestamp).toInt
  }

  def get3WeeksAgoDate(): Timestamp = {
    val dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:SSSZ")
    val cal = Calendar.getInstance()
    cal.add(Calendar.DATE, -21)
    val todate1 = cal.getTime
    new Timestamp(todate1.getTime)
  }

  def get1MonthAgoDate(): String = {
    val today = Calendar.getInstance()
    today.add(Calendar.DATE, -30)
    val todate = today.getTime
    val dateFormat = new SimpleDateFormat("yyyyMMdd")
    val lastMonthDate = dateFormat.format(todate.getTime)
    return lastMonthDate
  }

  def get3MonthsAgoDate(): String = {
    val today = Calendar.getInstance()
    today.add(Calendar.DATE, -90)
    val todate = today.getTime
    val dateFormat = new SimpleDateFormat("yyyyMMdd")
    val lastMonthDate = dateFormat.format(todate.getTime)
    return lastMonthDate
  }

  def escapeSimpleQuote(line: String): String = {
    line.replace("'", "\\'")
  }

  def strToLong(str: String): Long = {
    Try(str.toLong) match {
      case Success(v) => v
      case Failure(v) => EmptyLongField
    }
  }

  def strToInt(str: String): Int = {
    Try(str.toInt) match {
      case Success(v) => v
      case Failure(v) => EmptyLongField
    }
  }

  def NoneToLong(num: Option[Long]): Long = {
    num match {
      case Some(v) => v
      case _       => EmptyLongField
    }
  }

  def toInt(s: String): Option[Int] = {
    try {
      Some(s.toInt)
    } catch {
      case e: Exception => None
    }
  }

  def toDouble(s: String): Option[Double] = {
    try {
      Some(s.toDouble)
    } catch {
      case e: Exception => None
    }
  }
  def toLong(s: String): Option[Long] = {
    try {
      Some(s.toLong)
    } catch {
      case e: Exception => None
    }
  }
  def toLabel(code: String, map: collection.mutable.Map[String, String]): String = {
    var matchCode = Try(Codes(code, map).get)
    var label = ""
    matchCode match {
      case Success(v) => label = v.toString()
      case Failure(e) => label = "Libellé non trouvé"
    }
    label
  }

  /**
   * getNameDay allows to get the day name
   * @return String : day Name
   */
  def getNameDay(): String = {
    var dateToday = new LocalDate();
    DateTimeFormat.forPattern("EEEE").print(dateToday).toLowerCase()
  }

  /**
   * formatDate allows to add separator between year month and day
   * @param date
   * @return String : date_format
   */
  def formatDate(date: Integer): String = {
    if (date != null) {
      var date_ajout = date.toString()
      var date_format = date_ajout.substring(0, 4) + "-" + date_ajout.substring(4, 6) + "-" + date_ajout.substring(6, date_ajout.length())
      date_format
    } else {
      ""
    }
  }

  def addDaysDate(date: Int, number: Int): Int = {
    var date_str = date.toString()

    var dateParse: DateTime = new DateTime(date_str.substring(0, 4).toInt, date_str.substring(4, 6).toInt, date_str.substring(6, 8).toInt, 0, 0, 0)
    var dateAfter: DateTime = dateParse.plusDays(number)

    var fmt: DateTimeFormatter = DateTimeFormat.forPattern("yyyyMMdd")

    dateAfter.toString(fmt).toInt
  }
}
