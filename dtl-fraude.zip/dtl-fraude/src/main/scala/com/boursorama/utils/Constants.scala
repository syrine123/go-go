package com.boursorama.utils

import javax.mail.internet.InternetAddress

object Constants {
  val EmptyStringField = "-"
  val EmptyLongField = -1
  val TimeZoneParis = "Europe/Paris"
  val FluxCISE = "CISE"
  val FluxCIS5250 = "CIS5250"
  val FluxAtos = "ATOS"
  val FluxCrm = "CRM"
  val SUFFIX_BASE_FRAUDE = "-BASE-FRAUDE"

  val TYPE_FRAUDE_EXT_PAYS_SUSPECT: String = "EXTERNE-PAYS-SUSPECT"
  val TYPE_FRAUDE_EXT_CAVALERIE: String = "EXTERNE-CAVALERIE"
  val TYPE_FRAUDE_EXT_CAVALERIE_BOOSTER: String = "EXTERNE-CAVALERIE-BOOSTER"
  val TYPE_FRAUDE_INT_HEURE_SUSPECTE: String = "INTERNE-HEURE-SUSPECTE"
  val TYPE_FRAUDE_INT_ENCOURS_SUPERIEUR: String = "INTERNE-ENCOURS-SUPERIEUR"
  val TYPE_FRAUDE_INT_CLIENT_VIP: String = "INTERNE-CLIENT-VIP"
  val TYPE_FRAUDE_INT_CLIENT_COMEX: String = "INTERNE-CLIENT-COMEX"
  val TYPE_FRAUDE_EXT_EMBARGO: String = "EMBARGO"
  val TYPE_FRAUDE_EXT_EMBARGO_3_SEMAINES: String = "EMBARGO_3_SEMAINES"
  val TYPE_FRAUDE_EXT_EMBARGO_LIST: String = "EMBARGO_LIST"
  val EMBARGO_LIST: String = "CU,MX"

  val TYPE_FRAUDE_EXT_SEQUENCE_SUSPECTE: String = "SEQUENCE-SUSPECTE"
  val TYPE_FRAUDE_EXT_SEQUENCE_SUSPECTE_2: String = "SEQUENCE-SUSPECTE-2"
  //
  val TYPE_FRAUDE_SORTIE_ROUMANIE: String = "Sortie-Fond-Roumanie"

  // Cavalerie
  val CAVAL_SEUIL_ANCIENNETE_MOINS_EGAL_QUE: String = "735"
  val CAVAL_SEUIL_CUMUL_RMC_PLUS_EGAL_QUE: String = "1000"
  val CAVAL_SEUIL_MONTANT_PLUS_EGAL_QUE: String = "1000"
  val CAVAL_SEUIL_SOLDE_CUMUL_MOINS_EGAL_QUE: String = "-5000"
  val SAMEDI: String = "samedi"
  val DIMANCHE: String = "dimanche"
  val LUNDI: String = "lundi"

  // SortieFondRoumanie
  val SORTIE_FOND_ROUMANIE: String = "RO"
  val CHANGE_TEL_MAIL: String = "Tel-Mail-Changement"

  val CODE_FR: String = "FR"

  // Suspect sequence
  val CHANGE_TEL :String = "Changement-telephone"
  val CHANGE_MAIL :String = "Changement-adresse-mail"
  val AJOUT_IBAN :String = "Ajout-iban-externe"
  val NEW_MAIL :String = "Nouvelle adresse email"
  val NEW_TEL :String = "Nouveau numéro de téléphone"
  val OLD_MAIL :String = "Ancienne adresse email"
  val OLD_TEL :String = "Ancien numéro de téléphone"
  val SEQUENCE_SEUIL_MONTANT_PLUS_EGAL_QUE: String = "2000"

  // Cavalerie Booster
  val CAVAL_BOOST_SEUIL_ANCIENNETE_MOINS_EGAL_QUE: String = "735"
  val CAVAL_BOOST_SEUIL_CUMUL_RMC_PLUS_EGAL_QUE: String = "1000"
  val CAVAL_BOOST_SEUIL_MONTANT_PLUS_EGAL_QUE: String = "0"
  val CAVAL_BOOST_SEUIL_SOLDE_CUMUL_MOINS_EGAL_QUE: String = "0"

  // INTERNE
  val AUDIT_INTERNE_CLIENT_VIP: String = "634910918,115173,613,3190601494,5713240638,582"
  val AUDIT_INTERNE_CLIENT_COMEX: String = "634910918,115173,613,3190601494,5713240638,582"
  val AUDIT_INTERNE_HEURE_SUSPECTE_PLUS_EGAL_QUE: String = "22"
  val AUDIT_INTERNE_HEURE_SUSPECTE_MOINS_EGAL_QUE: String = "5"

  val FILTERED_TRANSFER_OPERATIONS = List("OTRANSFR", "ODEMEARV")

  // Fond entrant
  val MULTIPLE_TRANSACTION_EXT_PERSON_OUT: String = "EXTERNE-MULTIPLE-TRANSACTION-SORTANTE"
  val MULTIPLE_TRANSACTION_EXT_PERSON_IN: String = "EXTERNE-MULTIPLE-TRANSACTION-ENTRANTE"
  val MULTIPLE_TRANSACTION_EXT_PERSON_IN_OUT: String = "EXTERNE-MULTIPLE-TRANSACTION-ENTRANTE-SORTANTE"

  val NBR_VIR_DESTINATION_MEME: String = "5"
  val SEUIL_CUMUL_DESTINATION: String = "5000"
  val RIB_SOURCE_DESTINATION_DIFF: String = "True"
  val NBR_VIR_PROVENANCE_MEME: String = "2"
  val SEUIL_CUMUL_PROVENANCE: String = "3000"
  val SEUIL_CUMUL_DESTINATION_EGALE_SEUIL_CUMULE_PROVENANCE: String = "True"

  val ATOS_SUCCESSFULL_IDENTIFICATION = "successfull identification"
  val ATOS_FAILURE_IDENTIFICATION = "invalid password or user authentification is false"
  val SUSPECT_CONNECTION_COUNTRIES = List("CU", "IR", "LY", "SS", "SD", "SY", "UA", "BW", "BN", "GT", "MH", "NR", "NU", "PA", "TR")
  val SUSPECT_SEQUENCE_SERVICES = List("monprofil.CONTACT_MANAGEMENT/MODIFY_TEL_NUMBER", "AJOUTER_BICIBAN_EXTERNE")
  val IBAN_CHANGED = "IBAN_CHANGED"
  val TEL_CHANGED = "TEL_CHANGED"

  val CODE_BOURSORAMA = "FR7640618"
  val IBAN_CIBLE_E_VIE = "FR7630003030100006735265132"

  val VALID_STATUS = Map[String, Int](
    "UNKNOWN" -> 0,
    "VALID" -> 1,
    "UNVALID" -> 2)

  val CONSUMER_TREADS_PER_UNPUT_DSTREAM = 8

  val addressMap = Map[String, Array[InternetAddress]](
    TYPE_FRAUDE_EXT_CAVALERIE -> AppConf.RecipientRisqueMail,
    TYPE_FRAUDE_EXT_CAVALERIE_BOOSTER -> AppConf.RecipientRisqueMail,
    TYPE_FRAUDE_EXT_PAYS_SUSPECT -> AppConf.RecipientRisqueMail,
    TYPE_FRAUDE_SORTIE_ROUMANIE -> AppConf.RecipientRisqueMail,
    TYPE_FRAUDE_EXT_SEQUENCE_SUSPECTE -> AppConf.RecipientRisqueMail,
    TYPE_FRAUDE_EXT_EMBARGO_3_SEMAINES -> AppConf.RecipientConformiteMail,
    TYPE_FRAUDE_EXT_EMBARGO -> AppConf.RecipientConformiteMail,
    TYPE_FRAUDE_EXT_SEQUENCE_SUSPECTE_2 -> AppConf.RecipientRisqueMail)
}
