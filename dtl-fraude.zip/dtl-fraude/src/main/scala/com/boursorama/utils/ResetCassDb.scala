package com.boursorama.utils

import com.boursorama.cassandra.CassandraInitTablespace

object ResetCassDb extends Serializable {

  def main(args: Array[String]) : Unit = {
    CassandraInitTablespace.initKeyspaces
    CassandraInitTablespace.initTables
    CassandraInitTablespace.initData
  }
}
