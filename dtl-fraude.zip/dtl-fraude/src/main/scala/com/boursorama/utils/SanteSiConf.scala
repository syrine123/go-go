package com.boursorama.utils

import com.typesafe.config.ConfigFactory

object SanteSiConf extends Serializable {

  val conf = ConfigFactory.load("sante_si.conf")

    val EsDebianNodes = conf.getString("EsDebianNode")
    val EsDebianPort = conf.getString("EsDebianPort")

}
