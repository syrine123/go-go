package com.boursorama.utils

import javax.mail.internet.InternetAddress
import com.typesafe.config.ConfigFactory
import scala.util.Properties
import java.io.File

object AppConf extends Serializable {

  val fileInfra = sys.env("BRS_SPARK_ENV_CONF")
  
  val confInfra = ConfigFactory.parseFile(new File(fileInfra))
  
  val conf = ConfigFactory.load("application.conf")

  val SparkCisCheckpointDirectory = conf.getString("SparkCisCheckpointDirectory")
  val SparkAtosCheckpointDirectory = conf.getString("SparkAtosCheckpointDirectory")

  val SparkConcurrentJobs = conf.getString("SparkConcurrentJobs")

  val SenderMail = confInfra.getString("MAIL_FROM")
  val RecipientRisqueMail = conf.getString("RecipientRisqueMail").split(";").map(new InternetAddress(_))
  val RecipientConformiteMail = conf.getString("RecipientConformiteMail").split(";").map(new InternetAddress(_))

  val SmtpHost = confInfra.getString("SMTP_HOST")
  val SmtpPort = confInfra.getString("SMTP_PORT")

  val ProxyHttpHost = conf.getString("ProxyHttpHost")
  val ProxyHttpPort = conf.getString("ProxyHttpPort")

  val SparkBatchWindow = conf.getInt("SparkBatchWindow")

  val CassandraReplicationFactor = conf.getInt("CassandraReplicationFactor")
  val CassandraNodes = confInfra.getString("CASSANDRA_SERVERS")
  val CassandraUsername = confInfra.getString("CASSANDRA_LOGIN")
  val CassandraPassword = confInfra.getString("CASSANDRA_PASSWORD")
  val CassandraKeepAliveMs = conf.getString("CassandraKeepAliveMs")

  val EsNodes = confInfra.getString("ES_SERVERS")
  val EsPort = confInfra.getString("ES_PORT")
  val EsUsername = confInfra.getString("ES_LOGIN")
  val EsPassword = confInfra.getString("ES_PASSWORD")

  val CassandraReferentielKeySpace = conf.getString("CassandraReferentielKeySpace")
  val CassandraInternalRiskKeySpace = conf.getString("CassandraInternalRiskKeySpace")
  val CassandraExternalRiskKeySpace = conf.getString("CassandraExternalRiskKeySpace")
  val CassandraAuditDtlKeySpace = conf.getString("CassandraAuditDtlKeySpace")
  val CassandraReferentielValorizationKeySpace = conf.getString("CassandraReferentielValorizationKeySpace")

  val KafkaBroker = confInfra.getString("KAFKA_SERVERS")

  val zkQuorum = confInfra.getString("ZK_SERVERS")

  val KafkaTopicCis = conf.getString("KafkaTopicCis")
  val KafkaTopicAtos = conf.getString("KafkaTopicAtos")

  val cavalerieCaseWsUrl = conf.getString("cavalerieCaseWsUrl")
  val cavalerieCaseWsName = conf.getString("cavalerieCaseWsName")
  val cavalerieCaseWsContentType = conf.getString("cavalerieCaseWsContentType")
  val connTimeoutMs = conf.getString("connTimeoutMs")
  val readTimeoutMs = conf.getString("readTimeoutMs")

  // val NbThreadsPerKafkaTopic = conf.getString("NbThreadsPerKafkaTopic")

}
