package com.boursorama.spark.streaming.parser

import com.boursorama.cassandra.RejectionHandler._
import com.boursorama.dtl.business.Connection
import com.boursorama.utils.Constants._
import com.boursorama.utils.Conversion._
import org.joda.time.DateTime
import org.json4s.DefaultFormats
import org.json4s.jackson.JsonMethods._

import scala.util.{ Failure, Success, Try }
import scala.Ordered._

/**
 * Created by ubuntu on 23/05/17.
 */
class ConnectionParser {

  @transient lazy val logger = org.apache.log4j.LogManager.getLogger("ConnectionParser")

  def cleanActionLine(line: String): String = line match {
    case s if s.length() > 0 => line
    case _                   => "-"
  }

  def getClientId(line: String): Option[Long] = {
    Try(line.toLong) match {
      case Success(v) => Some(v)
      case Failure(v) => None
    }
  }

  def parseLine(logLine: String): Option[Connection] = {

    try {
      implicit val formats = DefaultFormats
      val json = parse(logLine)

      val libelleOperation = cleanActionLine((json \ "Information").extractOpt[String].getOrElse(EmptyStringField))
      val clientId = getClientId((json \ "UserID").extractOpt[String].getOrElse(EmptyStringField))

      if (clientId.getOrElse(EmptyLongField) == -1 &&
        (libelleOperation == ATOS_SUCCESSFULL_IDENTIFICATION || libelleOperation == ATOS_FAILURE_IDENTIFICATION)) {
        val managerId = (json \ "ManagerID").extractOpt[String].getOrElse(EmptyStringField) // Can be the user or the client
        val rawTimestamp = (json \ "@timestamp").extractOpt[String].getOrElse("-")
        val timestamp = DateTime.parse(rawTimestamp)
        val anneeMois = getYearMonth(timestamp)
        val idDimTemps = getYearMonthDay(timestamp)
        val country = ((json \\ "geoip") \ "country_name").extractOpt[String].getOrElse(EmptyStringField)
        val country_code = ((json \\ "geoip") \ "country_code2").extractOpt[String].getOrElse(EmptyStringField)
        val coords = ((json \\ "geoip") \ "location").extractOpt[Array[Double]].orNull
        val ipAdress = (json \ "IP Adress").extractOpt[String].getOrElse(EmptyStringField)
        val nomClient = EmptyStringField
        val prenomClient = EmptyStringField
        val type_fraude = "Aucun"
        val honeyPot = "Non"

        if (getClientId(managerId) < Some(10100000) && getClientId(managerId) > Some(9999999)) {
          //Tous les ID commençant par 100 suivi de 0 à 9  et qui sont sur 8 caractères
          val honeyPot = "Oui"
        }

        Some(Connection(
          managerId.toLong,
          anneeMois,
          idDimTemps,
          timestamp,
          EmptyLongField,
          logLine,
          country,
          country_code,
          ipAdress,
          coords,
          type_fraude,
          libelleOperation,
          honeyPot
        ))
      } else {
        None
      }
    } catch {
      case e: Throwable => {
        //handleRejection(FluxAtos, PARSING_ERROR, e.toString + " => " + e.getStackTrace.mkString("||"), EmptyStringField, logLine)
        logger.debug(FluxAtos, PARSING_ERROR, e.toString + " => " + e.getStackTrace.mkString("||"), EmptyStringField, logLine)
        None
      }
    }
  }
}

object ConnectionParser extends ConnectionParser
