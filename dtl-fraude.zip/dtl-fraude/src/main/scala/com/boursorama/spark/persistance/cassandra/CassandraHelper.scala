package com.boursorama.spark.persistance.cassandra

import org.apache.spark.streaming.dstream.DStream
import com.boursorama.cassandra.CassandraClient
import com.boursorama.cassandra.RejectionHandler.NONE_VALUE
import com.boursorama.cassandra.RejectionHandler.handleRejection
import com.boursorama.dtl.business._
import com.boursorama.dtl.business.cassandra.{ ConnectionCassDto, SortieFondCassDto, SortieFondSuspectCassDto }
import com.boursorama.utils.AppConf
import com.boursorama.utils.Constants.EmptyStringField
import com.boursorama.utils.Conversion.getDateTime
import com.datastax.driver.core.LocalDate
import com.datastax.spark.connector.streaming.toDStreamFunctions

object CassandraHelper extends Serializable {

  @transient lazy val logger = org.apache.log4j.LogManager.getLogger("CassandraHelper")

  val emptyClientDateEntryRelation = getDateTime(0)
  val emptyClient = Client(-1, -1, Some(emptyClientDateEntryRelation), -1, -1, -1)

  def persisteSortieFond(sortieFondDStream: DStream[SortieFond]): Unit = {
    sortieFondDStream
      .flatMap(sortieFond => mapToDto(sortieFond))
      .saveToCassandra(AppConf.CassandraExternalRiskKeySpace, "sortie_fond")
  }

  def mapToDto(sortieFond: SortieFond): Option[SortieFondCassDto] = {

    try {
      Some(new SortieFondCassDto(
        sortieFond.sys_origine,
        sortieFond.annee_mois,
        sortieFond.id_dim_temps,
        sortieFond.date_operation,
        sortieFond.id_transaction,
        sortieFond.id_web,
        sortieFond.adresse_ip,
        sortieFond.montant,
        sortieFond.status,
        sortieFond.error_message,
        sortieFond.code_operation,
        sortieFond.iban_source,
        sortieFond.iban_cible,
        sortieFond.code_pays_cible,
        sortieFond.client.getOrElse(emptyClient).contact_id,
        sortieFond.client.getOrElse(emptyClient).date_entree_relation.get,
        sortieFond.client.getOrElse(emptyClient).encours,
        sortieFond.client.getOrElse(emptyClient).mt_cumule_rc,
        sortieFond.client.getOrElse(emptyClient).nombre_rc,
        sortieFond.solde_previsionnel,
        sortieFond.log))
    } catch {
      case e: java.util.NoSuchElementException =>
        //handleRejection(sortieFond.sys_origine, NONE_VALUE, e.toString + " => " + e.getStackTrace.mkString("||"), EmptyStringField, sortieFond.log)
        logger.debug(sortieFond.sys_origine, NONE_VALUE, e.toString + " => " + e.getStackTrace.mkString("||"), EmptyStringField, sortieFond.log)
        None
    }
  }

  def persisteSortieFondSuspect(sortieFondSuspectDStream: DStream[SortieFondSuspect]): Unit = {
    sortieFondSuspectDStream
      .map(sortieFondSuspect => mapToDto(sortieFondSuspect))
      .saveToCassandra(AppConf.CassandraExternalRiskKeySpace, "sortie_fond_suspect")
  }

  def mapToDto(sortieFondSuspect: SortieFondSuspect): SortieFondSuspectCassDto = {
    new SortieFondSuspectCassDto(
      sortieFondSuspect.sys_origine,
      sortieFondSuspect.annee_mois,
      sortieFondSuspect.id_dim_temps,
      sortieFondSuspect.date_operation,
      sortieFondSuspect.id_transaction,
      sortieFondSuspect.id_web,
      sortieFondSuspect.adresse_ip,
      sortieFondSuspect.montant,
      sortieFondSuspect.code_operation,
      sortieFondSuspect.iban_source,
      sortieFondSuspect.iban_cible,
      sortieFondSuspect.code_pays_cible,
      sortieFondSuspect.client.getOrElse(emptyClient).contact_id,
      sortieFondSuspect.client.getOrElse(emptyClient).date_entree_relation.get,
      sortieFondSuspect.client.getOrElse(emptyClient).encours,
      sortieFondSuspect.client.getOrElse(emptyClient).mt_cumule_rc,
      sortieFondSuspect.client.getOrElse(emptyClient).nombre_rc,
      sortieFondSuspect.solde_previsionnel,
      sortieFondSuspect.type_fraude,
      sortieFondSuspect.param_fraude.toString(),
      sortieFondSuspect.valide_statut_fraude,
      sortieFondSuspect.valide_username_fraude,
      sortieFondSuspect.valide_date_fraude
      )
  }

  def persisteConnection(connectionDStream: DStream[Connection]): Unit = {
    connectionDStream
      .map(connection => mapToDto(connection))
      .saveToCassandra(AppConf.CassandraExternalRiskKeySpace, "connexion")
  }

  def mapToDto(connection: Connection): ConnectionCassDto = {
    new ConnectionCassDto(
      connection.id_web,
      connection.annee_mois,
      connection.id_dim_temps,
      connection.timestamp,
      connection.contact_id,
      connection.log,
      connection.pays,
      connection.code_pays,
      connection.ip,
      connection.type_fraude,
      connection.libelleOperation,
      connection.honeyPot)
  }

  def getFraudeParams(fraudeType: String): Option[FraudeParams] = {
    CassandraClient.getFraudeParams(fraudeType)
  }

  def getTodayClientSumSortieFondMontant(idWeb: Long): Double = {
    CassandraClient.getTodayClientSumSortieFondMontant(idWeb)
  }

  def getTodayClientSumSortieFondMontantJ_1(idWeb: Long): Double = {
    CassandraClient.getTodayClientSumSortieFondMontantJ_1(idWeb)
  }

  def getTodayClientSumSortieFondMontantJ_2(idWeb: Long): Double = {
    CassandraClient.getTodayClientSumSortieFondMontantJ_2(idWeb)
  }

  def getTodayClientSumSortieFondMontantJ_3(idWeb: Long): Double = {
    CassandraClient.getTodayClientSumSortieFondMontantJ_3(idWeb)
  }

  def getLastMonthClientSumSortieFondTiers(idWeb: Long, iban_cible: String): Double = {
    CassandraClient.getLastMonthClientSumSortieFondTiers(idWeb, iban_cible)
  }

  def getLast3MonthsClientSumSortieFondTiers(idWeb: Long, iban_cible: String): Double = {
    CassandraClient.getLast3MonthsClientSumSortieFondTiers(idWeb, iban_cible)
  }

  def getLastMonthClientSortieFondTiers(idWeb: Long, iban_cible: String): (Long, Double) = {
    CassandraClient.getLastMonthClientSortieFondTiers(idWeb, iban_cible)
  }

  def getLastMonthClientEntreeFondTiers(idWeb: Long, iban_cible: String): Long = {
    CassandraClient.getLastMonthClientEntreeFondTiers(idWeb, iban_cible)
  }

  def getCountMailsChangesDaysBeforePerIdWeb(idWeb: Long, duration: Int): Long = {
    CassandraClient.getCountMailsChangeDaysBeforeIdWeb(idWeb, duration)
  }

  def getCountTelsChangesDaysBeforePerIdWeb(idWeb: Long, duration: Int): Long = {
    CassandraClient.getCountTelsChangeDaysBeforePerIdWeb(idWeb, duration)
  }

  def getCountMailsChangesDaysBeforePerIdContact(idContact: Long, duration: Int): Long = {
    CassandraClient.getCountMailsChangeDaysBeforePerIdContact(idContact, duration)
  }

  def getCountTelsChangesDaysBeforePerIdContact(idContact: Long, duration: Int): Long = {
    CassandraClient.getCountTelsChangeDaysBeforePerIdContact(idContact, duration)
  }

  def getNumContratClient(idWeb: Long): List[String] = {
    CassandraClient.getNumContratClient(idWeb)
  }

  def getAllPaysSuspectsFlagBlanchiment: Option[List[String]] = {
    CassandraClient.getAllPaysSuspectsFlagBlanchiment
  }

  def getAllPaysSuspectsFlagEmbargo: Option[List[String]] = {
    CassandraClient.getAllPaysSuspectsFlagEmbargo
  }

  def getAllPaysSuspectsFlagNonCooperatif: Option[List[String]] = {
    CassandraClient.getAllPaysSuspectsNonCooperatif
  }

  def getClientInformationByKey(clientId: Long): Option[Client] = {
    CassandraClient.getClientInformationByKey(clientId)
  }

  def getSuspectConnectionsInLast3Weeks(id_web: Long): Boolean = {
    CassandraClient.getSuspectConnectionsInLast3Weeks(id_web)
  }

  def getClientSumSortieFondMontant(id_web: Long, previousDay: Int): Double = {
    CassandraClient.getClientSumSortieFondMontant(id_web, previousDay)
  }

  def getIbanAddInPreviousDay(idWeb: Long, idContact: Long, previousDay: Int, ibanCible: String): Integer = {
    CassandraClient.getIbanAddInPreviousDay(idWeb, idContact, previousDay, ibanCible)
  }

  def getDateMailChangeDaysBefore(idWeb: Long, idContact: Long, dateAddIban: Integer, duration: Int): (Integer, String, String) = {
    CassandraClient.getDateMailChangeDaysBefore(idWeb, idContact, dateAddIban, duration)
  }

  def getDateTelChangeDaysBefore(idWeb: Long, idContact: Long, dateAddIban: Integer, duration: Int): (Integer, String, String) = {
    CassandraClient.getDateTelChangeDaysBefore(idWeb, idContact, dateAddIban, duration)
  }

}
