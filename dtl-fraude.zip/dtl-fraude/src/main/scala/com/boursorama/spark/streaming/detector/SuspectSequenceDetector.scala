package com.boursorama.spark.streaming.detector

import com.boursorama.dtl.business.{ SortieFond, SortieFondSuspect }
import com.boursorama.spark.persistance.cassandra.CassandraHelper
import com.boursorama.utils.Constants._
import com.boursorama.utils.Conversion.{ formatDate, addDaysDate }
import com.boursorama.utils.Conversion.ParisTimeZone
import com.datastax.driver.core.LocalDate
import com.boursorama.utils.Conversion
import scala.collection.mutable
import org.joda.time.DateTime

class SuspectSequenceDetector extends Serializable {

  val refreshDelaySec: Long = 300l // every 5min
  var lastRefrech = 0L
  var cachedParamsMap = Map[String, String](
    "seuilMontantPlusEgalQue" -> SEQUENCE_SEUIL_MONTANT_PLUS_EGAL_QUE,
    CHANGE_TEL -> "",
    CHANGE_MAIL -> "",
    AJOUT_IBAN -> "",
    OLD_MAIL -> "",
    OLD_TEL -> "",
    NEW_MAIL -> "",
    NEW_TEL -> "")

  /**
   * getFraudeParamsFromDb allows to get the params fraude of suspect sequence
   * @return map of fraude params
   */
  def getFraudeParamsFromDb(type_fraude: String): Map[String, String] = {
    val option = CassandraHelper.getFraudeParams(type_fraude)
    option match {
      case None               => Map()
      case Some(fraudeParams) => fraudeParams.params
    }
  }

  def getFraudeParams(type_fraude: String): Map[String, String] = {
    if (lastRefrech + refreshDelaySec * 1000 < System.currentTimeMillis()) {
      val fraudeParams = getFraudeParamsFromDb(type_fraude)
      val newParamsMap = mutable.Map[String, String]()
      newParamsMap.put("seuilMontantPlusEgalQue", fraudeParams.getOrElse("seuilMontantPlusEgalQue", SEQUENCE_SEUIL_MONTANT_PLUS_EGAL_QUE))
      cachedParamsMap = newParamsMap.toMap
      lastRefrech = System.currentTimeMillis()
    }
    cachedParamsMap
  }

  /**
    * suspect allows to get suspect sequence (mail or tel changes and add external iban)
    * @param sortieFond
    * @return SortieFondSuspect
    */
  def suspect(sortieFond: SortieFond): Option[SortieFondSuspect] = {
    val clientOpt = sortieFond.client
    if (clientOpt == None) {
      None
    } else {
      val client = clientOpt.get
      var paramsMap: Map[String, String] = getFraudeParams(TYPE_FRAUDE_EXT_SEQUENCE_SUSPECTE)
      paramsMap += (CHANGE_TEL -> "")
      paramsMap += (CHANGE_MAIL -> "")
      paramsMap += (AJOUT_IBAN -> "")
      paramsMap += (OLD_MAIL -> "")
      paramsMap += (OLD_TEL -> "")
      paramsMap += (NEW_MAIL -> "")
      paramsMap += (NEW_TEL -> "")
      println(paramsMap.toString)
      val seuil_virement = paramsMap.getOrElse("seuilMontantPlusEgalQue", SEQUENCE_SEUIL_MONTANT_PLUS_EGAL_QUE).toDouble

      // recuperation des virements des 4 derniers jours. Quelques soit l'IBAN cible
      val previousDay = Conversion.getPreviousDaysDate(5)

      val sumMontant = CassandraHelper.getClientSumSortieFondMontant(client.id_web, previousDay)

      // si cumul plus grand que seuil
      if (sumMontant >= seuil_virement) {
        // recuperation de la date d'ajout de l'iban dans les 4 derniers jours
        val dateAjoutIban = CassandraHelper.getIbanAddInPreviousDay(client.id_web, client.contact_id, previousDay, sortieFond.iban_cible)
        if (dateAjoutIban != -1) {
          var date_format_add_iban = formatDate(dateAjoutIban)
          paramsMap += (AJOUT_IBAN -> date_format_add_iban)

          var date_format_mail_tel: String = ""
          // recuperation de la date de changement de l'email entre la date d'ajout de l'iban et 4 jours avant
          val dateChangeMail = CassandraHelper.getDateMailChangeDaysBefore(client.id_web, client.contact_id, dateAjoutIban, 5)._1
          val oldMail = CassandraHelper.getDateMailChangeDaysBefore(client.id_web, client.contact_id, dateAjoutIban, 5)._2
          val newMail = CassandraHelper.getDateMailChangeDaysBefore(client.id_web, client.contact_id, dateAjoutIban, 5)._3
          if (dateChangeMail != -1) {
            date_format_mail_tel = formatDate(dateChangeMail)
            paramsMap += (CHANGE_MAIL -> date_format_mail_tel)
            paramsMap += (OLD_MAIL -> oldMail)
            paramsMap += (NEW_MAIL -> newMail)
          }
          // recuperation de la date de changement du telephone entre la date d'ajout de l'iban et 4 jours avant
          val dateChangeTel = CassandraHelper.getDateTelChangeDaysBefore(client.id_web, client.contact_id, dateAjoutIban, 5)._1
          val oldTel = CassandraHelper.getDateTelChangeDaysBefore(client.id_web, client.contact_id, dateAjoutIban, 5)._2
          val newTel = CassandraHelper.getDateTelChangeDaysBefore(client.id_web, client.contact_id, dateAjoutIban, 5)._3
          if (dateChangeTel != -1) {
            date_format_mail_tel = formatDate(dateChangeTel)
            paramsMap += (CHANGE_TEL -> date_format_mail_tel)
            paramsMap += (OLD_TEL -> oldTel)
            paramsMap += (NEW_TEL -> newTel)
          }

          if (dateChangeMail != -1 || dateChangeTel != -1) {
            Some(
              new SortieFondSuspect(
                sortieFond.sys_origine,
                sortieFond.annee_mois,
                sortieFond.id_dim_temps,
                sortieFond.date_operation,
                sortieFond.id_transaction,
                sortieFond.id_web,
                sortieFond.adresse_ip,
                sortieFond.montant,
                sortieFond.error_message,
                sortieFond.code_operation,
                sortieFond.banque_source,
                sortieFond.agence_source,
                sortieFond.compte_source,
                sortieFond.cle_rib_source,
                sortieFond.iban_source,
                sortieFond.iban_cible,
                sortieFond.code_pays_cible,
                sortieFond.client,
                sortieFond.solde_previsionnel,
                TYPE_FRAUDE_EXT_SEQUENCE_SUSPECTE,
                paramsMap,
                VALID_STATUS("UNKNOWN"),
                EmptyStringField,
                DateTime.now()))
          } else {
            None
          }
        } else {
          None
        }
      } else {
        None
      }
    }
  }

  /**
    * suspect2 allows to get suspect sequence 2 (tel and mail changed and add external iban)
    * @param sortieFond
    * @return SortieFondSuspect
    */
  def suspect2(sortieFond: SortieFond): Option[SortieFondSuspect] = {
    val clientOpt = sortieFond.client
    if (clientOpt == None) {
      None
    } else {
      val client = clientOpt.get
      var paramsMap: Map[String, String] = getFraudeParams(TYPE_FRAUDE_EXT_SEQUENCE_SUSPECTE)
      paramsMap += (CHANGE_TEL -> "")
      paramsMap += (CHANGE_MAIL -> "")
      paramsMap += (AJOUT_IBAN -> "")
      paramsMap += (OLD_MAIL -> "")
      paramsMap += (OLD_TEL -> "")
      paramsMap += (NEW_MAIL -> "")
      paramsMap += (NEW_TEL -> "")
      println(paramsMap.toString)
      val seuil_virement = paramsMap.getOrElse("seuilMontantPlusEgalQue", SEQUENCE_SEUIL_MONTANT_PLUS_EGAL_QUE).toDouble

      // recuperation des virements des 4 derniers jours. Quelques soit l'IBAN cible
      val previousDay = Conversion.getPreviousDaysDate(5)

      val sumMontant = CassandraHelper.getClientSumSortieFondMontant(client.id_web, previousDay)

      // si cumul plus grand que seuil
      if (sumMontant >= seuil_virement) {
        // recuperation de la date d'ajout de l'iban dans les 4 derniers jours
        val dateAjoutIban = CassandraHelper.getIbanAddInPreviousDay(client.id_web, client.contact_id, previousDay, sortieFond.iban_cible)
        if (dateAjoutIban != -1) {
          var date_format_add_iban = formatDate(dateAjoutIban)
          paramsMap += (AJOUT_IBAN -> date_format_add_iban)

          var date_format_mail_tel: String = ""
          // recuperation de la date de changement de l'email entre la date d'ajout de l'iban et 4 jours avant
          val dateChangeMail = CassandraHelper.getDateMailChangeDaysBefore(client.id_web, client.contact_id, dateAjoutIban, 5)._1
          val oldMail = CassandraHelper.getDateMailChangeDaysBefore(client.id_web, client.contact_id, dateAjoutIban, 5)._2
          val newMail = CassandraHelper.getDateMailChangeDaysBefore(client.id_web, client.contact_id, dateAjoutIban, 5)._3
          if (dateChangeMail != -1) {
            date_format_mail_tel = formatDate(dateChangeMail)
            paramsMap += (CHANGE_MAIL -> date_format_mail_tel)
            paramsMap += (OLD_MAIL -> oldMail)
            paramsMap += (NEW_MAIL -> newMail)
          }
          // recuperation de la date de changement du telephone entre la date d'ajout de l'iban et 4 jours avant
          val dateChangeTel = CassandraHelper.getDateTelChangeDaysBefore(client.id_web, client.contact_id, dateAjoutIban, 5)._1
          val oldTel = CassandraHelper.getDateTelChangeDaysBefore(client.id_web, client.contact_id, dateAjoutIban, 5)._2
          val newTel = CassandraHelper.getDateTelChangeDaysBefore(client.id_web, client.contact_id, dateAjoutIban, 5)._3
          if (dateChangeTel != -1) {
            date_format_mail_tel = formatDate(dateChangeTel)
            paramsMap += (CHANGE_TEL -> date_format_mail_tel)
            paramsMap += (OLD_TEL -> oldTel)
            paramsMap += (NEW_TEL -> newTel)
          }

          if (dateChangeMail != -1 && dateChangeTel != -1) {
            Some(
              new SortieFondSuspect(
                sortieFond.sys_origine,
                sortieFond.annee_mois,
                sortieFond.id_dim_temps,
                sortieFond.date_operation,
                sortieFond.id_transaction,
                sortieFond.id_web,
                sortieFond.adresse_ip,
                sortieFond.montant,
                sortieFond.error_message,
                sortieFond.code_operation,
                sortieFond.banque_source,
                sortieFond.agence_source,
                sortieFond.compte_source,
                sortieFond.cle_rib_source,
                sortieFond.iban_source,
                sortieFond.iban_cible,
                sortieFond.code_pays_cible,
                sortieFond.client,
                sortieFond.solde_previsionnel,
                TYPE_FRAUDE_EXT_SEQUENCE_SUSPECTE_2,
                paramsMap,
                VALID_STATUS("UNKNOWN"),
                EmptyStringField,
                DateTime.now()))
          } else {
            None
          }
        } else {
          None
        }
      } else {
        None
      }
    }
  }

}

object SuspectSequenceDetector extends SuspectSequenceDetector
