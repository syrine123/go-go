package com.boursorama.spark.streaming.pipeline

import com.boursorama.dtl.business._
import com.boursorama.spark.persistance.cassandra.CassandraHelper
import com.boursorama.spark.persistance.es.EsHelper
import com.boursorama.spark.streaming.detector.SuspectConnectionDetector
import org.apache.spark.streaming.dstream.DStream
import com.boursorama.spark.streaming.notifier.{ ConnexionSuspectMailNotifier, SuspectNotifier }

trait ConnectionPipeline extends Pipeline {

  def processConnection(connectionDStream: DStream[Connection]): Unit = {

    val enrichedConnectionDStream = enrichConnection(connectionDStream)

    enrichedConnectionDStream.persist(getStorageLevel)

    val detectedConnectionDStream = detectSuspectConnection(enrichedConnectionDStream)

    detectedConnectionDStream.persist(getStorageLevel)

    persistConnection(detectedConnectionDStream)

    notifyConnexionSuspect(detectedConnectionDStream)
  }

  /*
   Parsing
   */

  def parseToConnection(logDStream: DStream[String]): DStream[Connection] = {
    logDStream.flatMap(log => parseToConnection(log))
  }

  def parseToConnection: String => Option[Connection]

  /*
  Enriching
   */

  def enrichConnection(connectionDStream: DStream[Connection]): DStream[Connection] = {
    connectionDStream
      .flatMap(Connection => enrichWithClientInfo(Connection))
  }

  def enrichWithClientInfo(connection: Connection): Option[Connection] = {
    getClientInformation(connection.id_web) match {
      case Some(client) => Some(connection.copy(contact_id = client.contact_id))
      case _ => Some(connection.copy())
    }
  }

  /*
  Detecting
   */

  def detectSuspectConnection(enrichedConnectionDStream: DStream[Connection]): DStream[Connection] = {
    enrichedConnectionDStream.flatMap(connection => detectSuspectConnection(connection))
  }

  def detectSuspectConnection(connection: Connection): Option[Connection] = {
    SuspectConnectionDetector.detectEmbargo(connection)
  }

  /*
  Persisting
   */

  def persistConnection(connectionDStream: DStream[Connection]): Unit = {
    CassandraHelper.persisteConnection(connectionDStream)
    EsHelper.persisteConnection(connectionDStream)
  }

  /*
  Mailing
   */
  val mailNotifier: SuspectNotifier[Connection] = ConnexionSuspectMailNotifier

  def notifyConnexionSuspect(connectionDStream: DStream[Connection]): Unit = {
    mailNotifier.notify(connectionDStream)
  }
}


