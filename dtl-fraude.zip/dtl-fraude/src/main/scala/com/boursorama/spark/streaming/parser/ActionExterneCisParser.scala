package com.boursorama.spark.streaming.parser

import org.json4s.DefaultFormats
import org.json4s.jackson.JsonMethods.parse
import com.boursorama.cassandra.RejectionHandler
import RejectionHandler._
import com.boursorama.dtl.business.SortieFond
import com.boursorama.utils.Constants.EmptyStringField
import com.boursorama.utils.Constants.FILTERED_TRANSFER_OPERATIONS
import com.boursorama.utils.Conversion.getYearMonth
import com.boursorama.utils.Conversion.getYearMonthDay


class ActionExterneCisParser extends ActionExterneParser[SortieFond] {

  @transient lazy val logger = org.apache.log4j.LogManager.getLogger("ActionExterneCisParser")

  override def parseLine(logLine: String): Option[SortieFond] = {
    val sysOrigine = "CIS"
    try {
      implicit val formats = DefaultFormats
      val json = parse(logLine)
      val codeOper = (json \ "COD OPER").extractOpt[String].getOrElse(EmptyStringField)

      if (FILTERED_TRANSFER_OPERATIONS.contains(codeOper)) {
        val year = (json \ "ANN DEBUT").extractOpt[String].getOrElse("")
        val month = (json \ "MOI DEBUT").extractOpt[String].getOrElse("")
        val day = (json \ "JOU DEBUT").extractOpt[String].getOrElse("")
        val time = (json \ "HEU DEBUT").extractOpt[String].getOrElse("")
        val idWebStr: String = (json \ "COD UTI SFW").extractOpt[String].getOrElse((json \ "COD UTI").extractOpt[String].get)
        val montantStr: String = (json \ "MTT OP").extractOpt[String].getOrElse("0")
        val timestamp = CisParserHelper.makeTimestampFromCIS(year, month, day, time)
        val anneeMois = getYearMonth(timestamp)
        val idDimTemps = getYearMonthDay(timestamp)
        Some(
          SortieFond(
            sysOrigine,
            anneeMois,
            idDimTemps,
            timestamp,
            (json \ "ID TRANSAC").extractOpt[String].getOrElse("-"),
            idWebStr.toLong,
            (json \ "ID IP").extractOpt[String].getOrElse("-"),
            montantStr.toDouble,
            EmptyStringField, //(json \ "Status").extractOpt[String].getOrElse("-"),
            EmptyStringField, //(json \ "error message").extractOpt[String].getOrElse("-"),
            codeOper,
            (json \ "COD BQE OP").extractOpt[String].getOrElse("-"),
            (json \ "COD AGE OP").extractOpt[String].getOrElse("-"),
            (json \ "NUM CON OP").extractOpt[String].getOrElse("-"),
            (json \ "DEV CON OP").extractOpt[String].getOrElse("-"),
            (json \ "COD BQE OP").extractOpt[String].getOrElse("-") + (json \ "COD AGE OP").extractOpt[String].getOrElse("-") + (json \ "NUM CON OP").extractOpt[String].getOrElse("-") + (json \ "DEV CON OP").extractOpt[String].getOrElse("-"),
            (json \ "INFO OPER2").extractOpt[String].getOrElse("-"),
            (json \ "codePaysCible").extractOpt[String].getOrElse("-"),
            None,
            0,
            logLine))
      } else {
        None
      }
    } catch {
      case e: Throwable => {
        //handleRejection(sysOrigine, PARSING_ERROR, e.toString + " => " + e.getStackTrace.mkString("||"), EmptyStringField, logLine)
        logger.debug(sysOrigine, PARSING_ERROR, e.toString + " => " + e.getStackTrace.mkString("||"), EmptyStringField, logLine)
        None
      }
    }
  }
}

object ActionExterneCisParser extends ActionExterneCisParser

