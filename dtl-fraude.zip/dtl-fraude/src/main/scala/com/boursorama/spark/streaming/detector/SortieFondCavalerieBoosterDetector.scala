package com.boursorama.spark.streaming.detector

import java.util.Date
import java.util.concurrent.TimeUnit
import org.joda.time.DateTime

import com.boursorama.dtl.business.{SortieFond, SortieFondSuspect}
import com.boursorama.spark.persistance.cassandra.CassandraHelper
import com.boursorama.utils.Constants._

import scala.collection.mutable
import scala.util.Try

class SortieFondCavalerieBoosterDetector extends Serializable{

  val refreshDelaySec: Long = 300l // every 5min
  var lastRefrech = 0L
  var cachedParamsMap = Map[String, String](
    "seuilAncienneteMoinsEgalQue" -> CAVAL_BOOST_SEUIL_ANCIENNETE_MOINS_EGAL_QUE,
    "seuilCumulRmcPlusEgalQue" -> CAVAL_BOOST_SEUIL_CUMUL_RMC_PLUS_EGAL_QUE,
    "seuilMontantPlusEgalQue" -> CAVAL_BOOST_SEUIL_MONTANT_PLUS_EGAL_QUE,
    "seuilSoldeCumulMoinsEgalQue" -> CAVAL_BOOST_SEUIL_SOLDE_CUMUL_MOINS_EGAL_QUE)

  def getFraudeParamsFromDb(): Map[String, String] = {
    var option = CassandraHelper.getFraudeParams(TYPE_FRAUDE_EXT_CAVALERIE_BOOSTER)
    option match {
      case None => Map()
      case Some(fraudeParams) => fraudeParams.params
    }
  }

  def getFraudeParams() : Map[String, String] = {

    if (lastRefrech + refreshDelaySec*1000 < System.currentTimeMillis()) {
      val fraudeParams = getFraudeParamsFromDb()
      val newParamsMap = mutable.Map[String, String]()
      newParamsMap.put("seuilAncienneteMoinsEgalQue", fraudeParams.getOrElse("seuilAncienneteMoinsEgalQue", CAVAL_BOOST_SEUIL_ANCIENNETE_MOINS_EGAL_QUE))
      newParamsMap.put("seuilCumulRmcPlusEgalQue", fraudeParams.getOrElse("seuilCumulRmcPlusEgalQue", CAVAL_BOOST_SEUIL_CUMUL_RMC_PLUS_EGAL_QUE))
      newParamsMap.put("seuilMontantPlusEgalQue", fraudeParams.getOrElse("seuilMontantPlusEgalQue", CAVAL_BOOST_SEUIL_MONTANT_PLUS_EGAL_QUE))
      newParamsMap.put("seuilSoldeCumulMoinsEgalQue", fraudeParams.getOrElse("seuilSoldeCumulMoinsEgalQue", CAVAL_BOOST_SEUIL_SOLDE_CUMUL_MOINS_EGAL_QUE))
      cachedParamsMap = newParamsMap.toMap
      lastRefrech = System.currentTimeMillis()
    }
    cachedParamsMap
  }

  def suspect(sortieFond: SortieFond): Option[SortieFondSuspect] = {
    val clientOpt = sortieFond.client
    if (clientOpt == None) {
      None
    } else {
      val client = clientOpt.get
      val paramsMap = getFraudeParams()
      val seuilAnciennete = paramsMap.getOrElse("seuilAncienneteMoinsEgalQue", CAVAL_BOOST_SEUIL_ANCIENNETE_MOINS_EGAL_QUE).toLong
      val seuilCumulRc = paramsMap.getOrElse("seuilCumulRmcPlusEgalQue", CAVAL_BOOST_SEUIL_CUMUL_RMC_PLUS_EGAL_QUE).toLong
      val seuilMontant = paramsMap.getOrElse("seuilMontantPlusEgalQue", CAVAL_BOOST_SEUIL_MONTANT_PLUS_EGAL_QUE).toLong
      val seuilEncours = paramsMap.getOrElse("seuilSoldeCumulMoinsEgalQue", CAVAL_BOOST_SEUIL_SOLDE_CUMUL_MOINS_EGAL_QUE).toLong
      val anciennete: Long = Try(TimeUnit.DAYS.convert(new Date().getTime - client.date_entree_relation.get.toDate.getTime, TimeUnit.MILLISECONDS)).getOrElse(-1)
      var transactionBourso : Boolean = false

      if (sortieFond.iban_cible.contains(CODE_BOURSORAMA) || sortieFond.iban_cible.contains(IBAN_CIBLE_E_VIE)){
        transactionBourso = true
      }

      if (
          sortieFond.montant >= seuilMontant &&
          anciennete <= seuilAnciennete &&
          client.mt_cumule_rc >= seuilCumulRc &&
          client.encours - client.mt_cumule_rc - sortieFond.montant.toDouble <= seuilEncours &&
          transactionBourso == false
      ) {
        println(s"     - Sortie fond suspecte avec cas de cavalerie detectée ! - ${sortieFond.toString}")
        Some(
          new SortieFondSuspect(
            sortieFond.sys_origine,
            sortieFond.annee_mois,
            sortieFond.id_dim_temps,
            sortieFond.date_operation,
            sortieFond.id_transaction,
            sortieFond.id_web,
            sortieFond.adresse_ip,
            sortieFond.montant,
            sortieFond.error_message,
            sortieFond.code_operation,
            sortieFond.banque_source,
            sortieFond.agence_source,
            sortieFond.compte_source,
            sortieFond.cle_rib_source,
            sortieFond.iban_source,
            sortieFond.iban_cible,
            sortieFond.code_pays_cible,
            sortieFond.client,
            sortieFond.solde_previsionnel,
            TYPE_FRAUDE_EXT_CAVALERIE_BOOSTER,
            paramsMap,
            VALID_STATUS("UNKNOWN"),
            EmptyStringField,
            DateTime.now()
          )
        )
      } else
        None
    }
  }
}

object SortieFondCavalerieBoosterDetector extends SortieFondCavalerieBoosterDetector
