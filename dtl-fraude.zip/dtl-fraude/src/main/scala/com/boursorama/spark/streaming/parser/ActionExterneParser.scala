package com.boursorama.spark.streaming.parser

trait ActionExterneParser[T] {

  def parseLine(logLine: String): Option[T]

}
