package com.boursorama.spark.streaming.pipeline

import com.boursorama.dtl.business.Client
import com.boursorama.spark.persistance.cassandra.CassandraHelper
import com.boursorama.spark.streaming.kafkastream.KafkaStreamHelper
import com.boursorama.utils.AppConf._
import org.apache.spark.{ SparkConf, SparkContext }
import org.apache.spark.storage.StorageLevel
import org.apache.spark.streaming.dstream.DStream
import org.apache.spark.streaming.{ Seconds, StreamingContext }

trait Pipeline extends Serializable {

  def getAppName: String

  def getCheckpointDir: String

  def getTopicSet: Set[String]

  def getGroupId: String

  protected def afterStart(ssc: StreamingContext): Unit = {}

  def getSparkContext(ssc: StreamingContext): SparkContext = {
    ssc.sparkContext
  }

  def start(): Unit = {
    val timeout = 0
    // val ssc = StreamingContext.getOrCreate(getCheckpointDir, createStreamingContext)
    val ssc = createStreamingContext()
    runSpark(ssc, timeout)
  }

  def createStreamingContext(): StreamingContext = {
    val timeout = 0
    val sparkConf = getSparkConf

    var sc = new SparkContext(sparkConf)
    val ssc = new StreamingContext(sc, Seconds(SparkBatchWindow)) // new context

    //val ssc = new StreamingContext(sparkConf, Seconds(SparkBatchWindow))   // new context
    process(ssc, timeout)
    // ssc.checkpoint(getCheckpointDir)
    ssc
  }

  def getSparkConf: SparkConf = {
    new SparkConf()
      .setAppName(getAppName)
      // cassandra
      .set("spark.cassandra.connection.host", CassandraNodes)
      .set("spark.cassandra.auth.username", CassandraUsername)
      .set("spark.cassandra.auth.password", CassandraPassword)
      //.set("spark.cassandra.output.concurrent.writes", "5")
      // elastic search
      .set("es.nodes", EsNodes)
      .set("es.port", EsPort)
      .set("es.net.ssl.cert.allow.self.signed", "true")
      .set("es.net.ssl", "true")
      .set("es.net.http.auth.user", EsUsername)
      .set("es.net.http.auth.pass", EsPassword)
      .set("es.index.auto.create", "true")
      .set("es.nodes.discovery", "true")
      .set("es.nodes.data.only", "true")
      .set("es.nodes.client.only", "false")
      //.set("es.write.operation","upsert")
      .set("es.batch.write.refresh","false")
      // kafka   
      //.set("spark.streaming.kafka.maxRatePerPartition", "1000")
      .set("spark.streaming.receiver.maxRate", "5000")
      // serializer
      .set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
  }

  def runSpark(ssc: StreamingContext, timeout: Long): Unit = {
    ssc.start()

    if (0 < timeout) {
      ssc.awaitTerminationOrTimeout(timeout)
      ssc.stop()
    } else {
      ssc.awaitTermination()
    }
    println("<< process ")
  }

  protected def getStorageLevel: StorageLevel = {
    StorageLevel.MEMORY_AND_DISK_2
  }

  def process(ssc: StreamingContext, timeout: Long): Unit

  def getInputStream(ssc: StreamingContext): DStream[String] = {
    KafkaStreamHelper.printOffsetRanges(ssc, getTopicSet, getGroupId)
  }

  def getClientInformation(idWeb: Long): Option[Client] = {
    CassandraHelper.getClientInformationByKey(idWeb)
  }

}
