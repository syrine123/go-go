package com.boursorama.spark.streaming.detector

import com.boursorama.dtl.business.{SortieFond, SortieFondSuspect}
import com.boursorama.spark.persistance.cassandra.CassandraHelper
import com.boursorama.utils.Constants._
import org.apache.spark.SparkContext
import org.joda.time.DateTime
import scala.collection.mutable

class SortieFondPaysSuspectDetector extends Serializable {

  val refreshDelaySec: Long = 300l // every 5min
  var lastRefrech = 0L
  //var cachedParamsMap = SUSPECT_CONNECTION_COUNTRIES
  var cachedParamsMap = List("")
  val initList = cachedParamsMap

  def getFraudeParamsFromDbFlagBlanchiment: List[String] = {
    val codePaysSuspects = CassandraHelper.getAllPaysSuspectsFlagBlanchiment
    codePaysSuspects match {
      case None => initList
      case Some(codes) => codes
    }
  }

  def getFraudeParamsFlagBlanchiment() : List[String] = {
    if (lastRefrech + refreshDelaySec * 1000 < System.currentTimeMillis()) {
      cachedParamsMap = getFraudeParamsFromDbFlagBlanchiment
      lastRefrech = System.currentTimeMillis()
    }
    cachedParamsMap
  }

  def getFraudeParamsFromDbFlagEmbargo: List[String] = {
    val codePaysSuspects = CassandraHelper.getAllPaysSuspectsFlagEmbargo
    codePaysSuspects match {
      case None => initList
      case Some(codes) => codes
    }
  }

  def getFraudeParamsFlagEmbargo() : List[String] = {
    if (lastRefrech + refreshDelaySec * 1000 < System.currentTimeMillis()) {
      cachedParamsMap = getFraudeParamsFromDbFlagEmbargo
      lastRefrech = System.currentTimeMillis()
    }
    cachedParamsMap
  }

  def getFraudeParamsFromDbFlagNonCooperatif: List[String] = {
    val codePaysSuspects = CassandraHelper.getAllPaysSuspectsFlagNonCooperatif
    codePaysSuspects match {
      case None => initList
      case Some(codes) => codes
    }
  }

  def getFraudeParamsFlagNonCooperatif() : List[String] = {
    if (lastRefrech + refreshDelaySec * 1000 < System.currentTimeMillis()) {
      cachedParamsMap = getFraudeParamsFromDbFlagNonCooperatif
      lastRefrech = System.currentTimeMillis()
    }
    cachedParamsMap
  }

  def suspect(sortieFond: SortieFond): Option [SortieFondSuspect] = {

    val countryCodesFlagBlanchiment = getFraudeParamsFlagBlanchiment()
    val countryCodesFlagEmbargo = getFraudeParamsFlagEmbargo()
    val countryCodesFlagNonCooperatif = getFraudeParamsFlagNonCooperatif()

    if (
          countryCodesFlagBlanchiment.contains(sortieFond.code_pays_cible.toUpperCase()) ||
          countryCodesFlagEmbargo.contains(sortieFond.code_pays_cible.toUpperCase()) ||
          countryCodesFlagNonCooperatif.contains(sortieFond.code_pays_cible.toUpperCase())
    ) {
      println(s"     - Sortie fond suspecte avec pays suspect ${sortieFond.code_pays_cible} detecté ! - ${sortieFond.toString}")
      Some(
        new  SortieFondSuspect(
          sortieFond.sys_origine,
          sortieFond.annee_mois,
          sortieFond.id_dim_temps,
          sortieFond.date_operation,
          sortieFond.id_transaction,
          sortieFond.id_web,
          sortieFond.adresse_ip,
          sortieFond.montant,
          sortieFond.error_message,
          sortieFond.code_operation,
          sortieFond.banque_source,
          sortieFond.agence_source,
          sortieFond.compte_source,
          sortieFond.cle_rib_source,
          sortieFond.iban_source,
          sortieFond.iban_cible,
          sortieFond.code_pays_cible,
          sortieFond.client,
          sortieFond.solde_previsionnel,
          TYPE_FRAUDE_EXT_PAYS_SUSPECT,
          Map("ListePaysSuspectsFlagBlanchiment" -> countryCodesFlagBlanchiment.mkString(","),
              "ListePaysSuspectsFlagEmbargo" -> countryCodesFlagEmbargo.mkString(","),
              "ListePaysSuspectsFlagNonCooperatif" -> countryCodesFlagNonCooperatif.mkString(",")),
          VALID_STATUS("UNKNOWN"),
          EmptyStringField,
          DateTime.now()
        )
      )
    } else
      None
  }
}

object SortieFondPaysSuspectDetector extends SortieFondPaysSuspectDetector
