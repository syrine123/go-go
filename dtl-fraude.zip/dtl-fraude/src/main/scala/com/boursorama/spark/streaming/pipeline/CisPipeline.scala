package com.boursorama.spark.streaming.pipeline

import com.boursorama.dtl.business.SortieFond
import com.boursorama.spark.streaming.parser.ActionExterneCisParser
import com.boursorama.utils.AppConf
import org.apache.spark.streaming.dstream.DStream
import org.apache.spark.streaming.StreamingContext

class CisPipeline extends SortieFondPipeline {

  def getAppName: String = "sp-strm-cis"

  def getCheckpointDir: String = AppConf.SparkCisCheckpointDirectory

  def getTopicSet: Set[String] = Set(AppConf.KafkaTopicCis)

  def getGroupId : String = "dtl-fraude"

  def process(ssc: StreamingContext, timeout: Long): Unit = {

    val logDStream: DStream[String] = getInputStream(ssc)

    val sortieFondDStream: DStream[SortieFond] = parseToSortieFond(logDStream)

    processSortieFond(sortieFondDStream)

    //processSequenceSuspect(sortieFondDStream)
  }

  def parseToSortieFond: String => Option[SortieFond] = ActionExterneCisParser.parseLine

}

object CisPipeline extends CisPipeline
