package com.boursorama.spark.streaming.detector

import com.boursorama.dtl.business.Connection
import com.boursorama.spark.persistance.cassandra.CassandraHelper
import com.boursorama.utils.Constants._

class SuspectConnectionDetector extends Serializable {

  val refreshDelaySec: Long = 300l // every 5min
  var lastRefrech = 0L
  //var cachedParamsList = SUSPECT_CONNECTION_COUNTRIES
  var cachedParamsList = List("")
  val initList = cachedParamsList

  def getFraudeParamsFromDbFlagBlanchiment: List[String] = {
    val codePaysSuspects = CassandraHelper.getAllPaysSuspectsFlagBlanchiment
    codePaysSuspects match {
      case None        => initList
      case Some(codes) => codes
    }
  }

  def getFraudeParamsFlagBlanchiment(): List[String] = {
    if (lastRefrech + refreshDelaySec * 1000 < System.currentTimeMillis()) {
      cachedParamsList = getFraudeParamsFromDbFlagBlanchiment
      lastRefrech = System.currentTimeMillis()
    }
    cachedParamsList
  }

  def getFraudeParamsFromDbFlagEmbargo: List[String] = {
    val codePaysSuspects = CassandraHelper.getAllPaysSuspectsFlagEmbargo
    codePaysSuspects match {
      case None        => initList
      case Some(codes) => codes
    }
  }

  def getFraudeParamsFlagEmbargo(): List[String] = {
    if (lastRefrech + refreshDelaySec * 1000 < System.currentTimeMillis()) {
      cachedParamsList = getFraudeParamsFromDbFlagEmbargo
      lastRefrech = System.currentTimeMillis()
    }
    cachedParamsList
  }

  def getFraudeParamsFromDbFlagNonCooperatif: List[String] = {
    val codePaysSuspects = CassandraHelper.getAllPaysSuspectsFlagNonCooperatif
    codePaysSuspects match {
      case None        => initList
      case Some(codes) => codes
    }
  }

  def getFraudeParamsFlagNonCooperatif(): List[String] = {
    if (lastRefrech + refreshDelaySec * 1000 < System.currentTimeMillis()) {
      cachedParamsList = getFraudeParamsFromDbFlagNonCooperatif
      lastRefrech = System.currentTimeMillis()
    }
    cachedParamsList
  }

  def detectEmbargo3Weeks(suspectConnection: Connection): Option[Connection] = {
    if (CassandraHelper.getSuspectConnectionsInLast3Weeks(suspectConnection.id_web)) {
      suspectConnection.type_fraude = TYPE_FRAUDE_EXT_EMBARGO_3_SEMAINES
    }
    Some(suspectConnection)
  }

  def detectEmbargo(connection: Connection): Option[Connection] = {
    //var listBlanchiment = getFraudeParamsFlagBlanchiment
    var listEmbatgo = getFraudeParamsFlagEmbargo
    //var listNonCooperatif = getFraudeParamsFlagNonCooperatif
    /*
    if (listBlanchiment.contains(connection.code_pays.toUpperCase()) ||
      listEmbatgo.contains(connection.code_pays.toUpperCase()) ||
      listNonCooperatif.contains(connection.code_pays.toUpperCase())) {
      connection.type_fraude = TYPE_FRAUDE_EXT_EMBARGO
      detectEmbargo3Weeks(connection)
    }*/

    // verify only on countries that have embargo flag
    if ( listEmbatgo.contains(connection.code_pays.toUpperCase()) ) {
      connection.type_fraude = TYPE_FRAUDE_EXT_EMBARGO
      detectEmbargo3Weeks(connection)
    }

    Some(connection)
  }

}

object SuspectConnectionDetector extends SuspectConnectionDetector

