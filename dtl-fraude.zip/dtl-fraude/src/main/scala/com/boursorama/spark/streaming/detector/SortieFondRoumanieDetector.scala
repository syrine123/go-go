package com.boursorama.spark.streaming.detector

import com.boursorama.dtl.business.{SortieFond, SortieFondSuspect}
import com.boursorama.spark.persistance.cassandra.CassandraHelper
import com.boursorama.utils.Constants._
import org.apache.spark.SparkContext
import org.joda.time.DateTime

/**
  * Created by ubuntu on 14/03/17.
  */
class SortieFondRoumanieDetector extends Serializable {

  var cachedParamsMap = Map[String, String](
    "paysCible" -> SORTIE_FOND_ROUMANIE,
    "changementInfos" -> CHANGE_TEL_MAIL
  )

  def suspect(sortieFond: SortieFond): Option[SortieFondSuspect] = {
    val clientOpt = sortieFond.client
    if (clientOpt == None) {
      None
    } else {
      val client = clientOpt.get
      val paramsMap = cachedParamsMap

      if (sortieFond.iban_cible.contains(SORTIE_FOND_ROUMANIE)){
        var MailChange  = CassandraHelper.getCountMailsChangesDaysBeforePerIdWeb(client.id_web, 30)
        var TelChange  = CassandraHelper.getCountTelsChangesDaysBeforePerIdWeb(client.id_web, 30)

        var MailChange2  = CassandraHelper.getCountMailsChangesDaysBeforePerIdContact(client.contact_id, 30)
        var TelChange2  = CassandraHelper.getCountTelsChangesDaysBeforePerIdContact(client.contact_id, 30)

        if (
            MailChange + TelChange + MailChange2 + TelChange2 > 0
        ) {
          Some(
            new SortieFondSuspect(
              sortieFond.sys_origine,
              sortieFond.annee_mois,
              sortieFond.id_dim_temps,
              sortieFond.date_operation,
              sortieFond.id_transaction,
              sortieFond.id_web,
              sortieFond.adresse_ip,
              sortieFond.montant,
              sortieFond.error_message,
              sortieFond.code_operation,
              sortieFond.banque_source,
              sortieFond.agence_source,
              sortieFond.compte_source,
              sortieFond.cle_rib_source,
              sortieFond.iban_source,
              sortieFond.iban_cible,
              sortieFond.code_pays_cible,
              sortieFond.client,
              sortieFond.solde_previsionnel,
              TYPE_FRAUDE_SORTIE_ROUMANIE,
              paramsMap,
              VALID_STATUS("UNKNOWN"),
              EmptyStringField,
              DateTime.now()
            )
          )
        } else
          None
      }else {
        None
      }
    }
  }
}

object SortieFondRoumanieDetector extends SortieFondRoumanieDetector
