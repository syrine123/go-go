package com.boursorama.spark.streaming.parser

import com.boursorama.utils.Conversion._
import org.joda.time.DateTime

import scala.util.{Failure, Success, Try}

/**
 * Created by ubuntu on 22/07/16.
 */
class CisParserHelper {

  def cleanActionLineCis(line: String): String = line match {
    case s if s.length() > 0 => line.replace("{", "e").replace("}", "e")
    case _ => line
  }

  def makeTimestampFromCIS(year: String, month: String, day: String, time: String): DateTime = {
    Try(
      getDateTime(year.toInt, month.toInt, day.toInt, time.substring(0, 2).toInt, time.substring(2, 4).toInt, time.substring(4, 6).toInt, ParisTimeZone)
    ) match {
      case Success(v) => v
      case Failure(v) => getDateTime(0,0,0,0,0,0)
    }
  }
}

object CisParserHelper extends CisParserHelper
