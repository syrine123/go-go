package com.boursorama.spark.streaming

import com.boursorama.spark.streaming.pipeline.AtosPipeline

object SpStrmConnectionDriver extends Serializable {

  def main(args: Array[String]) : Unit = {
    AtosPipeline.start()
  }
}
