package com.boursorama.spark.streaming.pipeline

import com.boursorama.dtl.business.{ SortieFond, SortieFondSuspect }
import com.boursorama.spark.persistance.cassandra.CassandraHelper
import com.boursorama.spark.persistance.es.EsHelper
import com.boursorama.spark.streaming.detector.SortieFondSuspectDetector
import com.boursorama.spark.streaming.notifier.{ SortieFondSuspectMailNotifier, SuspectNotifier }
import org.apache.spark.streaming.dstream.DStream

trait SortieFondPipeline extends Pipeline {

  def processSortieFond(sortieFondDStream: DStream[SortieFond]): Unit = {

    val enrichedSortieFondDStream = enrichiSortieFond(sortieFondDStream)

    enrichedSortieFondDStream.persist(getStorageLevel)

    persisteSortieFond(enrichedSortieFondDStream)

    val sortieFondSuspectDStream = detectSortieFondSuspect(enrichedSortieFondDStream)

    sortieFondSuspectDStream.persist(getStorageLevel)

    persisteSortieFondSuspect(sortieFondSuspectDStream)

    notifySortieFondSuspect(sortieFondSuspectDStream)
  }

  def parseToSortieFond(logDStream: DStream[String]): DStream[SortieFond] = {
    logDStream.flatMap(log => parseToSortieFond(log))
  }

  def parseToSortieFond: String => Option[SortieFond]

  def enrichiSortieFond(sortieFondDStream: DStream[SortieFond]): DStream[SortieFond] = {
    sortieFondDStream.flatMap(sortieFond => enrichiSortieFond(sortieFond))
  }

  def enrichiSortieFond(sortieFond: SortieFond): Option[SortieFond] = {

    val optionClientInfo = getClientInformation(sortieFond.id_web)
    val solde_previsionnel = optionClientInfo match {
      case None         => 0.0
      case Some(client) => client.encours - client.mt_cumule_rc - sortieFond.montant.toDouble
    }
    Some(sortieFond.copy(client = optionClientInfo, solde_previsionnel = solde_previsionnel))
  }

  def detectSortieFondSuspect(sortieFondsDStream: DStream[SortieFond]): DStream[SortieFondSuspect] = {
    sortieFondsDStream.flatMap(sortieFond => detectSortieFondSuspect(sortieFond))
  }

  val suspectDetector: SortieFondSuspectDetector = SortieFondSuspectDetector

  def detectSortieFondSuspect(sortieFonds: SortieFond): List[SortieFondSuspect] = {
    suspectDetector.suspect(sortieFonds)
  }

  def persisteSortieFond(sortieFondDStream: DStream[SortieFond]): Unit = {
    CassandraHelper.persisteSortieFond(sortieFondDStream)
    EsHelper.persisteSortieFond(sortieFondDStream)
  }

  val mailNotifier: SuspectNotifier[SortieFondSuspect] = SortieFondSuspectMailNotifier

  def notifySortieFondSuspect(sortieFondSuspectDStream: DStream[SortieFondSuspect]): Unit = {
    mailNotifier.notify(sortieFondSuspectDStream)
  }

  def persisteSortieFondSuspect(sortieFondSuspectDStream: DStream[SortieFondSuspect]): Unit = {
    CassandraHelper.persisteSortieFondSuspect(sortieFondSuspectDStream)
    EsHelper.persisteSortieFondSuspect(sortieFondSuspectDStream)
  }

}
