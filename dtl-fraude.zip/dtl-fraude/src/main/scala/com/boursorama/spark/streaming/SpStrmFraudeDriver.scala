package com.boursorama.spark.streaming

import com.boursorama.spark.streaming.pipeline.CisPipeline

object SpStrmFraudeDriver extends Serializable {

  def main(args: Array[String]) : Unit = {
    CisPipeline.start()
  }
}
