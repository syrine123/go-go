package com.boursorama.spark.streaming.notifier

import javax.mail.internet.InternetAddress

import com.boursorama.dtl.business.SortieFondSuspect
import com.boursorama.utils.AppConf.SenderMail
import com.boursorama.utils.MailSender
import com.boursorama.utils.Constants.{AJOUT_IBAN,CHANGE_MAIL,CHANGE_TEL, OLD_MAIL, OLD_TEL, NEW_MAIL, NEW_TEL, TYPE_FRAUDE_EXT_SEQUENCE_SUSPECTE, TYPE_FRAUDE_EXT_SEQUENCE_SUSPECTE_2, addressMap}
import com.boursorama.utils.Conversion.ParisTimeZone

class SortieFondSuspectMailNotifier extends SuspectNotifier[SortieFondSuspect] with Serializable {

  override def notifySuspect(sortieFondSuspect: SortieFondSuspect): Unit = {
    println(s" - SortieFondSuspectMailNotifier.notify -> sendMail")
    val startTime = System.currentTimeMillis()
    sendMail(sortieFondSuspect, addressMap(sortieFondSuspect.type_fraude), false)
    val execTime = System.currentTimeMillis() - startTime
    println(s"     took : $execTime ms")
  }

  def sendMail(sortieFondSuspect: SortieFondSuspect, RecipientSortieFondMail: Array[InternetAddress], testMode: Boolean): String = {
    val mailSubject = formatMailSubject(sortieFondSuspect)
    val mailBody = formatMailBody(sortieFondSuspect)
    MailSender.send(SenderMail, RecipientSortieFondMail, mailSubject, mailBody, testMode)
  }

  def formatMailSubject(sortieFondSuspect: SortieFondSuspect): String = {
    "Sortie de fond suspecte : " + sortieFondSuspect.type_fraude.toString
  }

  def formatMailBody(sortieFondSuspect: SortieFondSuspect): String = {

      if(sortieFondSuspect.type_fraude == TYPE_FRAUDE_EXT_SEQUENCE_SUSPECTE || sortieFondSuspect.type_fraude == TYPE_FRAUDE_EXT_SEQUENCE_SUSPECTE_2){
          "Séquence suspecte détectée : \r\n\n" +
          "Contact ID : " + sortieFondSuspect.client.get.contact_id.toString + "   \r\n" +
          "ID WEB : " + sortieFondSuspect.client.get.id_web.toString + "    \r\n" +
          "Date entrée en relation du client / prospect : " + sortieFondSuspect.client.get.date_entree_relation.getOrElse(None).toString + "    \r\n" +
          "Changement déclencheur : MAIL ou TEL" + "    \r\n" +
          "Date changement mail: " + sortieFondSuspect.param_fraude(CHANGE_MAIL) +"    \r\n" +
          "Ancienne adresse mail: " + sortieFondSuspect.param_fraude(OLD_MAIL) +"    \r\n" +
          "Nouvelle adresse mail: " + sortieFondSuspect.param_fraude(NEW_MAIL) +"    \r\n" +
          "Date changement téléphone: " + sortieFondSuspect.param_fraude(CHANGE_TEL) +"    \r\n" +
          "Ancien numéro de téléphone: " + sortieFondSuspect.param_fraude(OLD_TEL) +"    \r\n" +
          "Nouveau numéro de téléphone: " + sortieFondSuspect.param_fraude(NEW_TEL) +"    \r\n" +
          "Ajout déclencheur : BIC / IBAN externe déclaré    \r\n" +
          "Date ajout : "+ sortieFondSuspect.param_fraude(AJOUT_IBAN) +"    \r\n" +
          "Evénement déclencheur : virement     \r\n" +
          "Date Heure evénement déclencheur : " + sortieFondSuspect.date_operation.withZone(ParisTimeZone).toString() + "    \r\n" +
          "Montant : " + sortieFondSuspect.montant.toString + "    \r\n" +
          "IBAN source : " + sortieFondSuspect.iban_source.toString + "    \r\n" +
          "IBAN cible : " + sortieFondSuspect.iban_cible.toString + "    \r\n"
      }else {
            "Sortie de fond suspecte détectée : \r\n\n" +
            "Contact ID : " + sortieFondSuspect.client.get.contact_id.toString + "   \r\n" +
            "ID WEB : " + sortieFondSuspect.client.get.id_web.toString + "    \r\n" +
            "Date entrée en relation du client / prospect : " + sortieFondSuspect.client.get.date_entree_relation.getOrElse(None).toString + "    \r\n" +
            "Date opération : " + sortieFondSuspect.date_operation.withZone(ParisTimeZone).toString() + "    \r\n" +
            "Login du client: " + sortieFondSuspect.id_web.toString + "    \r\n" +
            "IBAN source : " + sortieFondSuspect.iban_source.toString + "    \r\n" +
            "IBAN cible : " + sortieFondSuspect.iban_cible.toString + "    \r\n" +
            "Montant : " + sortieFondSuspect.montant.toString + "    \r\n" +
            "Type de la fraude : " + sortieFondSuspect.type_fraude.toString + "    \r\n" +
            "Paramètres de fraude : \r\n  - " +
            sortieFondSuspect.param_fraude.map { case (k, v) => k.toString + " = " + v.toString }.mkString("\r\n  - ") +
            "\r\n\r\n"
      }


  }
}

object SortieFondSuspectMailNotifier extends SortieFondSuspectMailNotifier
