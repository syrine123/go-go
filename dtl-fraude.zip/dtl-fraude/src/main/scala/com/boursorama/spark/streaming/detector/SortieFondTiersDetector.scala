package com.boursorama.spark.streaming.detector

import com.boursorama.dtl.business.{SortieFond, SortieFondSuspect}
import com.boursorama.spark.persistance.cassandra.CassandraHelper
import com.boursorama.utils.Constants._
import org.joda.time.DateTime
import scala.collection.mutable

/**
  * Created by ubuntu on 14/02/17.
  */
class SortieFondTiersDetector extends Serializable {

  var cachedParamsMap = Map[String, String]()

  def getFraudeParamsFromDb (Type_Fraude : String): Map[String, String] = {
    val option = CassandraHelper.getFraudeParams(Type_Fraude)
    option match {
      case None => Map()
      case Some(fraudeParams) => fraudeParams.params
    }
  }

  def getFraudeParams(Type_Fraude : String) : Map[String, String] = {
    if(Type_Fraude == MULTIPLE_TRANSACTION_EXT_PERSON_OUT){
      val fraudeParams = getFraudeParamsFromDb(MULTIPLE_TRANSACTION_EXT_PERSON_OUT)
      val newParamsMap = mutable.Map[String, String]()
      newParamsMap.put("NbrTotalVirementDestinationMemeTiers", fraudeParams.getOrElse("NbrTotalVirementDestinationMemeTiers", NBR_VIR_DESTINATION_MEME))
      newParamsMap.put("seuilCumulDestinationMemeTiers", fraudeParams.getOrElse("seuilCumulDestinationMemeTiers", SEUIL_CUMUL_DESTINATION))
      newParamsMap.put("RibSourceDestinationDiff", fraudeParams.getOrElse("RibSourceDestinationDiff", RIB_SOURCE_DESTINATION_DIFF))
      cachedParamsMap = newParamsMap.toMap
      return cachedParamsMap
    }else if (Type_Fraude == MULTIPLE_TRANSACTION_EXT_PERSON_IN){
              val fraudeParams = getFraudeParamsFromDb(MULTIPLE_TRANSACTION_EXT_PERSON_IN)
              val newParamsMap = mutable.Map[String, String]()
              newParamsMap.put("NbrTotalVirementProvenanceMemeTiers", fraudeParams.getOrElse("NbrTotalVirementProvenanceMemeTiers", NBR_VIR_PROVENANCE_MEME))
              newParamsMap.put("seuilCumulProvenanceMemeTiers", fraudeParams.getOrElse("seuilCumulProvenanceMemeTiers", SEUIL_CUMUL_PROVENANCE))
              newParamsMap.put("RibSourceDestinationDiff", fraudeParams.getOrElse("RibSourceDestinationDiff", RIB_SOURCE_DESTINATION_DIFF))
              cachedParamsMap = newParamsMap.toMap
              return cachedParamsMap
            } else {
                  val fraudeParams = getFraudeParamsFromDb(MULTIPLE_TRANSACTION_EXT_PERSON_IN_OUT)
                  val newParamsMap = mutable.Map[String, String]()
                  newParamsMap.put("seuilCumulDestinationMemeTiers", fraudeParams.getOrElse("seuilCumulDestinationMemeTiers", SEUIL_CUMUL_DESTINATION))
                  newParamsMap.put("seuilCumulDestinationEgaleSeuilCumulProvenance", fraudeParams.getOrElse("seuilCumulDestinationEgaleSeuilCumulProvenance", SEUIL_CUMUL_DESTINATION_EGALE_SEUIL_CUMULE_PROVENANCE))
                  cachedParamsMap = newParamsMap.toMap
                  return cachedParamsMap
            }

  }

  /** Indicateur 2
    * suspect_outgoing Allows to detect the outgoing transactions that constitute frauds
    * @param sortieFond
    * @return SortieFondSuspect
    */
  def suspect_outgoing(sortieFond: SortieFond): Option[SortieFondSuspect] = {
    val clientOpt = sortieFond.client
    if (clientOpt == None) {
      None
    } else {
      val client = clientOpt.get

      val paramsMap = getFraudeParams(MULTIPLE_TRANSACTION_EXT_PERSON_OUT)

      val seuil_cumul = paramsMap.getOrElse("seuilCumulProvenanceMemeTiers", SEUIL_CUMUL_PROVENANCE).toDouble
      val nb_total_vir = paramsMap.getOrElse("NbrTotalVirementProvenanceMemeTiers", NBR_VIR_PROVENANCE_MEME).toLong


      val resultats = CassandraHelper.getLastMonthClientSortieFondTiers(client.id_web,sortieFond.iban_cible)
      val nbrTotalVir : Long = resultats._1
      val sumMontant : Double = resultats._2

      var nums_contrat : List[String] = CassandraHelper.getNumContratClient(client.id_web)

      var same_compte : Boolean = false

      for (num_contrat <- nums_contrat){
        if (sortieFond.iban_cible.contains(num_contrat)){
          same_compte = true
        }
      }

      if (
            nbrTotalVir >= nb_total_vir &&
            sumMontant >= seuil_cumul &&
            same_compte == false
      ) {
        println(s"     - Sortie fond suspecte avec cas de Multiples virements sortants à destination d’un même tiers ! - ${sortieFond.toString}")
        Some(
          new SortieFondSuspect(
            sortieFond.sys_origine,
            sortieFond.annee_mois,
            sortieFond.id_dim_temps,
            sortieFond.date_operation,
            sortieFond.id_transaction,
            sortieFond.id_web,
            sortieFond.adresse_ip,
            sortieFond.montant,
            sortieFond.error_message,
            sortieFond.code_operation,
            sortieFond.banque_source,
            sortieFond.agence_source,
            sortieFond.compte_source,
            sortieFond.cle_rib_source,
            sortieFond.iban_source,
            sortieFond.iban_cible,
            sortieFond.code_pays_cible,
            sortieFond.client,
            sortieFond.solde_previsionnel,
            MULTIPLE_TRANSACTION_EXT_PERSON_OUT,
            paramsMap,
            VALID_STATUS("UNKNOWN"),
            EmptyStringField,
            DateTime.now()
          )
        )
      } else
        None
    }
  }
/*
  /**
    * suspect_incoming Allows to detect the incoming transactions that constitute frauds
    * @param sortieFond
    * @return SortieFondSuspect
    */
  def suspect_incoming(sortieFond: SortieFond): Option[SortieFondSuspect] = {
    val clientOpt = sortieFond.client
    if (clientOpt == None) {
      None
    } else {
      val client = clientOpt.get

      val paramsMap = getFraudeParams(MULTIPLE_TRANSACTION_EXT_PERSON_IN)
      val seuil_cumul = paramsMap.getOrElse("seuilCumulProvenanceMemeTiers", SEUIL_CUMUL_PROVENANCE).toDouble
      val nb_total_vir = paramsMap.getOrElse("NbrTotalVirementProvenanceMemeTiers", NBR_VIR_PROVENANCE_MEME).toLong

      val sumMontant : Double = CassandraHelper.getLastMonthClientSumEntreeFondTiers(client.id_web,sortieFond.iban_source)
      val nbrTotalVir : Double = CassandraHelper.getLastMonthClientEntreeFondTiers(client.id_web,sortieFond.iban_source)
      var nums_contrat : List[String] = CassandraHelper.getNumContratClient(client.id_web)

      var same_compte : Boolean = false

      for (num_contrat <- nums_contrat){
        if (sortieFond.iban_cible.contains(num_contrat)){
          same_compte = true
        }
      }
      if (
          nbrTotalVir >= nb_total_vir &&
          sumMontant >= seuil_cumul &&
          same_compte == false
      ) {
        println(s"     - Sortie fond suspecte avec cas de Multiples virements sortants à destination d’un même tiers ! - ${sortieFond.toString}")
        Some(
          new SortieFondSuspect(
            sortieFond.sys_origine,
            sortieFond.annee_mois,
            sortieFond.id_dim_temps,
            sortieFond.date_operation,
            sortieFond.id_transaction,
            sortieFond.id_web,
            sortieFond.adresse_ip,
            sortieFond.montant,
            sortieFond.error_message,
            sortieFond.code_operation,
            sortieFond.banque_source,
            sortieFond.agence_source,
            sortieFond.compte_source,
            sortieFond.cle_rib_source,
            sortieFond.iban_source,
            sortieFond.iban_cible,
            sortieFond.code_pays_cible,
            sortieFond.client,
            sortieFond.solde_previsionnel,
            MULTIPLE_TRANSACTION_EXT_PERSON_IN,
            paramsMap,
            VALID_STATUS("UNKNOWN")
          )
        )
      } else
        None
    }
  }

  /**
    * suspect_in_out Allows to detect the incoming and outgoing transactions that constitute frauds
    * @param sortieFond
    * @return
    */
  def suspect_in_out(sortieFond: SortieFond): Option[SortieFondSuspect] = {
    val clientOpt = sortieFond.client
    if (clientOpt == None) {
      None
    } else {
      val client = clientOpt.get

      val paramsMap = getFraudeParams(MULTIPLE_TRANSACTION_EXT_PERSON_IN_OUT)
      val seuil_cumul : Double = 200

      val sumMontantSortant : Double = CassandraHelper.getLast3MonthsClientSumSortieFondTiers(client.id_web,sortieFond.iban_cible)
      val sumMontantEntrant : Double = CassandraHelper.getLast3MonthsClientSumEntreeFondTiers(client.id_web,sortieFond.iban_source)

      if (
          sumMontantSortant >= seuil_cumul &&
          sumMontantSortant == sumMontantEntrant
      ) {
        println(s"     - Sortie fond suspecte avec cas de Multiples virements sortants à destination d’un même tiers ! - ${sortieFond.toString}")
        Some(
          new SortieFondSuspect(
            sortieFond.sys_origine,
            sortieFond.annee_mois,
            sortieFond.id_dim_temps,
            sortieFond.date_operation,
            sortieFond.id_transaction,
            sortieFond.id_web,
            sortieFond.adresse_ip,
            sortieFond.montant,
            sortieFond.error_message,
            sortieFond.code_operation,
            sortieFond.banque_source,
            sortieFond.agence_source,
            sortieFond.compte_source,
            sortieFond.cle_rib_source,
            sortieFond.iban_source,
            sortieFond.iban_cible,
            sortieFond.code_pays_cible,
            sortieFond.client,
            sortieFond.solde_previsionnel,
            MULTIPLE_TRANSACTION_EXT_PERSON_IN_OUT,
            paramsMap,
            VALID_STATUS("UNKNOWN")
          )
        )
      } else
        None
    }
  }*/
}

object SortieFondTiersDetector extends SortieFondTiersDetector
