package com.boursorama.spark.persistance.es

import com.boursorama.cassandra.RejectionHandler._
import com.boursorama.dtl.business._
import com.boursorama.dtl.business.es._
import com.boursorama.utils.Constants._
import com.boursorama.utils.Conversion._
import org.apache.spark.streaming.dstream.DStream
import org.elasticsearch.spark.streaming._

object EsHelper extends Serializable {

  @transient lazy val logger = org.apache.log4j.LogManager.getLogger("EsHelper")

  val emptyClient = Client(-1, -1, Some(getDateTime(0)), -1, -1, -1)

  def getSortieFondIndexName: String = "idx-sortie-fond-{annee_mois}/sortie-fond"
  def getConnection: String = "idx-connexion-suspecte-{annee_mois}/connexion-suspecte"

  def persistSuspectSequence(suspectSequenceDStream: DStream[SuspectSequence]): Unit = {
    suspectSequenceDStream
      .map(suspectSequence => mapToDto(suspectSequence))
      .saveToEs(getSortieFondIndexName)
  }

  def persisteSortieFond(sortieFondsDStream: DStream[SortieFond]): Unit = {
    sortieFondsDStream
      .flatMap(sortieFond => mapToDto(sortieFond))
      .saveToEs(getSortieFondIndexName, Map("es.mapping.id" -> "id_es", "es.write.operation" -> "upsert"))
  }

  def mapToDto(suspectSequence: SuspectSequence): SuspectSequenceEsDto = {
    new SuspectSequenceEsDto(
      suspectSequence.id_web,
      suspectSequence.annee_mois,
      suspectSequence.service,
      suspectSequence.id_dim_temps,
      dateTimeToString(suspectSequence.timestamp),
      suspectSequence.client_contact_id,
      suspectSequence.log,
      suspectSequence.tel_changed,
      suspectSequence.iban_changed,
      TYPE_FRAUDE_EXT_SEQUENCE_SUSPECTE)
  }

  def persisteSortieFondSuspect(sortieFondSuspectDStream: DStream[SortieFondSuspect]): Unit = {
    sortieFondSuspectDStream
      .map(sortieFondSuspect => mapToDto(sortieFondSuspect))
      .saveToEs(getSortieFondIndexName, Map("es.mapping.id" -> "id_es", "es.write.operation" -> "upsert"))
  }

  def mapToDto(sortieFond: SortieFond): Option[SortieFondEsDto] = {

    try {
      Some(new SortieFondEsDto(
        sortieFond.sys_origine,
        sortieFond.annee_mois,
        sortieFond.id_dim_temps,
        dateTimeToString(sortieFond.date_operation),
        nowToString(),
        sortieFond.id_transaction,
        sortieFond.id_web,
        sortieFond.adresse_ip,
        sortieFond.montant,
        sortieFond.status,
        sortieFond.error_message,
        sortieFond.code_operation,
        sortieFond.banque_source,
        sortieFond.agence_source,
        sortieFond.compte_source,
        sortieFond.cle_rib_source,
        sortieFond.iban_source,
        sortieFond.iban_cible,
        sortieFond.code_pays_cible,
        sortieFond.client.getOrElse(emptyClient).contact_id.toString(),
        dateTimeToString(sortieFond.client.getOrElse(emptyClient).date_entree_relation.get),
        sortieFond.client.getOrElse(emptyClient).encours,
        sortieFond.client.getOrElse(emptyClient).mt_cumule_rc,
        sortieFond.client.getOrElse(emptyClient).nombre_rc,
        sortieFond.solde_previsionnel,
        "",
        "",
        dateTimeToString(sortieFond.date_operation)+sortieFond.id_transaction))
    } catch {
      case e: java.util.NoSuchElementException =>
        //handleRejection(sortieFond.sys_origine, NONE_VALUE, e.toString + " => " + e.getStackTrace.mkString("||"), EmptyStringField, sortieFond.log)
        logger.debug(sortieFond.sys_origine, NONE_VALUE, e.toString + " => " + e.getStackTrace.mkString("||"), EmptyStringField, sortieFond.log)
        None
    }
  }

  def mapToDto(sortieFondSuspect: SortieFondSuspect): SortieFondSuspectEsDto = {
    new SortieFondSuspectEsDto(
      sortieFondSuspect.sys_origine,
      sortieFondSuspect.annee_mois,
      sortieFondSuspect.id_dim_temps,
      dateTimeToString(sortieFondSuspect.date_operation),
      nowToString(),
      sortieFondSuspect.id_transaction,
      sortieFondSuspect.id_web,
      sortieFondSuspect.adresse_ip,
      sortieFondSuspect.montant,
      sortieFondSuspect.error_message,
      sortieFondSuspect.code_operation,
      sortieFondSuspect.banque_source,
      sortieFondSuspect.agence_source,
      sortieFondSuspect.compte_source,
      sortieFondSuspect.cle_rib_source,
      sortieFondSuspect.iban_source,
      sortieFondSuspect.iban_cible,
      sortieFondSuspect.code_pays_cible,
      sortieFondSuspect.client.getOrElse(emptyClient).contact_id.toString(),
      dateTimeToString(sortieFondSuspect.client.getOrElse(emptyClient).date_entree_relation.get),
      sortieFondSuspect.client.getOrElse(emptyClient).encours,
      sortieFondSuspect.client.getOrElse(emptyClient).mt_cumule_rc,
      sortieFondSuspect.client.getOrElse(emptyClient).nombre_rc,
      sortieFondSuspect.solde_previsionnel,
      sortieFondSuspect.type_fraude,
      sortieFondSuspect.param_fraude.toString(),
      sortieFondSuspect.valide_statut_fraude,
      sortieFondSuspect.valide_username_fraude,
      dateTimeToString(sortieFondSuspect.valide_date_fraude),
      dateTimeToString(sortieFondSuspect.date_operation)+sortieFondSuspect.id_transaction+sortieFondSuspect.type_fraude)
  }

  def persisteConnection(connectionDStream: DStream[Connection]): Unit = {
    connectionDStream
      .map(connection => mapToDto(connection))
      .saveToEs(getConnection)
  }

  def mapToDto(connection: Connection): ConnectionEsDto = {
    new ConnectionEsDto(
      connection.id_web,
      connection.annee_mois,
      connection.id_dim_temps,
      dateTimeToString(connection.timestamp),
      connection.contact_id,
      connection.log,
      connection.pays,
      connection.code_pays,
      connection.ip,
      connection.coords,
      connection.type_fraude,
      connection.libelleOperation,
      connection.honeyPot)
  }

}
