package com.boursorama.spark.streaming.notifier

import javax.mail.internet.InternetAddress

import com.boursorama.dtl.business.Connection
import com.boursorama.spark.persistance.cassandra.CassandraHelper
import com.boursorama.utils.AppConf.SenderMail
import com.boursorama.utils.Constants._
import com.boursorama.utils.MailSender
import com.boursorama.utils.Conversion.ParisTimeZone

import scala.collection.mutable

/**
 * Created by ubuntu on 02/06/17.
 */
class ConnexionSuspectMailNotifier extends SuspectNotifier[Connection] with Serializable {

  override def notifySuspect(connexionSuspect: Connection): Unit = {
    val result = getFraudeParamsFromDb(TYPE_FRAUDE_EXT_EMBARGO_LIST)
    val newParams = result.getOrElse("embargoList",EMBARGO_LIST)

    if (
      (connexionSuspect.type_fraude == TYPE_FRAUDE_EXT_EMBARGO_3_SEMAINES ||
        connexionSuspect.type_fraude == TYPE_FRAUDE_EXT_EMBARGO) && (newParams.contains(connexionSuspect.code_pays.toUpperCase))
    ) {
      val startTime = System.currentTimeMillis()
      println(s" - ConnexionSuspectMailNotifier.notify -> sendMail")
      sendMail(connexionSuspect, addressMap(connexionSuspect.type_fraude), false)
      val execTime = System.currentTimeMillis() - startTime
      println(s"     took : $execTime ms")
    }
  }

  def getFraudeParamsFromDb(type_fraude: String): Map[String, String] = {
    val option = CassandraHelper.getFraudeParams(type_fraude)
    option match {
      case None               => Map()
      case Some(fraudeParams) => fraudeParams.params
    }
  }

  def sendMail(connexionSuspect: Connection, RecipientSortieFondMail: Array[InternetAddress], testMode: Boolean): String = {
    val mailSubject = formatMailSubject(connexionSuspect)
    val mailBody = formatMailBody(connexionSuspect)
    MailSender.send(SenderMail, RecipientSortieFondMail, mailSubject, mailBody, testMode)
  }

  def formatMailSubject(connexionSuspect: Connection): String = {
    "Connexion suspecte : " + connexionSuspect.type_fraude.toString
  }

  def formatMailBody(connexionSuspect: Connection): String = {
    "Connexion suspecte détectée : \r\n\n" +
      "Contact ID : " + connexionSuspect.contact_id.toString + "   \r\n" +
      "ID WEB : " + connexionSuspect.id_web.toString + "    \r\n" +
      "Date de connexion : " + connexionSuspect.timestamp.withZone(ParisTimeZone).toString() + "    \r\n" +
      "Pays de connexion : " + connexionSuspect.pays + "    \r\n" +
      "Tentative de connexion avec un compte HoneyPot : " + connexionSuspect.honeyPot + "    \r\n" +
      "Type de la fraude : " + connexionSuspect.type_fraude + "    \r\n" +
      "\r\n\r\n"
  }

}

object ConnexionSuspectMailNotifier extends ConnexionSuspectMailNotifier