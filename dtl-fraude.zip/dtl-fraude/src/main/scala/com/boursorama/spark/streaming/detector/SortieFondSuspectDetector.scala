package com.boursorama.spark.streaming.detector

import com.boursorama.dtl.business.{SortieFond, SortieFondSuspect}
import com.boursorama.utils.Constants

class SortieFondSuspectDetector extends Serializable {

  val suspect1: SortieFond => Option[SortieFondSuspect] = SortieFondCavalerieDetector.suspect
  val suspect2: SortieFond => Option[SortieFondSuspect] = SortieFondPaysSuspectDetector.suspect
  val suspect3: SortieFond => Option[SortieFondSuspect] = SortieFondCavalerieBoosterDetector.suspect
  val suspect7: SortieFond => Option[SortieFondSuspect] = SortieFondRoumanieDetector.suspect
  val suspect8: SortieFond => Option[SortieFondSuspect] = SuspectSequenceDetector.suspect
  val suspect9: SortieFond => Option[SortieFondSuspect] = SuspectSequenceDetector.suspect2

  /*val suspect4: SortieFond => Option[SortieFondSuspect] = SortieFondTiersDetector.suspect_outgoing
  val suspect5: SortieFond => Option[SortieFondSuspect] = SortieFondTiersDetector.suspect_incoming
  val suspect6: SortieFond => Option[SortieFondSuspect] = SortieFondTiersDetector.suspect_in_out
  */


  def suspect(sortieFonds: SortieFond): List[SortieFondSuspect] = {
    val detectors = Map(
      "OTRANSFR" -> List(suspect1, suspect2/*, suspect4, suspect5, suspect6*/,suspect7, suspect8, suspect9),
      "ODEMEARV" -> List(suspect3)
    )

    val suspectList = detectors.flatMap(detector =>
      if (detector._1 == sortieFonds.code_operation.trim) {
        detector._2.flatMap(d => d(sortieFonds))
      } else {
        None
      }
    )
    suspectList.toList
  }
}

object SortieFondSuspectDetector extends SortieFondSuspectDetector
