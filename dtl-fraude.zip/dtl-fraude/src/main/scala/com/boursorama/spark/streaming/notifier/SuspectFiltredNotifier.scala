package com.boursorama.spark.streaming.notifier

import org.apache.spark.streaming.dstream.DStream

/**
 * Created by ubuntu on 03/06/16.
 */
trait SuspectFiltredNotifier[T] extends SuspectNotifier[T] {

  def filterSuspect(row: T) : Boolean

  override def notify(stream: DStream[T]): Unit = {

    stream
      .filter(filterSuspect)
      .foreachRDD(rdd => rdd.foreach(row => notifySuspect(row)))
  }
}
