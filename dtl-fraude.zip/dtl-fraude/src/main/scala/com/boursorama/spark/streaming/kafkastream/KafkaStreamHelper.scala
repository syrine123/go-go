package com.boursorama.spark.streaming.kafkastream

import org.apache.spark.streaming.StreamingContext
import org.apache.spark.streaming.dstream.DStream
import org.apache.spark.streaming.kafka.KafkaUtils
import com.boursorama.utils.Constants.CONSUMER_TREADS_PER_UNPUT_DSTREAM
import kafka.serializer.StringDecoder
import com.boursorama.utils.AppConf._
import org.apache.spark.storage.StorageLevel

class KafkaStreamHelper extends Serializable {

  @transient lazy val logger = org.apache.log4j.LogManager.getLogger("KafkaStreamHelper")

  def printOffsetRanges(ssc: StreamingContext, topicSet: Set[String], groupId: String): DStream[String] = {

    var topicMap = Map[String, Int]()

    for (x <- topicSet) {
      topicMap +=  (x -> CONSUMER_TREADS_PER_UNPUT_DSTREAM)
    }
    
    val kafkaParams = Map[String, String](
      //      "metadata.broker.list" -> KafkaBroker,
      "group.id" -> groupId,
      "auto.offset.reset" -> "smallest",
      "zookeeper.connect" -> zkQuorum,
      "zookeeper.connection.timeout.ms" -> "10000")

    KafkaUtils.createStream[String, String, StringDecoder, StringDecoder](ssc, kafkaParams, topicMap, StorageLevel.MEMORY_AND_DISK_SER_2)
      .map(_._2)
  }
  

  //  def printOffsetRangesDirect(ssc: StreamingContext, topicSet: Set[String], groupId: String): DStream[String] = {
  //    val kafkaParams = Map[String, String]("metadata.broker.list" -> KafkaBroker, "group.id" -> groupId)
  //    var offsetRanges = Array.empty[OffsetRange]
  //
  //    val dstream = KafkaUtils.createDirectStream[String, String, StringDecoder, StringDecoder](ssc, kafkaParams, topicSet)
  //      .transform { rdd =>
  //        offsetRanges = rdd.asInstanceOf[HasOffsetRanges].offsetRanges
  //        rdd
  //      }.map(_._2)
  //    dstream.foreachRDD { rdd =>
  //      for (o <- offsetRanges) {
  //        logger.info(s"${o.topic} ${o.partition} ${o.fromOffset} ${o.untilOffset}")
  //        // startOffsetsMap.put(TopicAndPartition(o.topic,o.partition), o)
  //      }
  //    }
  //    dstream
  //  }

}

object KafkaStreamHelper extends KafkaStreamHelper
