package com.boursorama.spark.streaming.pipeline

import com.boursorama.dtl.business.Connection
import com.boursorama.spark.streaming.parser.ConnectionParser
import com.boursorama.utils.AppConf
import org.apache.spark.streaming.dstream.DStream
import org.apache.spark.streaming.StreamingContext

class AtosPipeline extends ConnectionPipeline {

  def getAppName: String = "sp-strm-connection"

  def getCheckpointDir: String = AppConf.SparkAtosCheckpointDirectory

  def getTopicSet: Set[String] = Set(AppConf.KafkaTopicAtos)

  def getGroupId : String = "dtl-connection"

  def process(ssc: StreamingContext, timeout: Long) : Unit = {

    val logDStream: DStream[String] = getInputStream(ssc)

    val connectionDStream: DStream[Connection] = parseToConnection(logDStream)

    processConnection(connectionDStream)
  }

  def parseToConnection: String => Option[Connection] = ConnectionParser.parseLine
}

object AtosPipeline extends AtosPipeline
