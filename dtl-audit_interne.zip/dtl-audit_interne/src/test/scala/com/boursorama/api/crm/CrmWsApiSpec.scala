package com.boursorama.api.crm

import com.boursorama.dtl.business.Client
import com.boursorama.test.SimpleSpec
import com.boursorama.utils.Constants._
import com.boursorama.utils.Conversion._

/**
 * Created by ubuntu on 01/07/16.
 */
class CrmWsApiSpec extends SimpleSpec{

  val sortieFondSuspect: SortieFondSuspect = SortieFondSuspect(
    "CIS",
    201604,
    20160430,
    getDateTime(2016,4,30,19,37,30),
    "W01K02570878784",
    68656476,
    "80.12.59.179",
    30.00,
    "-",
    "-",
    "OTRANSFR",
    "40618",
    "20000",
    "00040327669",
    "555",
    "406182000000040327669978",
    "40618-80263-00040695894-978",
    "FR",
    Some(Client(68656476, 68656476, "NOM-CLIENT", "Prenom-Client", Some(getDateTime(2013, 1, 4, 10, 25, 15)), -10000.0, 5000.0, 1)),
    1000.0,
    TYPE_FRAUDE_EXT_CAVALERIE,
    null)

  "La méthode buildWsCrm" should "renvoyer un objet de type WsCrm " in {

    Given("Une sortie de fond suspecte")

    val apiBuilder = CrmWsApi

    When("On apelle la méthode buildWsRequest")
    val res = apiBuilder.buildWsRequest(sortieFondSuspect)

    Then("L'appel doit être conforme au modèle")
    res.get.toString() should be (
      "HttpRequest(https://crmrec6-fr-web001/boursorama-crm-xmlrpc/rpcTest,POST,StringBodyConnectFunc(action=execute&methodName=monprofil.doQuery&serviceName=CREER_CASE_PF_VIREMENT&params=&params=&params=68656476&params=40618&params=20000&params=00040327669&params=555&params=8-80&params=63-0&params=040695894-&params=78&params=&params=&params=20160430&params=30.0&params=NOM-CLIENT Prenom-Client&optionalParametersCount=0),List(),List((User-Agent,scalaj-http/1.0), (content-type,application/x-www-form-urlencoded), (content-type,application/x-www-form-urlencoded)),List(<function1>, <function1>, <function1>, <function1>, <function1>, <function1>),Some(HTTP @ /10.2.156.2:3128),UTF-8,4096,QueryStringUrlFunc,true)"
    )

  }

}
