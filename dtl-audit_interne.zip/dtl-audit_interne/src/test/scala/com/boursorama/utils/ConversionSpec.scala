package com.boursorama.utils

import com.boursorama.test.SimpleSpec
import com.boursorama.utils.Conversion._
import org.joda.time.DateTime

class ConversionSpec extends SimpleSpec {

  "Conversion" should "convert DateTime values correctly" in {
    Given("Une date heure ")

    var result: DateTime = null

    When("On crèe une date de type DateTime")

    result = getDateTimeIgnoreMsAndTZ("2016-05-30T15:28:28")
    Then("2016-05-30T15:28:28 = " + result)
    result should be(getDateTime(2016, 5, 30, 15, 28, 28))

    result = getDateTime("2016-05-30T15:28:28.303Z")
    Then("2016-05-30T15:28:28.303Z (w/o TimeZone) = " + result)
    result should be(getDateTime(2016, 5, 30, 15, 28, 28, 303))

    result = getDateTime("2016-05-30T17:28:28.303+0200")
    Then("2016-05-30T17:28:28.303+0200 = " + result)
    result should be(getDateTime(2016, 5, 30, 15, 28, 28, 303))

    result = getDateTimeIgnoreMsAndTZ("2016-05-30T17:28:28.303+0200")
    Then("2016-05-30T17:28:28.303+0200 (!!!) != " + result)
    result should be(getDateTime(2016, 5, 30, 17, 28, 28))

    result = getDateTimeFromISO("2016-05-30T17:28:28.303+0200")
    Then("2016-05-30T17:28:28.303+0200 (Iso)  = " + result)
    result should be(getDateTime(2016, 5, 30, 15, 28, 28, 303))

    result = getDateTimeFromISO("2016-05-30T15:28:28.303Z")
    Then("2016-05-30T15:28:28.303Z (Iso)  = " + result)
    result should be(getDateTime(2016, 5, 30, 15, 28, 28, 303))

    result = getDateTimeFromISO("2016-05-30T15:28:28.303")
    Then("2016-05-30T15:28:28.303 (Iso)  = " + result)
    result should be(getDateTime(2016, 5, 30, 15, 28, 28, 303))

    result = getDateTimeFromISO("2016-05-30T15:28:28")
    Then("2016-05-30T15:28:28 (Iso)  = " + result)
    result should be(getDateTime(2016, 5, 30, 15, 28, 28))

    result = getDateTime(2016, 5, 30, 15, 28, 28)
    Then("2016, 5, 30, 15, 28, 28 = " + result)
    result should be(new DateTime(2016, 5, 30, 15, 28, 28))

    result = getDateTime(2016, 5, 30, 15, 28, 28, 303)
    Then("2016, 5, 30, 15, 28, 28 = " + result)
    result should be(new DateTime(2016, 5, 30, 15, 28, 28, 303))

    result = getDateTime(2016, 5, 30, 17, 28, 28, ParisTimeZone)
    Then("2016, 5, 30, 17, 28, 28, ParisTimeZone = " + result)
    result should be(new DateTime(2016, 5, 30, 15, 28, 28))

    result = getDateTime(2016, 5, 30, 17, 28, 28, 303, ParisTimeZone)
    Then("2016, 5, 30, 17, 28, 28, 303, ParisTimeZone = " + result)
    result should be(new DateTime(2016, 5, 30, 15, 28, 28, 303))

    val dateTimeStr = "2016-05-31T15:34:56"
    val valueyyyyMMddTHHmmss = getDateTimeIgnoreMsAndTZ(dateTimeStr)

    When("On appelle getYearMonth")
    val valueYYYYMMFromDateTime = getYearMonth(valueyyyyMMddTHHmmss)
    Then("formatage YYYYMM OK")
    valueYYYYMMFromDateTime should be(201605)

    When("On appelle getIdDimTemps")
    val valueYYYYMMDDFromDateTime = getYearMonthDay(valueyyyyMMddTHHmmss)
    Then("formatage YYYYMMDD OK")
    valueYYYYMMDDFromDateTime should be(20160531)

    When("On appelle getYearMonth")
    val valueYYYYMMFromStr = getYearMonth(dateTimeStr)
    Then("formatage YYYYMM OK")
    valueYYYYMMFromStr should be(201605)

    When("On appelle getIdDimTemps")
    val valueYYYYMMDDFromStr = getYearMonthDay(dateTimeStr)
    Then("formatage YYYYMMDD OK")
    valueYYYYMMDDFromStr should be(20160531)

    When("On appelle getDateTime")
    val dateTimeStr2 = "2016/05/31 12-34-56"
    val valueyyyMMddTHHmmssCustom = getDateTimeIgnoreMsAndTZ(dateTimeStr2, "yyyy/MM/dd HH-mm-ss")
    Then("formatage yyyy/MM/dd HH-mm-ss  OK")
    valueyyyMMddTHHmmssCustom should be( new DateTime(2016, 5, 31, 12, 34, 56) )
  }
}

