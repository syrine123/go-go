package com.boursorama.spark.streaming.notifier

import com.boursorama.api.crm.CrmWsApi

import scala.collection.mutable
import scala.collection.mutable.ArrayBuffer

object SortieFondSuspectCaseWsNotifierMock extends SortieFondSuspectCaseWsNotifier {

  override def wsCall = mockWSCall

  val webServiceCalls = new ArrayBuffer[SortieFondSuspect] with mutable.SynchronizedBuffer[SortieFondSuspect]

  def clearWsCalls() = {
    webServiceCalls.clear()
  }

  def mockWSCall(sortieFondSuspect: SortieFondSuspect): Unit  = {
    println("mockWSCall")
    webServiceCalls += sortieFondSuspect
  }

  def getWebServiceCalls : List[SortieFondSuspect] = {
    webServiceCalls.toList
  }
 }

