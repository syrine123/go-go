package com.boursorama.spark.streaming.pipeline

import com.boursorama.cassandra.CassandraClientSpec
import com.boursorama.dtl.business.Client
import com.boursorama.spark.streaming.notifier.SortieFondSuspectMailNotifier
import com.boursorama.test.SimpleSpec
import com.boursorama.utils.AppConf._
import com.boursorama.utils.Constants._
import com.boursorama.utils.Conversion._
import com.datastax.driver.core.ConsistencyLevel
import org.apache.spark.SparkConf
import org.apache.spark.streaming.{Seconds, StreamingContext}
import org.scalatest.GivenWhenThen


class SortieFondPipelineWithSparkAndPersisteSpecIT extends CassandraClientSpec with GivenWhenThen {

  val sortieFondSuspect1 = SortieFondSuspect (
    "CIS",
    201604,
    20160430,
    getDateTime(2016, 4, 30, 19, 37, 30, ParisTimeZone),
    "W01K02570878784",
    32354028,
    "80.12.59.179",
    2000.0,
    "-",
    "-",
    "OTRANSFR",
    "40618",
    "20000",
    "00040327669",
    "978",
    "406182000000040327669978",
    "40618-80263-00040695894-978",
    "CH",
    Some(Client(32354028,32354028,"NOM-CLIENT","Prenom-Client",getDateTime(2016,1,4,10,25,15), 1500.5, 500.0, 5)),
    -999.5,
    TYPE_FRAUDE_EXT_PAYS_SUSPECT,
    Map("listePaysARisque" -> "HR,MC,LT,RO,CH,LI,BG,EE,CZ,CY")
  )

  // TODO: cas SortieFondSuspect de type cavalerie à trouver
  /*
  val sortieFondSuspect2 = SortieFondSuspect (
    "CIS",
    201604,
    20160430,
    getDateTime(2016, 4, 30, 19, 37, 30, ParisTimeZone),
    "W01K02570878787",
    68656476,
    "80.12.59.179",
    10000.0,
    "-",
    "-",
    "OTRANSFR",
    "40618",
    "20000",
    "00040327669",
    "978",
    "406182000000040327669978",
    "40618-80263-00040695894-978",
    "FR",
    Some(Client(68656476,68656476,"NOM-CLIENT","Prenom-Client",getDateTime(2016,1,4,10,25,15), 1500.5, 5000.0, 2)),
    -13499.5,
    TYPE_FRAUDE_EXT_CAVALERIE,
    Map(
      "seuilSoldeCumulMoinsEgalQue" -> "-5000",
      "seuilCumulRmcPlusEgalQue" -> "1000",
      "seuilMontantPlusEgalQue" -> "1000",
      "seuilAncienneteMoinsEgalQue" -> "730"
    )
  )
  */

  // TODO: cas SortieFondSuspect de type cavalerie à trouver
  /*
  val sortieFondSuspect3 = SortieFondSuspect (
    "CIS",
    201604,
    20160430,
    getDateTime(2016, 4, 30, 19, 37, 30, ParisTimeZone),
    "W01K02570878788",
    68656476,
    "80.12.59.179",
    12550.0,
    "-",
    "-",
    "OTRANSFR",
    "40618",
    "20000",
    "00040327669",
    "978",
    "406182000000040327669978",
    "40618-80263-00040695894-978",
    "CH",
    Some(Client(68656476,68656476,"NOM-CLIENT","Prenom-Client",getDateTime(2016,1,4,10,25,15), 1500.5, 5000.0, 2)),
    -16049.5,
    TYPE_FRAUDE_EXT_CAVALERIE,
    Map(
      "seuilSoldeCumulMoinsEgalQue" -> "-5000",
      "seuilCumulRmcPlusEgalQue" -> "1000",
      "seuilMontantPlusEgalQue" -> "1000",
      "seuilAncienneteMoinsEgalQue" -> "730"
    )
  )
  */

  val sortieFondSuspect4 = SortieFondSuspect(
    "CIS",
    201604,
    20160430,
    getDateTime(2016, 4, 30, 19, 37, 30, ParisTimeZone),
    "W01K02570878788",
    68656476,
    "80.12.59.179",
    12550.0,
    "-",
    "-",
    "OTRANSFR",
    "40618",
    "20000",
    "00040327669",
    "978",
    "406182000000040327669978",
    "40618-80263-00040695894-978",
    "CH",
    Some(
      Client(
        68656476l,
        5234076562l,
        "AUBERT",
        "CATHERINE",
        getDateTime(2016, 3, 22, 23, 0, 0),
        2606.04,
        0.0,
        0)
    ),
    -16049.5,
    TYPE_FRAUDE_EXT_PAYS_SUSPECT,
    Map("listePaysARisque" -> "HR,MC,LT,RO,CH,LI,BG,EE,CZ,CY")
  )


  def getSparkConf() : SparkConf = {
    new SparkConf()
      .setMaster("local[2]")
      .setAppName("test-pipeline")
      .set("spark.executor.memory", "1g")
      .set("spark.cassandra.connection.host", CassandraNodes)
      .set("es.nodes", EsNodes)
      .set("es.port", EsPort)
      .set("es.index.auto.create", "true")
  }

   "Le pipeline ActionInternePipeline" should "transforme les données de log en ActionInterne correctement" in {
     Given("Une implementation du ActionInternePipelineMock fournissant des lignes de log")

     val pipeline = SortieFondPipelineMockKafka

     val logLines = pipeline.getJsonSamplesSet

     When("On lance spark streaming par la methode process et tempo de 5sec")

     val sparkConf = getSparkConf()
     val ssc = new StreamingContext(sparkConf, Seconds(2))
     //ssc.checkpoint("/tmp/spark-checkpoint")

     pipeline.process(ssc, 10000)

     Then("Client cavalerie")
     SortieFondPipelineMockKafka.getClientInformation(68656476l) should be (
       Some(
         Client(
           68656476l,
           68656476l,
           "Oueslati",
           "fares",
           getDateTime(2015, 11, 20, 14, 22, 54),
           10000.0,
           1000.0,
           5)
       )
     )

     Then("2 notifications de sortie de fond suspectes devrées être envoyées par mail")
     pipeline.getMails should have size (2)  // TODO: passer à 4 quand les cas de cavalerie seront ajoutés

     // TODO: cas de CRM case wsCall SortieFondSuspect de type cavalerie à construire
     /*
     Then("2 notifications de case CRM devrées être envoyées")
     pipeline.getWebServiceCalls should have size (2)
     */

     Then("Des notifications de sortie de fond suspectes devrées être envoyées par mail")
     pipeline.getMails should contain (
       "{\"smtpHost\": \"10.4.1.12:25\"," +
         " \"sender\": \"admin.cognos@boursorama.fr\"," +
         " \"to\": \"DTL-Risque@boursorama.fr\"," +
         " \"subject\": \""  + SortieFondSuspectMailNotifier.formatMailSubject(sortieFondSuspect1) + "\"," +
         " \"body\": \"" + SortieFondSuspectMailNotifier.formatMailBody(sortieFondSuspect1) + "\"" +
         "}"
     )

     // TODO: cas de mail de SortieFondSuspect de type cavalerie à construire
     /*
     pipeline.getMails should contain (
       "{\"smtpHost\": \"10.4.1.12:25\"," +
         " \"sender\": \"admin.cognos@boursorama.fr\"," +
         " \"to\": \"DTL-Risque@boursorama.fr\"," +
         " \"subject\": \""  + SortieFondSuspectMailNotifier.formatMailSubject(sortieFondSuspect2) + "\"," +
         " \"body\": \"" + SortieFondSuspectMailNotifier.formatMailBody(sortieFondSuspect2) + "\"" +
         "}"
     )
     */

     // TODO: cas de mail de SortieFondSuspect de type cavalerie à construire
     /*
     pipeline.getMails should contain (
       "{\"smtpHost\": \"10.4.1.12:25\"," +
         " \"sender\": \"admin.cognos@boursorama.fr\"," +
         " \"to\": \"DTL-Risque@boursorama.fr\"," +
         " \"subject\": \""  + SortieFondSuspectMailNotifier.formatMailSubject(sortieFondSuspect3) + "\"," +
         " \"body\": \"" + SortieFondSuspectMailNotifier.formatMailBody(sortieFondSuspect3) + "\"" +
         "}"
     )
     */

     pipeline.getMails should contain (
       "{\"smtpHost\": \"10.4.1.12:25\"," +
         " \"sender\": \"admin.cognos@boursorama.fr\"," +
         " \"to\": \"DTL-Risque@boursorama.fr\"," +
         " \"subject\": \""  + SortieFondSuspectMailNotifier.formatMailSubject(sortieFondSuspect4) + "\"," +
         " \"body\": \"" + SortieFondSuspectMailNotifier.formatMailBody(sortieFondSuspect4) + "\"" +
         "}"
     )

     ssc.stop()
   }
 }

