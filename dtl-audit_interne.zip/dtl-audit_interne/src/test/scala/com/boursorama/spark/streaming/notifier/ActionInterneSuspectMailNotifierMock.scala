package com.boursorama.spark.streaming.notifier

import com.boursorama.dtl.business.ActionInterneSuspect
import scala.collection.mutable
import scala.collection.mutable.ArrayBuffer

object ActionInterneSuspectMailNotifierMock extends ActionInterneSuspectMailNotifier {

  val mails = new ArrayBuffer[String] with mutable.SynchronizedBuffer[String]

  override def notifySuspect(internSuspect: ActionInterneSuspect): Unit = {
    mails += sendMail(internSuspect, true)
  }

  def clearMails() = {
    mails.clear()
  }

  def getMails : List[String] = {
    mails.toList
  }
 }

