package com.boursorama.spark.streaming.detector

import com.boursorama.dtl.business.Client
import com.boursorama.spark.streaming.parser.{ActionExterneCisParser, ActionInterneAtosParser}
import com.boursorama.spark.streaming.pipeline.SortieFondPipelineMockAll
import com.boursorama.test.SimpleSpec
import com.boursorama.utils.Constants._
import com.boursorama.utils.Conversion._

class SortieFondSuspectDetectorSpec extends SimpleSpec {

    "La méthode suspect" should "ne pas trouver de cas suspect" in {
      Given("Une ligne de log CIS Externe au format JSON")

      val logLineCisFR = "{  \"@version\": \"1\",    \"@timestamp\": \"2016-05-03T09:34:53.628Z\",    \"host\": \"tupocbi005\",    \"path\": \"/logcisprod/LOGCISW-C-20160430-193741.CSV\",    \"type\": \"cis-web\",    \"NOM SERVICE\": \"WE01KS01K\",    \"ID TRANSAC\": \"W01K02570878784\",    \"COD ASI\": \"000000000000000\",    \"COD SOP\": \"0000\",    \"ID IP\": \"80.12.59.179\",    \"ID SEANCE\": \"90795\",    \"COD UTI SFW\": \"65545919\",    \"TYP UTIL\": \"2\",    \"NUM ORDRE\": null,    \"COD AGENT\": null,    \"NOM AGENT\": null,    \"NUM TEL\": null,    \"NIV ACCES\": \"2\",    \"COD UTI BRS\": null,    \"TYP ACCES\": \"I\",    \"ID INTERNE\": \"00729913\",    \"COD CANAL\": \"W\",    \"COD OPER\": \"OTRANSFR\",    \"ANN DEBUT\": \"2016\",    \"MOI DEBUT\": \"04\",    \"JOU DEBUT\": \"30\",    \"HEU DEBUT\": \"193730\",    \"HEU MSC DEB\": \"313\",    \"ANN FIN\": \"2016\",    \"MOI FIN\": \"04\",    \"JOU FIN\": \"30\",    \"HEU FIN\": \"193731\",    \"HEU MSC FIN\": \"218\",    \"COD FIN\": \"1\",    \"COD MSGEXT\": null,    \"LIB EXT\": null,    \"COD MSGINT\": null,    \"LIB INT\": null,    \"COD BQE OP\": \"40618\",    \"COD AGE OP\": \"20000\",    \"NUM CON OP\": \"00040327669\",    \"DEV CON OP\": \"978\",    \"MTT OP\": \"10000\",    \"DEV MTT\": \"978\",    \"MTT CVAL\": \"00000000000.00\",    \"DV MTT CVAL\": null,    \"QUAN OP\": \"000\",    \"INFO OPER\": \"02-05-2016 / 20000-00016185073     / GTSEPAP\",    \"INFO OPER2\": \"40618-80263-00040695894-978\",    \"COD ASI OP\": \"060200002195876\",    \"COD SOP OP\": \"0000\",    \"ANN MAJ\": \"2016\",    \"JOU MAJ\": \"30\",    \"MOI MAJ\": \"04\",    \"HEU MAJ\": \"193731\",    \"ID OPER\": \"1462037849\",    \"NOM ABR\": \"DEVAUDBRUNO\", \"codePaysCible\": \"FR\", \"LIB TRANS\": \"Creation TRANSFERT\"\n}"

      When("On apelle la méthode parseLine puis on applique la detection des actions suspectes")
      val sortieFond = ActionExterneCisParser.parseLine(logLineCisFR)
      val sortieFondEnriched = SortieFondPipelineMockAll.enrichiSortieFond(sortieFond.get)
      val suspect = SortieFondSuspectDetectorMock.suspect(sortieFondEnriched.get)

      Then("Une sortie de fond est retournée")
      sortieFondEnriched.get should be (
        SortieFond(
          "CIS",
          201604,
          20160430,
          getDateTime(2016, 4, 30, 19, 37, 30, ParisTimeZone),
          "W01K02570878784",
          65545919,
          "80.12.59.179",
          10000.0,
          "-",
          "-",
          "OTRANSFR",
          "40618",
          "20000",
          "00040327669",
          "978",
          "406182000000040327669978",
          "40618-80263-00040695894-978",
          "FR",
          Some(Client(65545919, 65545919, "NOM-CLIENT", "Prenom-Client", getDateTime(2013, 1, 4, 10, 25, 15), -10000.0, 5000.0, 1)),
          -25000.0,
          logLineCisFR,
          "OUTGOING_TRANSFERE"
        )
      )

      Then("Aucune Sortie Fond suspecte n'est retournée")
      suspect should have size ( 0 )

    }

  "La méthode suspect" should "trouver un cas de pays suspect" in {
    Given("Une ligne de log CIS Externe au format JSON")

    val logLineCisCH = "{  \"@version\": \"1\",    \"@timestamp\": \"2016-05-03T09:34:53.628Z\",    \"host\": \"tupocbi005\",    \"path\": \"/logcisprod/LOGCISW-C-20160430-193741.CSV\",    \"type\": \"cis-web\",    \"NOM SERVICE\": \"WE01KS01K\",    \"ID TRANSAC\": \"W01K02570878784\",    \"COD ASI\": \"000000000000000\",    \"COD SOP\": \"0000\",    \"ID IP\": \"80.12.59.179\",    \"ID SEANCE\": \"90795\",    \"COD UTI SFW\": \"32354028\",    \"TYP UTIL\": \"2\",    \"NUM ORDRE\": null,    \"COD AGENT\": null,    \"NOM AGENT\": null,    \"NUM TEL\": null,    \"NIV ACCES\": \"2\",    \"COD UTI BRS\": null,    \"TYP ACCES\": \"I\",    \"ID INTERNE\": \"00729913\",    \"COD CANAL\": \"W\",    \"COD OPER\": \"OTRANSFR\",    \"ANN DEBUT\": \"2016\",    \"MOI DEBUT\": \"04\",    \"JOU DEBUT\": \"30\",    \"HEU DEBUT\": \"193730\",    \"HEU MSC DEB\": \"313\",    \"ANN FIN\": \"2016\",    \"MOI FIN\": \"04\",    \"JOU FIN\": \"30\",    \"HEU FIN\": \"193731\",    \"HEU MSC FIN\": \"218\",    \"COD FIN\": \"1\",    \"COD MSGEXT\": null,    \"LIB EXT\": null,    \"COD MSGINT\": null,    \"LIB INT\": null,    \"COD BQE OP\": \"40618\",    \"COD AGE OP\": \"20000\",    \"NUM CON OP\": \"00040327669\",    \"DEV CON OP\": \"978\",    \"MTT OP\": \"3000\",    \"DEV MTT\": \"978\",    \"MTT CVAL\": \"00000000000.00\",    \"DV MTT CVAL\": null,    \"QUAN OP\": \"000\",    \"INFO OPER\": \"02-05-2016 / 20000-00016185073     / GTSEPAP\",    \"INFO OPER2\": \"40618-80263-00040695894-978\",    \"COD ASI OP\": \"060200002195876\",    \"COD SOP OP\": \"0000\",    \"ANN MAJ\": \"2016\",    \"JOU MAJ\": \"30\",    \"MOI MAJ\": \"04\",    \"HEU MAJ\": \"193731\",    \"ID OPER\": \"1462037849\",    \"NOM ABR\": \"DEVAUDBRUNO\", \"codePaysCible\": \"CH\", \"LIB TRANS\": \"Creation TRANSFERT\"\n}"

      When("On apelle la méthode parseLine puis on applique la detection des actions suspectes")
    val sortieFond = ActionExterneCisParser.parseLine(logLineCisCH)
    val sortieFondEnriched = SortieFondPipelineMockAll.enrichiSortieFond(sortieFond.get)
    val suspect = SortieFondSuspectDetectorMock.suspect(sortieFondEnriched.get)

        Then("Une ActionInterneSuspecte est retournée")
        suspect(0) should be (
          SortieFondSuspect(
            "CIS",
            201604,
            20160430,
            getDateTime(2016, 4, 30, 19, 37, 30, ParisTimeZone),
            "W01K02570878784",
            32354028,
            "80.12.59.179",
            3000.0,
            "-",
            "-",
            "OTRANSFR",
            "40618",
            "20000",
            "00040327669",
            "978",
            "406182000000040327669978",
            "40618-80263-00040695894-978",
            "CH",
            Some(Client(32354028, 32354028, "NOM-CLIENT", "Prenom-Client", getDateTime(2016, 1, 4, 10, 25, 15), 1500.5, 500.0, 5)),
            -1999.5,
            TYPE_FRAUDE_EXT_PAYS_SUSPECT,
            Map("listePaysARisque" -> "HR,MC,LT,RO,CH,LI,BG,EE,CZ,CY")
          )
        )
    }

  "La méthode suspect" should "trouver un cas de cavalerie" in {
    Given("Une ligne de log CIS Externe au format JSON")

    val logLineCisFRCaval = "{  \"@version\": \"1\",    \"@timestamp\": \"2016-05-03T09:34:53.628Z\",    \"host\": \"tupocbi005\",    \"path\": \"/logcisprod/LOGCISW-C-20160430-193741.CSV\",    \"type\": \"cis-web\",    \"NOM SERVICE\": \"WE01KS01K\",    \"ID TRANSAC\": \"W01K02570878784\",    \"COD ASI\": \"000000000000000\",    \"COD SOP\": \"0000\",    \"ID IP\": \"80.12.59.179\",    \"ID SEANCE\": \"90795\",    \"COD UTI SFW\": \"68656476\",    \"TYP UTIL\": \"2\",    \"NUM ORDRE\": null,    \"COD AGENT\": null,    \"NOM AGENT\": null,    \"NUM TEL\": null,    \"NIV ACCES\": \"2\",    \"COD UTI BRS\": null,    \"TYP ACCES\": \"I\",    \"ID INTERNE\": \"00729913\",    \"COD CANAL\": \"W\",    \"COD OPER\": \"OTRANSFR\",    \"ANN DEBUT\": \"2016\",    \"MOI DEBUT\": \"04\",    \"JOU DEBUT\": \"30\",    \"HEU DEBUT\": \"193730\",    \"HEU MSC DEB\": \"313\",    \"ANN FIN\": \"2016\",    \"MOI FIN\": \"04\",    \"JOU FIN\": \"30\",    \"HEU FIN\": \"193731\",    \"HEU MSC FIN\": \"218\",    \"COD FIN\": \"1\",    \"COD MSGEXT\": null,    \"LIB EXT\": null,    \"COD MSGINT\": null,    \"LIB INT\": null,    \"COD BQE OP\": \"40618\",    \"COD AGE OP\": \"20000\",    \"NUM CON OP\": \"00040327669\",    \"DEV CON OP\": \"978\",    \"MTT OP\": \"2000\",    \"DEV MTT\": \"978\",    \"MTT CVAL\": \"00000000000.00\",    \"DV MTT CVAL\": null,    \"QUAN OP\": \"000\",    \"INFO OPER\": \"02-05-2016 / 20000-00016185073     / GTSEPAP\",    \"INFO OPER2\": \"40618-80263-00040695894-978\",    \"COD ASI OP\": \"060200002195876\",    \"COD SOP OP\": \"0000\",    \"ANN MAJ\": \"2016\",    \"JOU MAJ\": \"30\",    \"MOI MAJ\": \"04\",    \"HEU MAJ\": \"193731\",    \"ID OPER\": \"1462037849\",    \"NOM ABR\": \"DEVAUDBRUNO\", \"codePaysCible\": \"FR\", \"LIB TRANS\": \"Creation TRANSFERT\"\n}"

    When("On apelle la méthode parseLine puis on applique la detection des actions suspectes")
    val sortieFond = ActionExterneCisParser.parseLine(logLineCisFRCaval)
    val sortieFondEnriched = SortieFondPipelineMockAll.enrichiSortieFond(sortieFond.get)
    val suspect = SortieFondSuspectDetectorMock.suspect(sortieFondEnriched.get)

    Then("Une sortie fond cavalerie est retournée")
    suspect(0) should be (
      SortieFondSuspect (
        "CIS",
        201604,
        20160430,
        getDateTime(2016, 4, 30, 19, 37, 30, ParisTimeZone),
        "W01K02570878784",
        68656476,
        "80.12.59.179",
        2000,
        "-",
        "-",
        "OTRANSFR",
        "40618",
        "20000",
        "00040327669",
        "978",
        "406182000000040327669978",
        "40618-80263-00040695894-978",
        "FR",
        Some(Client(68656476,68656476,"NOM-CLIENT","Prenom-Client",getDateTime(2016,1,4,10,25,15), 1500.5, 5000.0, 2)),
        -5499.5,
        TYPE_FRAUDE_EXT_CAVALERIE,
        Map(
          "seuilSoldeCumulMoinsEgalQue" -> "-5000",
          "seuilCumulRmcPlusEgalQue" -> "1000",
          "seuilMontantPlusEgalQue" -> "1000",
          "seuilAncienneteMoinsEgalQue" -> "730"
        )
      )
    )
  }

  "La méthode suspect" should "trouver un cas de cavalerie et pays suspect" in {
    Given("Une ligne de log CIS Externe au format JSON")

    val logLineCisFRCaval = "{  \"@version\": \"1\",    \"@timestamp\": \"2016-05-03T09:34:53.628Z\",    \"host\": \"tupocbi005\",    \"path\": \"/logcisprod/LOGCISW-C-20160430-193741.CSV\",    \"type\": \"cis-web\",    \"NOM SERVICE\": \"WE01KS01K\",    \"ID TRANSAC\": \"W01K02570878784\",    \"COD ASI\": \"000000000000000\",    \"COD SOP\": \"0000\",    \"ID IP\": \"80.12.59.179\",    \"ID SEANCE\": \"90795\",    \"COD UTI SFW\": \"68656476\",    \"TYP UTIL\": \"2\",    \"NUM ORDRE\": null,    \"COD AGENT\": null,    \"NOM AGENT\": null,    \"NUM TEL\": null,    \"NIV ACCES\": \"2\",    \"COD UTI BRS\": null,    \"TYP ACCES\": \"I\",    \"ID INTERNE\": \"00729913\",    \"COD CANAL\": \"W\",    \"COD OPER\": \"OTRANSFR\",    \"ANN DEBUT\": \"2016\",    \"MOI DEBUT\": \"04\",    \"JOU DEBUT\": \"30\",    \"HEU DEBUT\": \"193730\",    \"HEU MSC DEB\": \"313\",    \"ANN FIN\": \"2016\",    \"MOI FIN\": \"04\",    \"JOU FIN\": \"30\",    \"HEU FIN\": \"193731\",    \"HEU MSC FIN\": \"218\",    \"COD FIN\": \"1\",    \"COD MSGEXT\": null,    \"LIB EXT\": null,    \"COD MSGINT\": null,    \"LIB INT\": null,    \"COD BQE OP\": \"40618\",    \"COD AGE OP\": \"20000\",    \"NUM CON OP\": \"00040327669\",    \"DEV CON OP\": \"978\",    \"MTT OP\": \"2000\",    \"DEV MTT\": \"978\",    \"MTT CVAL\": \"00000000000.00\",    \"DV MTT CVAL\": null,    \"QUAN OP\": \"000\",    \"INFO OPER\": \"02-05-2016 / 20000-00016185073     / GTSEPAP\",    \"INFO OPER2\": \"40618-80263-00040695894-978\",    \"COD ASI OP\": \"060200002195876\",    \"COD SOP OP\": \"0000\",    \"ANN MAJ\": \"2016\",    \"JOU MAJ\": \"30\",    \"MOI MAJ\": \"04\",    \"HEU MAJ\": \"193731\",    \"ID OPER\": \"1462037849\",    \"NOM ABR\": \"DEVAUDBRUNO\", \"codePaysCible\": \"CH\", \"LIB TRANS\": \"Creation TRANSFERT\"\n}"

    When("On apelle la méthode parseLine puis on applique la detection des actions suspectes")
    val sortieFond = ActionExterneCisParser.parseLine(logLineCisFRCaval)
    val sortieFondEnriched = SortieFondPipelineMockAll.enrichiSortieFond(sortieFond.get)
    val suspect = SortieFondSuspectDetectorMock.suspect(sortieFondEnriched.get)

    Then("Une sortie fond pays suspect est retournée")
    suspect should contain allOf (
      SortieFondSuspect (
        "CIS",
        201604,
        20160430,
        getDateTime(2016, 4, 30, 19, 37, 30, ParisTimeZone),
        "W01K02570878784",
        68656476,
        "80.12.59.179",
        2000,
        "-",
        "-",
        "OTRANSFR",
        "40618",
        "20000",
        "00040327669",
        "978",
        "406182000000040327669978",
        "40618-80263-00040695894-978",
        "CH",
        Some(Client(68656476,68656476,"NOM-CLIENT","Prenom-Client",getDateTime(2016,1,4,10,25,15), 1500.5, 5000.0, 2)),
        -5499.5,
        TYPE_FRAUDE_EXT_PAYS_SUSPECT,
        Map("listePaysARisque" -> "HR,MC,LT,RO,CH,LI,BG,EE,CZ,CY")
      ),
      SortieFondSuspect (
        "CIS",
        201604,
        20160430,
        getDateTime(2016, 4, 30, 19, 37, 30, ParisTimeZone),
        "W01K02570878784",
        68656476,
        "80.12.59.179",
        2000.0,
        "-",
        "-",
        "OTRANSFR",
        "40618",
        "20000",
        "00040327669",
        "978",
        "406182000000040327669978",
        "40618-80263-00040695894-978",
        "CH",
        Some(Client(68656476,68656476,"NOM-CLIENT","Prenom-Client",getDateTime(2016,1,4,10,25,15), 1500.5, 5000.0, 2)),
        -5499.5,
        TYPE_FRAUDE_EXT_CAVALERIE,
        Map(
          "seuilSoldeCumulMoinsEgalQue" -> "-5000",
          "seuilCumulRmcPlusEgalQue" -> "1000",
          "seuilMontantPlusEgalQue" -> "1000",
          "seuilAncienneteMoinsEgalQue" -> "730"
        )
      )
    )
  }
 }
