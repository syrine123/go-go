package com.boursorama.spark.streaming.parser

import java.text.SimpleDateFormat
import com.boursorama.dtl.business.ActionInterne
import com.boursorama.test.SimpleSpec
import org.joda.time.DateTime
import com.boursorama.utils.Conversion._
import org.scalatest.GivenWhenThen

class ActionInterneAtosParserSpec extends SimpleSpec with GivenWhenThen {

  "La méthode parseLine" should "parser une ligne de log ATOS au format JSON à la sortie de logstash" in {
    Given("Une ligne de log ATOS au format JSON")
    val atosInterneLine = "{  \"@version\" : \"1\",     \"@timestamp\" : \"2015-11-20T14:22:54Z\",  \"type\" : \"ATOS\",                    \"ID\" : \"201602-16172085\",                  \"Date\" : \"2016-02-25 19:10:22.0\",               \"Source\" : \"GTW\",                  \"Module\" : \"USERACCOUNT\",               \"ManagerID\" : \"61209\",                  \"UserID\" : \"1894578\",                 \"Account\" : null,             \"Office Code\" : null,               \"Bank Code\" : null,           \"Security Code\" : null,    \"Security Exchange ID\" : null,      \"Security ID source\" : null,                 \"OrderID\" : null,               \"IP Adress\" : \"192.168.5.2\",                \"Message\" : \"Session Logout - managerMediaID=OMS sessionID=9DBED22558F81B99BD0338B9EC639081.EDCE47CFEA8E148EEA\",          \"managerMediaID\" : \"OMS\",               \"sessionID\" : \"9DBED22558F81B99BD0338B9EC639081.EDCE47CFEA8E148EEA\",            \"Information\" : \"Session Logout\",              \"login_user\" : \"LGRENAUL\"}"

    When("On apelle la méthode parseLine")
    val result = ActionInterneAtosParser.parseLine(atosInterneLine)

    Then("Une ActionInterne case class est retourné")
      result should be (
        Some(ActionInterne(
          "ATOS",
          201602,
          20160225,
          getDateTime("2016-02-25T19:10:22.000Z"),
          "LGRENAUL",
          "-",
          "Session Logout",
          "-",
          "-",
          "192.168.5.2",
          Some(1894578L),
          None,
          "-",
          "-",
          "-",
          "9DBED22558F81B99BD0338B9EC639081.EDCE47CFEA8E148EEA",
          atosInterneLine
        )
      )
    )
  }
}
