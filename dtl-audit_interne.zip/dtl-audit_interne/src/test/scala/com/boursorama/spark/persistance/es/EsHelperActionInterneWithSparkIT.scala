package com.boursorama.spark.persistance.es

import com.boursorama.dtl.business.ActionInterne
import com.boursorama.test.{SparkStreamingTestHelper, SimpleSpec}
import com.boursorama.utils.AppConf._
import com.boursorama.utils.Conversion._
import org.apache.spark.SparkConf
import org.apache.spark.streaming.{Seconds, StreamingContext}
import org.scalatest.GivenWhenThen

class EsHelperActionInterneWithSparkIT extends SimpleSpec with GivenWhenThen {

  def getSparkConf() : SparkConf = {
    new SparkConf()
      .setMaster("local[2]")
      .setAppName("test-pipeline")
      .set("spark.executor.memory", "1g")
      .set("es.nodes", EsNodes)
      .set("es.port", EsPort)
      .set("es.index.auto.create", "true")
  }

   "La classe EsHelper" should "indexe les donnes dans ES via Spark" in {

     Given("Une collection de champs")

     val listeAction = List(
       ActionInterne (
         "TEST",
         201503,
         20150330,
         getDateTime(2015,3,30,20,0,0),
         "USER1",
         "OP1",
         "Operation 1",
         "OP1-SOP1",
         "Sous Operation 1.1",
         "1.1.1.1",
         Some(102L),
         None,
         "10001.00000001.99",
         "USER1Nom",
         "USER1Prenom",
         "32354028789-1",
         "log-data-1"
       ),
       ActionInterne (
         "TEST",
         201504,
         20150410,
         getDateTime(2015,4,10,23,0,0),
         "USER2",
         "OP2",
         "Operation 2",
         "OP2-SOP2",
         "Sous Operation 2.2",
         "2.2.2.2",
         Some(102L),
         None,
         "10001.00000002.99",
         "USER2Nom",
         "USER2Prenom",
         "32354028789-2",
         "log-data-2"
       ),
       ActionInterne (
         "TEST",
         201606,
         20160605,
         getDateTime(2016,6,5,5,0,0),
         "USER3",
         "OP3",
         "Operation 3",
         "OP3-SOP3",
         "Sous Operation 3.3",
         "3.3.3.3",
         Some(103L),
         None,
         "10001.00000003.99",
         "USER3Nom",
         "USER3Prenom",
         "32354028789-3",
         "log-data-3"
       )
     )
     When("On lance spark streaming par la methode process et tempo de 5sec")

     val sparkConf = getSparkConf()
     val ssc = new StreamingContext(sparkConf, Seconds(1))
     //ssc.checkpoint("/tmp/spark-checkpoint")

     val SparkStreamingTestHelper = new SparkStreamingTestHelper[ActionInterne]()

     val actionInterneDStream = SparkStreamingTestHelper.initInputStream(ssc)
     var count = 0
     actionInterneDStream.foreachRDD( rdd => { count += rdd.collect().length} )
     EsHelper.persisteActionInterne(actionInterneDStream)

     ssc.start()

     SparkStreamingTestHelper.pushToStream(ssc, listeAction)

     ssc.awaitTerminationOrTimeout(5000)

     Then("Les (3) ActionInternes sont indexées")
     count should be (3)

     ssc.stop()
     }
 }

