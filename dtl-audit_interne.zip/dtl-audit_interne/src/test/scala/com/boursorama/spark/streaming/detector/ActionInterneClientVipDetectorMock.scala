package com.boursorama.spark.streaming.detector

object ActionInterneClientVipDetectorMock extends ActionInterneClientVipDetector {

   var mockParamsMap = Map[String, String]("listeClientsVip" -> "32354028")

   override def getFraudeParams() : Map[String, String] = {
     mockParamsMap
   }
 }
