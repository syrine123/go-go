package com.boursorama.spark.streaming.notifier

import scala.collection.mutable
import scala.collection.mutable.ArrayBuffer

object SortieFondSuspectCaseWsInspectedNotifier extends SortieFondSuspectCaseWsNotifier {

  override def wsCall = mockWSCall

  val webServiceCalls = new ArrayBuffer[SortieFondSuspect] with mutable.SynchronizedBuffer[SortieFondSuspect]

  def clearWsCalls() = {
    webServiceCalls.clear()
  }

  def mockWSCall(sortieFondSuspect: SortieFondSuspect): Unit  = {
    super.wsCall(sortieFondSuspect)
    webServiceCalls += sortieFondSuspect
  }

  def getWebServiceCalls : List[SortieFondSuspect] = {
    webServiceCalls.toList
  }
 }

