package com.boursorama.spark.streaming.detector

import com.boursorama.dtl.business.{Client, ActionInterneSuspect}
import com.boursorama.spark.streaming.parser.ActionInterneAtosParser
import com.boursorama.test.SimpleSpec
import com.boursorama.utils.Constants._
import com.boursorama.utils.Conversion._

class ActionInterneSuspectDetectorSpec extends SimpleSpec {

    "La méthode suspect" should "ne pas trouver de cas suspect" in {
      Given("Une ligne de log ATOS au format JSON")

      val atosInterneLine = "{  \"@version\" : \"1\",     \"@timestamp\" : \"2015-11-20T14:22:54Z\",  \"type\" : \"ATOS\",                    \"ID\" : \"201602-16172085\",                  \"Date\" : \"2015-11-20 14:22:54\",               \"Source\" : \"GTW\",                  \"Module\" : \"USERACCOUNT\",               \"ManagerID\" : \"61209\",                  \"UserID\" : \"1894578\",                 \"Account\" : null,             \"Office Code\" : null,               \"Bank Code\" : null,           \"Security Code\" : null,    \"Security Exchange ID\" : null,      \"Security ID source\" : null,                 \"OrderID\" : null,               \"IP Adress\" : \"192.168.5.2\",                \"Message\" : \"Session Logout - managerMediaID=OMS sessionID=9DBED22558F81B99BD0338B9EC639081.EDCE47CFEA8E148EEA\",          \"managerMediaID\" : \"OMS\",               \"sessionID\" : \"9DBED22558F81B99BD0338B9EC639081.EDCE47CFEA8E148EEA\",            \"Information\" : \"Session Logout\",              \"login_user\" : \"LGRENAUL\"}"

      When("On apelle la méthode parseLine puis on applique la detection des actions suspectes")
      val actionInterne = ActionInterneAtosParser.parseLine(atosInterneLine)
      val suspect = ActionInterneSuspectDetectorMock.suspect(actionInterne.get)

      Then("Aucune ActionInterneSuspecte n'est retournée")
      suspect should have length ( 0 )

    }

    "La méthode suspect" should "trouver un cas de heure suspecte" in {
        Given("Une ligne de log ATOS au format JSON")

        val atosInterneLine = "{  \"@version\" : \"1\",     \"@timestamp\" : \"2015-11-20T22:15:54Z\",  \"type\" : \"ATOS\",                    \"ID\" : \"201602-16172085\",                  \"Date\" : \"2015-11-20 22:15:54\",               \"Source\" : \"GTW\",                  \"Module\" : \"USERACCOUNT\",               \"ManagerID\" : \"61209\",                  \"UserID\" : \"1894578\",                 \"Account\" : null,             \"Office Code\" : null,               \"Bank Code\" : null,           \"Security Code\" : null,    \"Security Exchange ID\" : null,      \"Security ID source\" : null,                 \"OrderID\" : null,               \"IP Adress\" : \"192.168.5.2\",                \"Message\" : \"Session Logout - managerMediaID=OMS sessionID=9DBED22558F81B99BD0338B9EC639081.EDCE47CFEA8E148EEA\",          \"managerMediaID\" : \"OMS\",               \"sessionID\" : \"9DBED22558F81B99BD0338B9EC639081.EDCE47CFEA8E148EEA\",            \"Information\" : \"Session Logout\",              \"login_user\" : \"LGRENAUL\"}"

        When("On apelle la méthode parseLine puis on applique la detection des actions suspectes")
        val actionInterne = ActionInterneAtosParser.parseLine(atosInterneLine)
        val suspects = ActionInterneSuspectDetectorMock.suspect(actionInterne.get)

        Then("Une ActionInterneSuspecte est retournée")
        suspects should contain (
          ActionInterneSuspect(
            "ATOS",
            201511,
            20151120,
            getDateTime(2015, 11, 20, 22, 15, 54),
            "LGRENAUL",
            "-",
            "Session Logout",
            "-",
            "-",
            "192.168.5.2",
            1894578,
            None,
            "-",
            "-",
            "-",
            "9DBED22558F81B99BD0338B9EC639081.EDCE47CFEA8E148EEA",
            TYPE_FRAUDE_INT_HEURE_SUSPECTE,
            Map(("seuilHeureSuspectePlusQue", "22"), ("seuilHeureSuspecteMoinsQue", "5")),
            atosInterneLine
          )
        )
    }

  "La méthode suspect" should "trouver un cas de encours sup à 1000" in {
    Given("Une ligne de log ATOS au format JSON")

    val atosInterneLine = "{  \"@version\" : \"1\",     \"@timestamp\" : \"2015-11-20T15:15:54Z\",  \"type\" : \"ATOS\",                    \"ID\" : \"32354028\",                  \"Date\" : \"2015-11-20 15:15:54\",               \"Source\" : \"GTW\",                  \"Module\" : \"USERACCOUNT\",               \"ManagerID\" : \"61209\",                  \"UserID\" : \"1894578\",                 \"Account\" : null,             \"Office Code\" : null,               \"Bank Code\" : null,           \"Security Code\" : null,    \"Security Exchange ID\" : null,      \"Security ID source\" : null,                 \"OrderID\" : null,               \"IP Adress\" : \"192.168.5.2\",                \"Message\" : \"Session Logout - managerMediaID=OMS sessionID=9DBED22558F81B99BD0338B9EC639081.EDCE47CFEA8E148EEA\",          \"managerMediaID\" : \"OMS\",               \"sessionID\" : \"9DBED22558F81B99BD0338B9EC639081.EDCE47CFEA8E148EEA\",            \"Information\" : \"Session Logout\",              \"login_user\" : \"LGRENAUL\"}"
    val clientEncoursPlus = Client(
      32354028l,
      32354028l,
      "NOM-CLIENT",
      "Prenom-Client",
      getDateTime(2016, 1, 4, 10, 25, 15),
      1500.50,
      500.0,
      5
    )

    When("On apelle la méthode parseLine puis on applique la detection des actions suspectes")
    val actionInterne = ActionInterneAtosParser.parseLine(atosInterneLine)
    val actionInterneEnriched = actionInterne.get.copy( client = Some(clientEncoursPlus) )
    val suspects = ActionInterneSuspectDetectorMock.suspect(actionInterneEnriched)

    Then("Une ActionInterneSuspecte est retournée")
    suspects should have size (2)

    Then("Une ActionInterneSuspecte est retournée")
    suspects should contain allOf (
      ActionInterneSuspect(
        "ATOS",
        201511,
        20151120,
        getDateTime(2015, 11, 20, 15, 15, 54),
        "LGRENAUL",
        "-",
        "Session Logout",
        "-",
        "-",
        "192.168.5.2",
        1894578,
        Some(clientEncoursPlus),
        "-",
        "-",
        "-",
        "9DBED22558F81B99BD0338B9EC639081.EDCE47CFEA8E148EEA",
        TYPE_FRAUDE_INT_ENCOURS_SUPERIEUR,
        Map(("seuilEncoursPlusEgalQue", "1000")),
        atosInterneLine
      ),
      ActionInterneSuspect(
        "ATOS",
        201511,
        20151120,
        getDateTime(2015, 11, 20, 15, 15, 54),
        "LGRENAUL",
        "-",
        "Session Logout",
        "-",
        "-",
        "192.168.5.2",
        1894578,
        Some(clientEncoursPlus),
        "-",
        "-",
        "-",
        "9DBED22558F81B99BD0338B9EC639081.EDCE47CFEA8E148EEA",
        TYPE_FRAUDE_INT_CLIENT_VIP,
        Map(("listeClientsVip", "32354028")),
        atosInterneLine
      )
    )
  }
 }
