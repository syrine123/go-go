package com.boursorama.spark.persistance.cassandra

import com.boursorama.cassandra.CassandraClientSpec
import com.boursorama.dtl.business.Client
import com.boursorama.test.{SimpleSpec, SparkStreamingTestHelper}
import com.boursorama.utils.AppConf._
import com.boursorama.utils.Conversion._
import org.apache.spark.SparkConf
import org.apache.spark.streaming.{Seconds, StreamingContext}
import org.scalatest.GivenWhenThen

class CassandraHelperSortieFondWithSparkIT extends CassandraClientSpec with GivenWhenThen {

  def getSparkConf() : SparkConf = {
    println("CassandraHostName : " + CassandraNodes)
    new SparkConf()
      .setMaster("local[2]")
      .setAppName("test-pipeline")
      .set("spark.executor.memory", "1g")
      .set("spark.cassandra.connection.host", CassandraNodes)
      //.set("spark.streaming.concurrentJobs", "5")
  }


   "La classe CassandraHelper" should "persister les données dans Cassandra via Spark" in {

     Given("Une collection de champs")

     val listeAction = List(
       SortieFond("sys_origine", 201503, 20150330, getDateTimeIgnoreMsAndTZ("2015-03-30T23:00:00"), "id_transaction", 1234, "2.2.2.2", 120.2, "status", "error", "code operation", "10001", "000000", "1111", "cle rib", "iban source", "ibancible", "FR", Some(Client(0,0,"","",getDateTimeIgnoreMsAndTZ("2015-03-30T23:00:00"),0.0,0.0,0)), 0.0, ""),
       SortieFond("sys_origine", 201503, 20150330, getDateTimeIgnoreMsAndTZ("2015-03-30T23:00:00"), "id_transaction", 1234, "2.2.2.2", 120.2, "status", "error", "code operation", "10001", "000000", "1111", "cle rib", "iban source", "ibancible", "FR", None, 0.0, "")
     )

     //CassandraTestTablespace.deleteCassandra
     //CassandraTestTablespace.initCassandra

     When("On appelle CassandraHelper")


     Then("Les données sortie de fonds sont persistées dans Cassandra")
     0 should be (0)

     val sparkConf = getSparkConf()
     val ssc = new StreamingContext(sparkConf, Seconds(1))
     //ssc.checkpoint("/tmp/spark-checkpoint")

     val SparkStreamingTestHelper = new SparkStreamingTestHelper[SortieFond]
     val actionDStream = SparkStreamingTestHelper.initInputStream(ssc)

     var count = 0
     actionDStream.foreachRDD( rdd => { count += rdd.collect().length} )
     CassandraHelper.persisteSortieFond(actionDStream)

     ssc.start()

     SparkStreamingTestHelper.pushToStream(ssc, listeAction)

     ssc.awaitTerminationOrTimeout(10000)

     Then("Les (2) actions sont indexées")
     count should be (2)

     ssc.stop()
     }
  //}

 }

