package com.boursorama.spark.streaming.pipeline

import com.boursorama.cassandra.{CassandraClient, CassandraClientSpec}
import com.boursorama.dtl.business.{ActionInterne, ActionInterneSuspect}
import com.boursorama.test.SimpleSpec
import com.boursorama.utils.AppConf._
import com.boursorama.utils.Constants._
import com.boursorama.utils.Conversion
import com.boursorama.utils.Conversion._
import com.datastax.driver.core.ConsistencyLevel
import org.apache.spark.SparkConf
import org.apache.spark.streaming.{Seconds, StreamingContext}
import org.scalatest.GivenWhenThen

class ActionInternePipelineWithSparkAndPersisteSpecIT extends CassandraClientSpec with GivenWhenThen {

  def getSparkConf() : SparkConf = {
    new SparkConf()
      .setMaster("local[2]")
      .setAppName("test-pipeline")
      .set("spark.executor.memory", "1g")
      .set("spark.cassandra.connection.host", CassandraNodes)
      .set("es.nodes", EsNodes)
      .set("es.port", EsPort)
      .set("es.index.auto.create", "true")
  }

   "Le pipeline ActionInternePipeline" should "trangit pull" +
     "sforme les donnes de log en ActionInterne correctement" in {
     Given("Une implementation du ActionInternePipelineMock fournissant des lignes de log")

     val statementWriteRefUtilisateur = CassandraClient.getSession.prepare(s"INSERT INTO $CassandraReferentielKeySpace.ref_utilisateur (login_user, statut_utilisateur, login_web_pcc, id_user_crm, code_operateur_cis, code_operateur_sgss, date_creation, date_desactivation, fonction_utilisateur, libelle_customer_range, nom_service_utilisateur, nom_utilisateur, prenom_utilisateur) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)")

     val pipeline = ActionInternePipelineMockKafka

     val logLines = pipeline.getJsonSamplesSet

     CassandraClient.getSession.execute(statementWriteRefUtilisateur.bind("AAITYAHI", 0 : java.lang.Integer, "0", 470978759L : java.lang.Long, 2103 : java.lang.Integer, null, Conversion.getDateTime(2007, 6, 28, 23, 0, 0).toDate, Conversion.getDateTime(2007, 6, 28, 23, 0, 0).toDate, null, "NON RENSEIGNE", "AGENCE BOULOGNE 2", "AIT YAHIA", "ADELIE"))
     CassandraClient.getSession.execute(statementWriteRefUtilisateur.bind("ABOYEZ", 0: java.lang.Integer, "0", 470978759L : java.lang.Long, 2103 : java.lang.Integer, null, Conversion.getDateTime(2007, 6, 28, 23, 0, 0).toDate, Conversion.getDateTime(2007, 6, 28, 23, 0, 0).toDate, null, "NON RENSEIGNE", "AGENCE BOULOGNE 2", "AIT YAHIA", "ADELIE"))

     When("On lance spark streaming par la methode process et tempo de 5sec")

     val sparkConf = getSparkConf()
     val ssc = new StreamingContext(sparkConf, Seconds(2))
     //ssc.checkpoint("/tmp/spark-checkpoint")

     pipeline.process(ssc, 15000)
     //ssc.scheduler.clock.asInstanceOf[ManualClock]

     Then("2 mails pour 2 actions suspectes sont envoyés")
     pipeline.getMails should have size 2

     ssc.stop()
   }
 }

