package com.boursorama.spark.streaming.parser

import java.text.SimpleDateFormat
import com.boursorama.dtl.business.ActionInterne
import com.boursorama.test.SimpleSpec
import com.boursorama.utils.Conversion._
import org.joda.time.DateTime
import org.scalatest.GivenWhenThen

class ActionInterneCisParserSpec extends SimpleSpec with GivenWhenThen {

  "The parseLine method" should "parse a cis e log line in JSON format from logstash's ouput and persist it in a cassandra table" in {
    Given("A CIS E log line in JSON")
    val logLineCISE = "{\n\t\"@version\": \"1\",\n\t\"@timestamp\": \"2016-03-04T13:59:04Z\",\n\t\"host\": \"tupocbi005\",\n\t\"login_user\": \"YMOREAU\",\n\t\"path\": \"/logcisprod/LOGCISE-C-20160303-210800.CSV\",\n\t\"type\": \"CIS_LOGCISE\",\n\t\"M SERVICE\": \"WE256S01K\",\n\t\"ID TRANSAC\": \"W25602336850176\",\n\t\"COD ASI\": \"000000000000000\",\n\t\"COD SOP\": \"0000\",\n\t\"ID IP\": \"10.21.0.28\",\n\t\"ID SEANCE\": \"57847\",\n\t\"COD UTI\": \"57573271\",\n\t\"TYP UTIL\": \"2\",\n\t\"NUM ORDRE\": \"nil\",\n\t\"COD AGENT\": \"nil\",\n\t\"NOM AGENT\": \"nil\",\n\t\"NUM TEL\": \"nil\",\n\t\"NIV ACCES\": \"2\",\n\t\"COD UTI BRS\": \"61347\",\n\t\"TYP ACCES\": \"I\",\n\t\"ID INTERNE\": \"00859436\",\n\t\"COD CANAL\": \"E\",\n\t\"COD OPER\": \"CSYCABAN\",\n\t\"ANN DEBUT\": \"2016\",\n\t\"MOI DEBUT\": \"03\",\n\t\"JOU DEBUT\": \"03\",\n\t\"HEU DEBUT\": \"210701\",\n\t\"HEU MSC DEB\": \"915\",\n\t\"ANN FIN\": \"2016\",\n\t\"MOI FIN\": \"03\",\n\t\"JOU FIN\": \"03\",\n\t\"HEU FIN\": \"210701\",\n\t\"HEU MSC FIN\": \"923\",\n\t\"COD FIN\": \"1\",\n\t\"COD MSGEXT\": \"nil\",\n\t\"LIB EXT\": \"nil\",\n\t\"COD MSGINT\": \"nil\",\n\t\"LIB INT\": \"nil\",\n\t\"COD BQE OP\": \"40618\",\n\t\"COD AGE OP\": \"20000\",\n\t\"NUM CON OP\": \"00040062240\",\n\t\"DEV CON OP\": \"978\",\n\t\"MTT OP\": \"00000000000.00\",\n\t\"DEV MTT\": \"nil\",\n\t\"MTT CVAL\": \"00000000000.00\",\n\t\"DV MTT CVAL\": \"nil\",\n\t\"QUAN OP\": \"000\",\n\t\"INFO OPER\": \"nil\",\n\t\"INFO OPER2\": \"nil\",\n\t\"COD ASI OP\": \"000000000000000\",\n\t\"COD SOP OP\": \"0000\",\n\t\"ANN MAJ\": \"2016\",\n\t\"JOU MAJ\": \"03\",\n\t\"MOI MAJ\": \"03\",\n\t\"HEU MAJ\": \"210701\",\n\t\"ID OPER\": \"0000000000\",\n\t\"NOM ABR\": \"DOUARDANNABELLE\",\n\t\"LIB TRANS\": \"Consulter carte bancaire\"\n}"

    When("On apelle la méthode parseLine")
    val result = ActionInterneCisParser.parseLine(logLineCISE)

    Then("Une LogCis case class est retourné")
      result should be ( Some (ActionInterne("CISE", 201603, 20160303, getDateTime("2016-03-03T21:07:01.000+0100"), "61347", "CSYCABAN", "Consulter carte bancaire", "-", "-", "10.21.0.28", Some(57573271L), None, "-", "-", "-", "-", logLineCISE)))
  }

  "The parseLine method" should "parses a cis S5250 log line in JSON format from logstash's ouput and persist it in a cassandra table" in {
    Given("A CIS S5250  log line in JSON")
    val logLineCIS5250 = "{\n\t\"@version\": \"1\",\n\t\"@timestamp\": \"2016-03-07T15:46:33Z\",\n\t\"type\": \"CIS_5250\",\n\t\"host\": \"tupocbi005\",\n\t\"login_user\": \"YMOREAU\",\n\t\"Code banque\": \"40618\",\n\t\"Code agence\": \"00043\",\n\t\"Code gestionnaire\": \"2473\",\n\t\"Jour operation\": \"07\",\n\t\"Mois operation\": \"03\",\n\t\"Annee operation\": \"2016\",\n\t\"Heure operation\": \"085633\",\n\t\"Tache utilisee\": \"31010\",\n\t\"Option choisie\": \"8\",\n\t\"Programme appel\": \"B0122V\",\n\t\"Poste operationnel\": \"02164\",\n\t\"Nom user\": \"YMOREAU\",\n\t\"Nom job\": \"NYBSR21408\",\n\t\"Numero de job\": \"541500\",\n\t\"DSLIBR du programme\": \"057200009178019000081    978  406188026200040017181    978                             0572000091780190000                                      0000000000000000     000000000000000000000000000000000000000000000000000000000000000000       00000000000000\",\n\t\"Nom pers\": \"LENCLOS\",\n\t\"Prenom\": \"MARC-ANTOINE\",\n\t\"Libelle Tache\": \"MVTS. ACTIFS/DATE OPERATION\",\n\t\"Libelle option\": null,\n\t\"Libelle pgm\": \"Visualisation dun CRO - Situation globale.\"\n}"

    When("On apelle la méthode parseLine")
    val result = ActionInterneCisParser.parseLine(logLineCIS5250)

    Then("Une LogCis case class est retourné")
      result should be (Some(ActionInterne("CIS5250", 201603, 20160307, getDateTime("2016-03-07T08:56:33.000+0100"), "YMOREAU", "31010", "MVTS. ACTIFS/DATE OPERATION", "8", "-", "-", Some(-1L), None, "-", "-", "-", "-", logLineCIS5250)))
  }
}