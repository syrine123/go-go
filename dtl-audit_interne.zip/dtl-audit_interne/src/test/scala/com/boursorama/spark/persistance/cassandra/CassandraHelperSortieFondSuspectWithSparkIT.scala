package com.boursorama.spark.persistance.cassandra

import com.boursorama.cassandra.CassandraClientSpec
import com.boursorama.dtl.business.Client
import com.boursorama.test.{SimpleSpec, SparkStreamingTestHelper}
import com.boursorama.utils.AppConf._
import com.boursorama.utils.Constants._
import com.boursorama.utils.Conversion._
import com.datastax.driver.core.ConsistencyLevel
import org.apache.spark.SparkConf
import org.apache.spark.streaming.{Seconds, StreamingContext}
import org.scalatest.GivenWhenThen

import scala.collection.mutable


class CassandraHelperSortieFondSuspectWithSparkIT extends CassandraClientSpec with GivenWhenThen {

  def getSparkConf() : SparkConf = {
    println("CassandraHostName : " + CassandraNodes)
    new SparkConf()
      .setMaster("local[2]")
      .setAppName("test-pipeline")
      .set("spark.executor.memory", "1g")
      .set("spark.cassandra.connection.host", CassandraNodes)
      .set("spark.cassandra.output.consistency.level", ConsistencyLevel.LOCAL_ONE.name())
      .set("spark.cassandra.input.consistency.level", ConsistencyLevel.LOCAL_ONE.name())
  }


   "La classe CassandraHelper" should "persister les données dans Cassandra via Spark" in {

     Given("Une collection de champs")

     val listeAction = List(
       SortieFondSuspect(
         "CIS",
         201404,
         20140430,
         getDateTime(2014, 4, 30, 19, 37, 30),
         "W01K02570878784",
         65545919,
         "80.12.59.179",
         10000.0,
         "-",
         "-",
         "OTRANSFR",
         "40618",
         "20000",
         "00040327669",
         "978",
         "406182000000040327669978",
         "40618-80263-00040695894-978",
         "FR",
         Some(Client(65545919, 65545919, "NOM-CLIENT", "Prenom-Client", getDateTime(2013, 1, 4, 10, 25, 15), -10000.0, 5000.0, 1)),
         1000,
         TYPE_FRAUDE_EXT_PAYS_SUSPECT,
         Map(("lastRefresh" -> "0"), ("KM", "KM"), ("CG", "CG"), ("CO", "CO"), ("CN", "CN"))
       ),
       SortieFondSuspect(
         "CIS",
         201604,
         20160430,
         getDateTime(2016, 4, 30, 19, 37, 30),
         "W01K02570878784",
         65545919,
         "80.12.59.179",
         10000.0,
         "-",
         "-",
         "OTRANSFR",
         "40618",
         "20000",
         "00040327669",
         "978",
         "406182000000040327669978",
         "40618-80263-00040695894-978",
         "FR",
         None,
         0.0,
         TYPE_FRAUDE_EXT_CAVALERIE,
         Map(
           "seuilSoldeCumulMoinsEgalQue" -> "-5000",
           "lastRefresh" -> "0",
           "seuilCumulRmcPlusEgalQue" -> "1000",
           "seuilMontantPlusEgalQue" -> "1000",
           "seuilAncienneteMoinsEgalQue" -> "730"
         )
       )
     )

     //CassandraTestTablespace.deleteCassandra
     //CassandraTestTablespace.initCassandra

     When("On appelle CassandraHelper")


     val sparkConf = getSparkConf()
     val ssc = new StreamingContext(sparkConf, Seconds(1))
     //ssc.checkpoint("/tmp/spark-checkpoint")

     val SparkStreamingTestHelper = new SparkStreamingTestHelper[SortieFondSuspect]
     val actionDStream = SparkStreamingTestHelper.initInputStream(ssc)

     var count = 0
     actionDStream.foreachRDD( rdd => { count += rdd.collect().length} )
     CassandraHelper.persisteSortieFondSuspect(actionDStream)

     ssc.start()

     SparkStreamingTestHelper.pushToStream(ssc, listeAction)

     ssc.awaitTerminationOrTimeout(10000)

     Then("Les (2) actions sont indexées")
     count should be (2)

     ssc.stop()
     }
 }

