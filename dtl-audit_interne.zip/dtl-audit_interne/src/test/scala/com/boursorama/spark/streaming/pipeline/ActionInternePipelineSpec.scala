package com.boursorama.spark.streaming.pipeline

import com.boursorama.dtl.business.{ActionInterneSuspect, Client, ActionInterne}
import com.boursorama.test.SimpleSpec
import com.boursorama.utils.Constants._
import com.boursorama.utils.Conversion._
import org.scalatest.GivenWhenThen

class ActionInternePipelineSpec extends SimpleSpec with GivenWhenThen {

  val client1 = Client(35021359, 35021359, "NOM-CLIENT", "Prenom-Client", Some(getDateTime(2016, 1, 4, 10, 25, 15)), 1500.50, 5000.0, 2)
  val client2 = Client(32354028, 32354028, "NOM-CLIENT", "Prenom-Client", Some(getDateTime(2016, 1, 4, 10, 25, 15)), 800.5, 500.0, 5)

   "Le pipeline ActionInternePipeline" should "transforme les donnes de log en ActionInterne correctement" in {
     Given("Une implementation du ActionInternePipelineMock fournissant des lignes de log")

     val pipelineMock = ActionInternePipelineMockAll

     When("On applique les méthodes parseLog et enricheActionInterne")

     val logLines = pipelineMock.getJsonSamplesSet
     val result1 = logLines.flatMap(logLine => pipelineMock.parseToAction(logLine))
     val result2 = result1.flatMap(actionInterne => pipelineMock.enrichWithUserInfo(actionInterne))
     val result3 = result2.flatMap(actionInterne => pipelineMock.enrichWithClientInfo(Some(actionInterne)))

     Then("Une liste de ActionInterne est retournée")
      result2 should contain (
           ActionInterne(
             "TEST",
             201605,
             20160503,
             getDateTimeIgnoreMsAndTZ("2016-05-03T23:34:53.628"),
             "AAITYAHI",
             "OP1",
             "Operation 1",
             "OP1-SOP1",
             "Sous Operation 1.1",
             "1.1.1.1",
             Some(35021359L),
             None,
             "10001.00000001.99",
             "AAITYAHINom",
             "AAITYAHIPrenom",
             "32354028789-1",
             logLines.head
         )
       )

     Then("Une liste de ActionInterne est retournée")
     result3 should contain (
       ActionInterne(
         "TEST",
         201605,
         20160503,
         getDateTimeIgnoreMsAndTZ("2016-05-03T23:34:53.628"),
         "AAITYAHI",
         "OP1",
         "Operation 1",
         "OP1-SOP1",
         "Sous Operation 1.1",
         "1.1.1.1",
         Some(35021359L),
         Some(client1),
         "10001.00000001.99",
         "AAITYAHINom",
         "AAITYAHIPrenom",
         "32354028789-1",
         logLines.head
       )
     )

     When("On applique la detection des actions suspectes")

     val suspectes = result3.flatMap(action => pipelineMock.detectSuspect(action))

     Then("Une ActionInterneSuspect heure suspecte est retournée")
     suspectes should have size (4)

     Then("Une ActionInterneSuspect est retournée")
     suspectes should contain allOf (
       ActionInterneSuspect(
         "TEST",
         201605,
         20160503,
         getDateTimeIgnoreMsAndTZ("2016-05-03T23:34:53.628"),
         "AAITYAHI",
         "OP1",
         "Operation 1",
         "OP1-SOP1",
         "Sous Operation 1.1",
         "1.1.1.1",
         35021359,
         Some(client1),
         "10001.00000001.99",
         "AAITYAHINom",
         "AAITYAHIPrenom",
         "32354028789-1",
         TYPE_FRAUDE_INT_ENCOURS_SUPERIEUR,
         Map(("seuilEncoursPlusEgalQue", "1000")),
         logLines.head
       ),
       ActionInterneSuspect(
         "TEST",
         201604,
         20160430,
         getDateTimeIgnoreMsAndTZ("2016-04-30T23:34:53.628"),
         "ABOYEZ",
         "OP2",
         "Operation 2",
         "OP2-SOP2",
         "Sous Operation 2.2",
         "2.2.2.2",
         32354028l,
         Some(client2),
         "10001.00000002.99",
         "ABOYEZNom",
         "ABOYEZPrenom",
         "32354028789-2",
         TYPE_FRAUDE_INT_HEURE_SUSPECTE,
         Map(("seuilHeureSuspectePlusQue", "22"), ("seuilHeureSuspecteMoinsQue", "5")),
         logLines.tail.head
       ),
       ActionInterneSuspect(
         "TEST",
         201604,
         20160430,
         getDateTimeIgnoreMsAndTZ("2016-04-30T23:34:53.628"),
         "ABOYEZ",
         "OP2",
         "Operation 2",
         "OP2-SOP2",
         "Sous Operation 2.2",
         "2.2.2.2",
         32354028l,
         Some(client2),
         "10001.00000002.99",
         "ABOYEZNom",
         "ABOYEZPrenom",
         "32354028789-2",
         TYPE_FRAUDE_INT_CLIENT_VIP,
         Map(("listeClientsVip", "32354028")),
         logLines.tail.head
       ),
       ActionInterneSuspect(
         "TEST",
         201605,
         20160503,
         getDateTimeIgnoreMsAndTZ("2016-05-03T23:34:53.628"),
         "AAITYAHI",
         "OP1",
         "Operation 1",
         "OP1-SOP1",
         "Sous Operation 1.1",
         "1.1.1.1",
         35021359,
         Some(client1),
         "10001.00000001.99",
         "AAITYAHINom",
         "AAITYAHIPrenom",
         "32354028789-1",
         TYPE_FRAUDE_INT_HEURE_SUSPECTE,
         Map(("seuilHeureSuspectePlusQue", "22"), ("seuilHeureSuspecteMoinsQue", "5")),
         logLines.head
       )
     )
  }
 }

