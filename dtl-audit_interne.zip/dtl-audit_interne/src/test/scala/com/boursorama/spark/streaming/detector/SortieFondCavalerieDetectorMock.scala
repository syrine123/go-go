package com.boursorama.spark.streaming.detector

object SortieFondCavalerieDetectorMock extends SortieFondCavalerieDetector {

  override def getFraudeParams() : Map[String, String] = {
    cachedParamsMap
  }
 }
