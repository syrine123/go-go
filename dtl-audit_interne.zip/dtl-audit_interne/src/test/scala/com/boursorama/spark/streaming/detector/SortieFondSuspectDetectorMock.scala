package com.boursorama.spark.streaming.detector

object SortieFondSuspectDetectorMock extends SortieFondSuspectDetector {

  override val suspect1: (SortieFond) => Option[SortieFondSuspect] = SortieFondCavalerieDetectorMock.suspect
  override val suspect2: (SortieFond) => Option[SortieFondSuspect] = SortieFondPaysSuspectDetectorMock.suspect
}
