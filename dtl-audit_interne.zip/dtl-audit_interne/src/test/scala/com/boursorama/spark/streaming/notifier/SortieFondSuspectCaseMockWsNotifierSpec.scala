package com.boursorama.spark.streaming.notifier

import com.boursorama.api.crm.CrmWsApi
import com.boursorama.dtl.business.Client
import com.boursorama.test.SimpleSpec
import com.boursorama.utils.Constants._
import com.boursorama.utils.Conversion._

class SortieFondSuspectCaseMockWsNotifierSpec extends SimpleSpec {

  val sortieFondSuspect1: SortieFondSuspect = SortieFondSuspect(
                                "CIS",
                                201604,
                                20160430,
                                getDateTime(2016,4,30,19,37,30),
                                "W01K02570878784",
                                68656476,
                                "80.12.59.179",
                                30.0,
                                "-",
                                "-",
                                "OTRANSFR",
                                "40618",
                                "20000",
                                "00040327669",
                                "555",
                                "406182000000040327669978",
                                "40618-80263-00040695894-978",
                                "FR",
                                Some(Client(68656476, 68656476, "NOM-CLIENT", "Prenom-Client", getDateTime(2013, 1, 4, 10, 25, 15), -10000.0, 5000.0, 1)),
                                1000.0,
                                TYPE_FRAUDE_EXT_CAVALERIE,
                                null)

  val sortieFondSuspect2: SortieFondSuspect = SortieFondSuspect(
                                "CIS",
                                201604,
                                20160430,
                                getDateTime(2016,4,30,19,37,30),
                                "W01K02570878784",
                                68656476,
                                "80.12.59.179",
                                30.0,
                                "-",
                                "-",
                                "OTRANSFR",
                                "40618",
                                "20000",
                                "00040327669",
                                "555",
                                "406182000000040327669978",
                                "40618-80263-00040695894-978",
                                "FR",
                                Some(Client(68656476, 68656476, "NOM-CLIENT", "Prenom-Client", getDateTime(2013, 1, 4, 10, 25, 15), -10000.0, 5000.0, 1)),
                                1000.0,
                                TYPE_FRAUDE_EXT_PAYS_SUSPECT,
                                null)

  "La méthode ActionInterneSuspectNotifier.process" should "envoyer un mail" in {

    Given("Une requete http")

    val suspectNotifier = SortieFondSuspectCaseWsNotifierMock

    When("On apelle la méthode process")
    suspectNotifier.notifySuspect(sortieFondSuspect1)
    suspectNotifier.notifySuspect(sortieFondSuspect2)

    Then("Doit retourner 1es donnes d'appel WS CRM de creation du case")
    suspectNotifier.getWebServiceCalls should have size 2

    Then("L'appel doit être conforme au modèle")
    suspectNotifier.getWebServiceCalls should contain ( sortieFondSuspect1  )

    Then("L'appel doit être conforme au modèle")
    suspectNotifier.getWebServiceCalls should contain ( sortieFondSuspect2 )

  }  
}

