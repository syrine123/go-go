package com.boursorama.spark.streaming.pipeline

import com.boursorama.dtl.business.{ActionInterne, ActionInterneSuspect, UserInformation}
import com.boursorama.spark.streaming.detector.ActionInterneSuspectDetectorMock
import com.boursorama.spark.streaming.notifier._
import com.boursorama.utils.Constants._
import com.boursorama.utils.Conversion._
import org.apache.spark.rdd.RDD
import org.apache.spark.storage.StorageLevel
import org.apache.spark.streaming.StreamingContext
import org.apache.spark.streaming.dstream.DStream
import org.json4s.DefaultFormats
import org.json4s.jackson.JsonMethods._

import scala.collection.mutable
import scala.collection.mutable.ListBuffer

class ActionInternePipelineMockKafka extends ActionInternePipeline with Serializable {

  override def getStorageLevel: StorageLevel = StorageLevel.MEMORY_ONLY

  override def getTopicSet : Set[String] = Set()

  override def getAppName(): String = "sp-strm-action-interne-mockkafka"

  // Needed for sbt test, because it's an object and so, keep previous unit test's result in memory
  def clearContainers() = {
    ActionInterneSuspectMailNotifierMock.clearMails()
  }

  def getJsonSamplesSet: Seq[String] = {
    clearContainers()

    Seq(
      "{\"timestamp\":\"2016-05-03T23:34:53.628Z\", \"login\":\"AAITYAHI\", \"codeOp\":\"OP1\", \"libOp\":\"Operation 1\", \"codeSousOp\":\"OP1-SOP1\", \"libSousOp\":\"Sous Operation 1.1\", \"remoteIp\":\"1.1.1.1\", \"clientId\":\"35021359\", \"compteId\":\"10001.00000001.99\", \"sessionId\":\"32354028789-1\"}",
      "{\"timestamp\":\"2016-04-30T23:34:53.628Z\", \"login\":\"ABOYEZ\", \"codeOp\":\"OP2\", \"libOp\":\"Operation 2\", \"codeSousOp\":\"OP2-SOP2\", \"libSousOp\":\"Sous Operation 2.2\", \"remoteIp\":\"2.2.2.2\", \"clientId\":\"32354028\", \"compteId\":\"10001.00000002.99\", \"sessionId\":\"32354028789-2\"}"
    )
  }

  protected var lines: mutable.Queue[RDD[String]] = _

  override def getInputStream(ssc: StreamingContext): DStream[String] = {
    println(">> getActionInputStream")
    lines = mutable.Queue()
    val dStream = ssc.queueStream(lines)
    println("<< getActionInputStream")
    dStream
  }

  override def afterStart(ssc: StreamingContext) : Unit = {
    println(">> afterStart")
    val sc = ssc.sparkContext
    lines += sc.makeRDD( getJsonSamplesSet )
    println("<< afterStart")
  }

  override def parseToAction = mockParseToAction

  def mockParseToAction(logLine: String): Option[ActionInterne] = {

    println(">>>>> parseLine")
    val sysOrigine = "TEST"
    implicit val formats = DefaultFormats
    val json = parse(logLine)
    val rawTimestamp = (json \ "timestamp").extractOpt[String].getOrElse(EmptyStringField)
    val timestamp = getDateTimeIgnoreMsAndTZ(rawTimestamp)
    val anneeMois = getYearMonth(timestamp)
    val idDimTemps = getYearMonthDay(timestamp)
    val userLogin = (json \ "login").extractOpt[String].getOrElse(EmptyStringField).toUpperCase
    val codeOperation = (json \ "codeOp").extractOpt[String].getOrElse(EmptyStringField)
    val libelleOperation = (json \ "libOp").extractOpt[String].getOrElse(EmptyStringField)
    val codeSousOperation = (json \ "codeSousOp").extractOpt[String].getOrElse(EmptyStringField)
    val libelleSousOperation = (json \ "libSousOp").extractOpt[String].getOrElse(EmptyStringField)
    val adresseIp = (json \ "remoteIp").extractOpt[String].getOrElse(EmptyStringField)
    val clientId = (json \ "clientId").extractOpt[String].getOrElse("-1").toInt
    val compteId = (json \ "compteId").extractOpt[String].getOrElse(EmptyStringField)
    val nomUtilisateur = (json \ "nomUser").extractOpt[String].getOrElse(EmptyStringField)
    val prenomUtilisateur = (json \ "prenomUser").extractOpt[String].getOrElse(EmptyStringField)
    val sessionId = (json \ "sessionId").extractOpt[String].getOrElse(EmptyStringField)

    Some(ActionInterne(
      sysOrigine,
      anneeMois.toInt,
      idDimTemps.toInt,
      timestamp,
      userLogin,
      codeOperation,
      libelleOperation,
      codeSousOperation,
      libelleSousOperation,
      adresseIp,
      Some(clientId.toLong),
      None,
      compteId,
      nomUtilisateur,
      prenomUtilisateur,
      sessionId,
      logLine
    ))
  }

  override val suspectNotifier: SuspectNotifier[ActionInterneSuspect] = ActionInterneSuspectMailNotifierMock
  def getMails : List[String] = ActionInterneSuspectMailNotifierMock.getMails

}

object ActionInternePipelineMockKafka extends ActionInternePipelineMockKafka