package com.boursorama.spark.streaming.detector

import com.boursorama.dtl.business.{ActionInterneSuspect, ActionInterne}

object ActionInterneSuspectDetectorMock extends ActionInterneSuspectDetector {

  override val suspect1: (ActionInterne) => Option[ActionInterneSuspect] = ActionInterneHeureSuspecteDetectorMock.suspect
  override val suspect2: (ActionInterne) => Option[ActionInterneSuspect] = ActionInterneEncoursSupDetectorMock.suspect
  override val suspect3: (ActionInterne) => Option[ActionInterneSuspect] = ActionInterneClientVipDetectorMock.suspect
}
