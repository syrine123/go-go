package com.boursorama.spark.streaming.detector

object ActionInterneEncoursSupDetectorMock extends ActionInterneEncoursSupDetector {

   var mockParamsMap = Map[String, String]("seuilEncoursPlusEgalQue" -> "1000")

   override def getFraudeParams() : Map[String, String] = {
     mockParamsMap
   }
 }
