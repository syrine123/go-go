package com.boursorama.spark.streaming.pipeline

import com.boursorama.cassandra.{CassandraClient, CassandraClientSpec}
import com.boursorama.dtl.business.{ActionInterne, ActionInterneSuspect, Client}
import com.boursorama.test.SimpleSpec
import com.boursorama.utils.AppConf._
import com.boursorama.utils.Constants._
import com.boursorama.utils.Conversion
import com.boursorama.utils.Conversion._
import org.apache.spark.SparkConf
import org.apache.spark.streaming.{Seconds, StreamingContext}
import org.scalatest.GivenWhenThen

class ActionInternePipelineWithSparkSpec extends CassandraClientSpec with GivenWhenThen {

  val client1 = Client(35021359, 35021359, "NOM-CLIENT", "Prenom-Client", Some(getDateTime(2016, 1, 4, 10, 25, 15)), 1500.50, 5000.0, 2)
  val client2 = Client(32354028, 32354028, "NOM-CLIENT", "Prenom-Client", Some(getDateTime(2016, 1, 4, 10, 25, 15)), 800.5, 500.0, 5)

  def getSparkConf() : SparkConf = {
    new SparkConf()
      .setMaster("local[2]")
      .setAppName("test-pipeline")

  }

   "Le pipeline ActionInternePipeline" should "trangit pull" +
     "sforme les donnes de log en ActionInterne correctement" in {
     Given("Une implementation du ActionInternePipelineMock fournissant des lignes de log")

     val pipeline = ActionInternePipelineMockAll

     val logLines = pipeline.getJsonSamplesSet

     val statementWriteRefUtilisateur = CassandraClient.getSession.prepare(s"INSERT INTO $CassandraReferentielKeySpace.ref_utilisateur (login_user, statut_utilisateur, login_web_pcc, id_user_crm, code_operateur_cis, code_operateur_sgss, date_creation, date_desactivation, fonction_utilisateur, libelle_customer_range, nom_service_utilisateur, nom_utilisateur, prenom_utilisateur) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)")

     CassandraClient.getSession.execute(statementWriteRefUtilisateur.bind("AAITYAHI", 0 : java.lang.Integer, "0", 470978759L : java.lang.Long, 2103 : java.lang.Integer, null, Conversion.getDateTime(2007, 6, 28, 23, 0, 0).toDate, Conversion.getDateTime(2007, 6, 28, 23, 0, 0).toDate, null, "NON RENSEIGNE", "AGENCE BOULOGNE 2", "AIT YAHIA", "ADELIE"))
     CassandraClient.getSession.execute(statementWriteRefUtilisateur.bind("ABOYEZ", 0: java.lang.Integer, "0", 470978759L : java.lang.Long, 2103 : java.lang.Integer, null, Conversion.getDateTime(2007, 6, 28, 23, 0, 0).toDate, Conversion.getDateTime(2007, 6, 28, 23, 0, 0).toDate, null, "NON RENSEIGNE", "AGENCE BOULOGNE 2", "AIT YAHIA", "ADELIE"))

     When("On lance spark streaming par la methode process et tempo de 5sec")

     val sparkConf = getSparkConf()
     val ssc = new StreamingContext(sparkConf, Seconds(1))
     //ssc.checkpoint("/tmp/spark-checkpoint")

     pipeline.process(ssc, 5000)
     //ssc.scheduler.clock.asInstanceOf[ManualClock]

     Then("Une liste de ActionInterne avec 2 actions est retournée")
       pipeline.getActionList should have size (2)

       pipeline.getActionList should contain (
         ActionInterne(
           "TEST",
           201605,
           20160503,
           getDateTimeIgnoreMsAndTZ("2016-05-03T23:34:53"),
           "AAITYAHI",
           "OP1",
           "Operation 1",
           "OP1-SOP1",
           "Sous Operation 1.1",
           "1.1.1.1",
           Some(35021359L),
           Some(client1),
           "10001.00000001.99",
           "AAITYAHINom",
           "AAITYAHIPrenom",
           "32354028789-1",
           logLines.head
         )
       )

       pipeline.getActionList should contain (
         ActionInterne(
           "TEST",
           201604,
           20160430,
           getDateTimeIgnoreMsAndTZ("2016-04-30T23:34:53"),
           "ABOYEZ",
           "OP2",
           "Operation 2",
           "OP2-SOP2",
           "Sous Operation 2.2",
           "2.2.2.2",
           Some(32354028L),
           Some(client2),
           "10001.00000002.99",
           "ABOYEZNom",
           "ABOYEZPrenom",
           "32354028789-2",
           logLines.tail.head
         )
       )

       pipeline.getSuspectList should have size (4)

       pipeline.getSuspectList should contain allOf (
           ActionInterneSuspect(
             "TEST",
             201605,
             20160503,
             getDateTimeIgnoreMsAndTZ("2016-05-03T23:34:53"),
             "AAITYAHI",
             "OP1",
             "Operation 1",
             "OP1-SOP1",
             "Sous Operation 1.1",
             "1.1.1.1",
             35021359,
             Some(client1),
             "10001.00000001.99",
             "AAITYAHINom",
             "AAITYAHIPrenom",
             "32354028789-1",
             TYPE_FRAUDE_INT_ENCOURS_SUPERIEUR,
             Map(("seuilEncoursPlusEgalQue", "1000")),
             logLines.head
           ),
         ActionInterneSuspect(
           "TEST",
           201605,
           20160503,
           getDateTimeIgnoreMsAndTZ("2016-05-03T23:34:53"),
           "AAITYAHI",
           "OP1",
           "Operation 1",
           "OP1-SOP1",
           "Sous Operation 1.1",
           "1.1.1.1",
           35021359,
           Some(client1),
           "10001.00000001.99",
           "AAITYAHINom",
           "AAITYAHIPrenom",
           "32354028789-1",
           TYPE_FRAUDE_INT_HEURE_SUSPECTE,
           Map(("seuilHeureSuspectePlusQue", "22"), ("seuilHeureSuspecteMoinsQue", "5")),
           logLines.head
         ),
           ActionInterneSuspect(
             "TEST",
             201604,
             20160430,
             getDateTimeIgnoreMsAndTZ("2016-04-30T23:34:53"),
             "ABOYEZ",
             "OP2",
             "Operation 2",
             "OP2-SOP2",
             "Sous Operation 2.2",
             "2.2.2.2",
             32354028l,
             Some(client2),
             "10001.00000002.99",
             "ABOYEZNom",
             "ABOYEZPrenom",
             "32354028789-2",
             TYPE_FRAUDE_INT_HEURE_SUSPECTE,
             Map(("seuilHeureSuspectePlusQue", "22"), ("seuilHeureSuspecteMoinsQue", "5")),
             logLines.tail.head
           ),
           ActionInterneSuspect(
             "TEST",
             201604,
             20160430,
             getDateTimeIgnoreMsAndTZ("2016-04-30T23:34:53"),
             "ABOYEZ",
             "OP2",
             "Operation 2",
             "OP2-SOP2",
             "Sous Operation 2.2",
             "2.2.2.2",
             32354028l,
             Some(client2),
             "10001.00000002.99",
             "ABOYEZNom",
             "ABOYEZPrenom",
             "32354028789-2",
             TYPE_FRAUDE_INT_CLIENT_VIP,
             Map(("listeClientsVip", "32354028")),
             logLines.tail.head
           )
        )

      ssc.stop()
     }
  //}
 }

