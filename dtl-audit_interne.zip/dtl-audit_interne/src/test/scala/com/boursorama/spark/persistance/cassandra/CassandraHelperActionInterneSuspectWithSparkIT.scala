package com.boursorama.spark.persistance.cassandra

import com.boursorama.cassandra.CassandraClientSpec
import com.boursorama.dtl.business.ActionInterneSuspect
import com.boursorama.test.{SimpleSpec, SparkStreamingTestHelper}
import com.boursorama.utils.AppConf._
import com.boursorama.utils.Conversion._
import com.datastax.driver.core.ConsistencyLevel
import org.apache.hadoop.hive.ql.exec.TaskRunner
import org.apache.spark.SparkConf
import org.apache.spark.streaming.{Seconds, StreamingContext}
import org.scalatest.GivenWhenThen


class CassandraHelperActionInterneSuspectWithSparkIT extends CassandraClientSpec with GivenWhenThen {

  def getSparkConf() : SparkConf = {
    new SparkConf()
      .setMaster("local[2]")
      .setAppName("test-pipeline")
      .set("spark.executor.memory", "1g")
      .set("spark.cassandra.connection.host", CassandraNodes)
      .set("spark.cassandra.output.consistency.level", ConsistencyLevel.LOCAL_ONE.name())
      .set("spark.cassandra.input.consistency.level", ConsistencyLevel.LOCAL_ONE.name())
  }

   "La classe EsHelper" should "indexe les donnes dans ES via Spark" in {

     Given("Une collection de champs")

     val listeSuspect = List(
       ActionInterneSuspect ("TEST1", 201303, 20130330, getDateTime(2013,3,30,20,0,0), "USER1", "OP1", "Operation 1", "OP1-SOP1", "Sous Operation 1.1", "1.1.1.1", 102, None, "10001.00000001.99", "USER1Nom", "USER1Prenom", "32354028789-1", "FRAUDE1", Map("param1" -> "1", "param2" -> "1"), "log-data-1"),
       ActionInterneSuspect ("TEST2", 201304, 20130410, getDateTime(2013,4,10,23,0,0), "USER2", "OP2", "Operation 2", "OP2-SOP2", "Sous Operation 2.2", "2.2.2.2", 102, None, "10001.00000002.99", "USER2Nom", "USER2Prenom", "32354028789-2", "FRAUDE1", Map("param1" -> "2", "param2" -> "2"), "log-data-2")
     )

     When("On lance spark streaming avec la methode persisteSuspect et tempo de 10sec")

     val sparkConf = getSparkConf()
     val ssc = new StreamingContext(sparkConf, Seconds(1))
     //ssc.checkpoint("/tmp/spark-checkpoint")

     val SparkStreamingTestHelper = new SparkStreamingTestHelper[ActionInterneSuspect]()

     val actionInterneSuspectDStream = SparkStreamingTestHelper.initInputStream(ssc)
     var count = 0
     actionInterneSuspectDStream.foreachRDD( rdd => { count += rdd.collect().length} )
     CassandraHelper.persisteSuspect(actionInterneSuspectDStream)

     ssc.start()

     SparkStreamingTestHelper.pushToStream(ssc, listeSuspect)

     ssc.awaitTerminationOrTimeout(10000)

     Then("Les (2) actionInternes sont persistées")
     count should be (2)

     ssc.stop()
   }
 }

