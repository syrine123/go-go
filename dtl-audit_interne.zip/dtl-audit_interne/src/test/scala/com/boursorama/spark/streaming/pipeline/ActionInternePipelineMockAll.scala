package com.boursorama.spark.streaming.pipeline

import java.util.Date

import com.boursorama.dtl.business.{Client, UserInformation, ActionInterneSuspect, ActionInterne}
import com.boursorama.spark.streaming.detector.ActionInterneSuspectDetectorMock
import com.boursorama.utils.Constants._
import com.boursorama.utils.Conversion._
import org.apache.spark.rdd.RDD
import org.apache.spark.storage.StorageLevel
import org.apache.spark.streaming.StreamingContext
import org.apache.spark.streaming.dstream.DStream
import org.json4s.DefaultFormats
import org.json4s.jackson.JsonMethods._

import scala.collection.mutable
import scala.collection.mutable.ListBuffer

object ActionInternePipelineMockAll extends ActionInternePipelineMockKafka {

  override def getAppName(): String = "sp-strm-action-interne-mockall"

  override def afterStart(ssc: StreamingContext) : Unit = {
    println(">> afterStart")
    val sc = ssc.sparkContext
    lines += sc.makeRDD( getJsonSamplesSet )
    println("<< afterStart")
  }

  override def detectSuspect(actionInterne: ActionInterne) : List[ActionInterneSuspect] = {
    println(s"-- detectActionInterneSuspect $actionInterne")
    val listSuspect = ActionInterneSuspectDetectorMock.suspect(actionInterne)
    listSuspect.foreach( suspect => println(s"  -- detected : $suspect") )
    listSuspect
  }

  val actionList =  new ListBuffer[ActionInterne]()

  def getActionList: List[ActionInterne] = {
    actionList.toList
  }

  override def persisteAction(actionInterneDStream: DStream[ActionInterne]): Unit = {
    actionInterneDStream.foreachRDD(rdd => storeActions(rdd))
  }

  def storeActions(rdd: RDD[ActionInterne]): Unit = {
    rdd.foreach(action => {
      actionList.synchronized {
        actionList += action
        println(">>>>> storeAction " + action.toString)
      }
    } )
  }

  val suspectList =  new ListBuffer[ActionInterneSuspect]()

  def getSuspectList: List[ActionInterneSuspect] = {
    suspectList.toList
  }

  override def persisteSuspect(actionInterneSuspecteDStream: DStream[ActionInterneSuspect]): Unit = {
    actionInterneSuspecteDStream.foreachRDD(rdd => storeSuspect(rdd))
  }

  def storeSuspect(rdd: RDD[ActionInterneSuspect]): Unit = {
    rdd.foreach(action => {
      suspectList.synchronized {
        suspectList += action
        println(">>>>> storeSuspect " + action.toString)
      }
    })
  }

  override def getUserInformation(originSystem: String, userLogin: String): Option[UserInformation] = {

    println(">>>>> getUserInformation")
    Some(
      UserInformation(
        userLogin,
        "",
        123l,
        123 : Int,
        "123" : String,
        getDateTime(2016, 6, 1, 16, 30, 10),
        null,
        "userFonction",
        "libelle",
        "DSI BI",
        userLogin + "Nom",
        userLogin + "Prenom",
        999
      )
    )
  }

   def getClientInformation(clientId: Long): Option[Client] = {

    println("-- getUserInformation (id_web=" + clientId + ")")
    if (35021359l.equals(clientId)) {
      Some(
        Client(
          35021359l,
          35021359l,
          "NOM-CLIENT",
          "Prenom-Client",
          Some(getDateTime(2016, 1, 4, 10, 25, 15)),
          1500.50,
          5000.0,
          2
        )
      )
    } else if (32354028l.equals(clientId)) {
      Some(
        Client(
          32354028l,
          32354028l,
          "NOM-CLIENT",
          "Prenom-Client",
          Some(getDateTime(2016, 1, 4, 10, 25, 15)),
          800.50,
          500.0,
          5
        )
      )
    } else {
      Some(
        Client(
          clientId,
          clientId,
          "NOM-CLIENT",
          "Prenom-Client",
          Some(getDateTime(2013, 1, 4, 10, 25, 15)),
          -10000.0,
          5000.0,
          1
        )
      )
    }
  }
}

