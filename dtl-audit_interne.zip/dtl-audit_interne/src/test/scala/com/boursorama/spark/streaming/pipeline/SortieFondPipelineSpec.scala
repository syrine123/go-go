package com.boursorama.spark.streaming.pipeline

import com.boursorama.dtl.business.Client
import com.boursorama.test.SimpleSpec
import com.boursorama.utils.Constants._
import com.boursorama.utils.Conversion._
import org.scalatest.GivenWhenThen

class SortieFondPipelineSpec extends SimpleSpec with GivenWhenThen {

   "Le pipeline ActionInternePipeline" should "transforme les donnes de log en ActionInterne correctement" in {
     Given("Une implementation du ActionInternePipelineMock fournissant des lignes de log")

     val pipelineMock = SortieFondPipelineMockAll
     val logCisExterneList = pipelineMock.getJsonSamplesSet
     val sortieFondList = logCisExterneList.flatMap(logLine => pipelineMock.parseToAction(logLine))
     val sortieFondEnrichiList = sortieFondList.flatMap(sortieFond => pipelineMock.enrichiSortieFond(sortieFond))
     val suspectList = sortieFondEnrichiList.flatMap(pipelineMock.detectSortieFondSuspect)

     When("On applique les méthodes parseLog et enricheActionInterne")

     Then("Une liste de 4 sortiee fond est retournée")
     sortieFondEnrichiList should have size (5)

     When("On applique la detection des actions suspectes")

     Then("Une liste de 3 sorties de fond suspectes est retournée")
     suspectList should have size (4)

     Then("Une sortie fond pays suspect est retournée")
     suspectList should contain (
       SortieFondSuspect (
         "CIS",
         201604,
         20160430,
         getDateTime(2016, 4, 30, 19, 37, 30, ParisTimeZone),
         "W01K02570878784",
         32354028,
         "80.12.59.179",
         2000.0,
         "-",
         "-",
         "OTRANSFR",
         "40618",
         "20000",
         "00040327669",
         "978",
         "406182000000040327669978",
         "40618-80263-00040695894-978",
         "CH",
         Some(Client(32354028,32354028,"NOM-CLIENT","Prenom-Client",getDateTime(2016,1,4,10,25,15), 1500.5, 500.0, 5)),
         -999.5,
         TYPE_FRAUDE_EXT_PAYS_SUSPECT,
         Map("listePaysARisque" -> "HR,MC,LT,RO,CH,LI,BG,EE,CZ,CY")
       )
     )

     Then("Une sortie fond cavalerie est retournée")
     suspectList should contain (
       SortieFondSuspect (
         "CIS",
         201604,
         20160430,
         getDateTime(2016, 4, 30, 19, 37, 30, ParisTimeZone),
         "W01K02570878787",
         68656476,
         "80.12.59.179",
         10000.0,
         "-",
         "-",
         "OTRANSFR",
         "40618",
         "20000",
         "00040327669",
         "978",
         "406182000000040327669978",
         "40618-80263-00040695894-978",
         "FR",
         Some(Client(68656476,68656476,"NOM-CLIENT","Prenom-Client",getDateTime(2016,1,4,10,25,15), 1500.5, 5000.0, 2)),
         -13499.5,
         TYPE_FRAUDE_EXT_CAVALERIE,
         Map(
           "seuilSoldeCumulMoinsEgalQue" -> "-5000",
           "seuilCumulRmcPlusEgalQue" -> "1000",
           "seuilMontantPlusEgalQue" -> "1000",
           "seuilAncienneteMoinsEgalQue" -> "730"
         )
       )
     )

     Then("Une sortie fond cavalerie est retournée")
     suspectList should contain (
       SortieFondSuspect (
         "CIS",
         201604,
         20160430,
         getDateTime(2016, 4, 30, 19, 37, 30, ParisTimeZone),
         "W01K02570878788",
         68656476,
         "80.12.59.179",
         12550.0,
         "-",
         "-",
         "OTRANSFR",
         "40618",
         "20000",
         "00040327669",
         "978",
         "406182000000040327669978",
         "40618-80263-00040695894-978",
         "CH",
         Some(Client(68656476,68656476,"NOM-CLIENT","Prenom-Client",getDateTime(2016,1,4,10,25,15), 1500.5, 5000.0, 2)),
         -16049.5,
         TYPE_FRAUDE_EXT_CAVALERIE,
         Map(
           "seuilSoldeCumulMoinsEgalQue" -> "-5000",
           "seuilCumulRmcPlusEgalQue" -> "1000",
           "seuilMontantPlusEgalQue" -> "1000",
           "seuilAncienneteMoinsEgalQue" -> "730"
         )
       )
     )

     Then("Une sortie fond cavalerie est retournée")
     suspectList should contain (
         SortieFondSuspect(
         "CIS",
         201604,
         20160430,
         getDateTime(2016, 4, 30, 19, 37, 30, ParisTimeZone),
         "W01K02570878788",
         68656476,
         "80.12.59.179",
         12550.0,
         "-",
         "-",
         "OTRANSFR",
         "40618",
         "20000",
         "00040327669",
         "978",
         "406182000000040327669978",
         "40618-80263-00040695894-978",
         "CH",
         Some(Client(68656476, 68656476, "NOM-CLIENT", "Prenom-Client", getDateTime(2016, 1, 4, 10, 25, 15), 1500.5, 5000.0, 2)),
         -16049.5,
         TYPE_FRAUDE_EXT_PAYS_SUSPECT,
           Map("listePaysARisque" -> "HR,MC,LT,RO,CH,LI,BG,EE,CZ,CY")
         )
        )
  }
 }

