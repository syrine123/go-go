package com.boursorama.spark.streaming.parser

import java.text.SimpleDateFormat
import com.boursorama.test.{SimpleSpec, SparkStreamingSpec}
import com.boursorama.utils.Conversion._
import org.scalatest.GivenWhenThen
import org.scalatest.concurrent.PatienceConfiguration.Timeout
import org.scalatest.time.{Millis, Span}

class ActionExterneCisParserSpec extends SimpleSpec with GivenWhenThen {

  "The parseLine method" should "parse a cis e log line in JSON format from logstash's ouput and persist it in a cassandra table" in {
    Given("A CIS  log line in JSON")

    val logLineCIS = "{  \"@version\": \"1\",    \"@timestamp\": \"2016-05-03T09:34:53.628Z\",    \"host\": \"tupocbi005\",    \"path\": \"/logcisprod/LOGCISW-C-20160430-193741.CSV\",    \"type\": \"cis-web\",    \"NOM SERVICE\": \"WE01KS01K\",    \"ID TRANSAC\": \"W01K02570878784\",    \"COD ASI\": \"000000000000000\",    \"COD SOP\": \"0000\",    \"ID IP\": \"80.12.59.179\",    \"ID SEANCE\": \"90795\",    \"COD UTI SFW\": \"68656476\",    \"TYP UTIL\": \"2\",    \"NUM ORDRE\": null,    \"COD AGENT\": null,    \"NOM AGENT\": null,    \"NUM TEL\": null,    \"NIV ACCES\": \"2\",    \"COD UTI BRS\": null,    \"TYP ACCES\": \"I\",    \"ID INTERNE\": \"00729913\",    \"COD CANAL\": \"W\",    \"COD OPER\": \"OTRANSFR\",    \"ANN DEBUT\": \"2016\",    \"MOI DEBUT\": \"04\",    \"JOU DEBUT\": \"30\",    \"HEU DEBUT\": \"193730\",    \"HEU MSC DEB\": \"313\",    \"ANN FIN\": \"2016\",    \"MOI FIN\": \"04\",    \"JOU FIN\": \"30\",    \"HEU FIN\": \"193731\",    \"HEU MSC FIN\": \"218\",    \"COD FIN\": \"1\",    \"COD MSGEXT\": null,    \"LIB EXT\": null,    \"COD MSGINT\": null,    \"LIB INT\": null,    \"COD BQE OP\": \"40618\",    \"COD AGE OP\": \"20000\",    \"NUM CON OP\": \"00040327669\",    \"DEV CON OP\": \"978\",    \"MTT OP\": \"00000000030.00\",    \"DEV MTT\": \"978\",    \"MTT CVAL\": \"00000000000.00\",    \"DV MTT CVAL\": null,    \"QUAN OP\": \"000\",    \"INFO OPER\": \"02-05-2016 / 20000-00016185073     / GTSEPAP\",    \"INFO OPER2\": \"40618-80263-00040695894-978\",    \"COD ASI OP\": \"060200002195876\",    \"COD SOP OP\": \"0000\",    \"ANN MAJ\": \"2016\",    \"JOU MAJ\": \"30\",    \"MOI MAJ\": \"04\",    \"HEU MAJ\": \"193731\",    \"ID OPER\": \"1462037849\",    \"NOM ABR\": \"DEVAUDBRUNO\",    \"LIB TRANS\": \"Creation TRANSFERT\", \"codePaysCible\": \"FR\"\n}"

    When("On apelle la méthode parseLine")

    val result = ActionExterneCisParser.parseLine(logLineCIS)

    Then("Une LogCis case class est retourné")
      result.get should be (
        SortieFond(
          "CIS",
          201604,
          20160430,
          getDateTime("2016-04-30T19:37:30.000+0200"),
          "W01K02570878784",
          68656476,
          "80.12.59.179",
          30.0,
          "-",
          "-",
          "OTRANSFR",
          "40618",
          "20000",
          "00040327669",
          "978",
          "406182000000040327669978",
          "40618-80263-00040695894-978",
          "FR",
           None,
           0.0,
          logLineCIS
        )
      )
  }
}