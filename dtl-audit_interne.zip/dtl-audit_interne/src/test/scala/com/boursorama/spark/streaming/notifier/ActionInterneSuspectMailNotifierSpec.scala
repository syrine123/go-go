package com.boursorama.spark.streaming.notifier

import com.boursorama.dtl.business.ActionInterneSuspect
import com.boursorama.spark.streaming.detector.{ActionInterneSuspectDetectorMock, ActionInterneSuspectDetector}
import com.boursorama.spark.streaming.parser.{ActionInterneAtosParser, ActionInterneCrmParser}
import com.boursorama.utils.Conversion._
import com.boursorama.utils.Constants._
import com.boursorama.test.SimpleSpec
import org.joda.time.DateTime

class ActionInterneSuspectMailNotifierSpec extends SimpleSpec {

  val internSuspect: ActionInterneSuspect = ActionInterneSuspect(
    "TEST",
    201604,
    20160430,
    getDateTimeIgnoreMsAndTZ("2016-04-30T23:00:00"),
    "USER2",
    "OP2",
    "Operation 2",
    "OP2-SOP2",
    "Sous Operation 2.2",
    "2.2.2.2",
    102,
    None,
    "10001.00000002.99",
    "USER2Nom",
    "USER2Prenom",
    "32354028789-2",
    TYPE_FRAUDE_INT_HEURE_SUSPECTE,
    Map(("seuilHeureSuspectePlusQue", "22"), ("seuilHeureSuspecteMoinsQue", "5")),
    "log line data"
  )

  "La méthode ActionInterneSuspectNotifier.process" should "envoyer un mail" in {
    
    Given("Une action interne suspecte")

    val suspectNotifier = ActionInterneSuspectMailNotifierMock

    When("On apelle la méthode process")
    suspectNotifier.notifySuspect(internSuspect)

    Then("Doit retourner 1 mail")
    suspectNotifier.getMails should have size (1)

    Then("Le mail doit être conforme au modèle")
    suspectNotifier.getMails should contain (
      "{\"smtpHost\": \"127.0.0.1:25\","
        + " \"sender\": \"admin.cognos@boursorama.fr\","
        + " \"to\": \"DTL-Risque@boursorama.fr\","
        + " \"subject\": \"Action Suspecte\","
        + " \"body\": \"Action suspecte détectée : \r\n"
        + "ActionInterneSuspect(TEST,201604,20160430,2016-04-30T23:00:00.000Z,USER2,OP2,Operation 2,OP2-SOP2,Sous Operation 2.2,2.2.2.2,102,None,10001.00000002.99,USER2Nom,USER2Prenom,32354028789-2," + TYPE_FRAUDE_INT_HEURE_SUSPECTE + ",Map(seuilHeureSuspectePlusQue -> 22, seuilHeureSuspecteMoinsQue -> 5),log line data)\"}"
    )

  }  
}

