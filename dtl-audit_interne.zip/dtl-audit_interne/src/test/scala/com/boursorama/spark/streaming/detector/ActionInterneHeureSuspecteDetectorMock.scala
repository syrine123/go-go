package com.boursorama.spark.streaming.detector

object ActionInterneHeureSuspecteDetectorMock extends ActionInterneHeureSuspecteDetector {

   override def getFraudeParams() : Map[String, String] = {
     cachedParamsMap
   }
 }
