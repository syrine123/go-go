package com.boursorama.spark.streaming.notifier

import com.boursorama.dtl.business.Client
import com.boursorama.test.{SimpleSpec, SparkStreamingTestHelper}
import com.boursorama.utils.AppConf._
import com.boursorama.utils.Constants._
import com.boursorama.utils.Conversion._
import org.apache.spark.SparkConf
import org.apache.spark.rdd.RDD
import org.apache.spark.streaming.dstream.DStream
import org.apache.spark.streaming.{Seconds, StreamingContext}
import org.scalatest.concurrent.PatienceConfiguration.Timeout
import org.scalatest.time.{Millis, Span}

import scala.collection.mutable

class SortieFondSuspectCaseWsNotifierSpecIT extends SimpleSpec {

  def getSparkConf() : SparkConf = {

    new SparkConf()
      .setMaster("local[2]")
      .setAppName("test-sortie-fond-suspect-case-ws-notifier-spec-it")
      .set("spark.streaming.concurrentJobs", "5")
  }

  val sortieFondSuspect1: SortieFondSuspect = SortieFondSuspect(
                                "CIS",
                                201604,
                                20160430,
                                getDateTime(2016,4,30,19,37,30),
                                "W01K02570878784",
                                68656476,
                                "80.12.59.179",
                                30.0,
                                "-",
                                "-",
                                "OTRANSFR",
                                "40618",
                                "20000",
                                "00040327669",
                                "555",
                                "406182000000040327669978",
                                "40618-80263-00040695894-978",
                                "FR",
                                Some(Client(68656476, 68656476, "NOM-CLIENT", "Prenom-Client", getDateTime(2013, 1, 4, 10, 25, 15), -10000.0, 5000.0, 1)),
                                1000.0,
                                TYPE_FRAUDE_EXT_CAVALERIE,
                                null)

  val sortieFondSuspect2: SortieFondSuspect = SortieFondSuspect(
                                "CIS",
                                201604,
                                20160430,
                                getDateTime(2016,4,30,19,37,30),
                                "W01K02570878784",
                                68656476,
                                "80.12.59.179",
                                30.0,
                                "-",
                                "-",
                                "OTRANSFR",
                                "40618",
                                "20000",
                                "00040327669",
                                "555",
                                "406182000000040327669978",
                                "40618-80263-00040695894-978",
                                "FR",
                                Some(Client(68656476, 68656476, "NOM-CLIENT", "Prenom-Client", getDateTime(2013, 1, 4, 10, 25, 15), -10000.0, 5000.0, 1)),
                                1000.0,
                                TYPE_FRAUDE_EXT_PAYS_SUSPECT,
                                null)

  "La méthode ActionInterneSuspectNotifier.process" should "envoyer un mail" in {

    Given("Une requete http")

    val suspectNotifier = SortieFondSuspectCaseWsInspectedNotifier

    val sparkConf = getSparkConf()
    val ssc = new StreamingContext(sparkConf, Seconds(2))
    val sscHelper = new SparkStreamingTestHelper[SortieFondSuspect]
    val dStream = sscHelper.initInputStream(ssc)

    When("On apelle la méthode process")
    suspectNotifier.notify(dStream)

    ssc.start()

    sscHelper.pushToStream(ssc, List(sortieFondSuspect1, sortieFondSuspect2))

    Then("Doit retourner 1es donnes d'appel WS CRM de creation du case")
    eventually(Timeout(Span(5000, Millis))) {
      suspectNotifier.getWebServiceCalls should have size 1
    }

    Then("L'appel doit être conforme au modèle")
    eventually(Timeout(Span(5000, Millis))) {
      suspectNotifier.getWebServiceCalls should contain ( sortieFondSuspect1  )
    }

    Then("L'appel doit être conforme au modèle")
    eventually(Timeout(Span(5000, Millis))) {
      suspectNotifier.getWebServiceCalls shouldNot contain ( sortieFondSuspect2 )
    }

    ssc.stop()
  }  
}

