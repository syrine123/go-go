package com.boursorama.spark.streaming.pipeline

import com.boursorama.dtl.business.{ActionInterneSuspect, Client}
import com.boursorama.spark.streaming.detector.{SortieFondSuspectDetector, SortieFondSuspectDetectorMock}
import com.boursorama.spark.streaming.notifier._
import com.boursorama.utils.Conversion._
import org.apache.spark.rdd.RDD
import org.apache.spark.storage.StorageLevel
import org.apache.spark.streaming.StreamingContext
import org.apache.spark.streaming.dstream.DStream

import scala.collection.mutable
import scala.collection.mutable.ArrayBuffer

trait SortieFondPipelineMockKafka extends SortieFondPipeline with Serializable {

  override def getPersistLevel: StorageLevel = StorageLevel.MEMORY_ONLY

  override def getAppName(): String = "sp-strm-sortie-fond-cis-mockkafka"

  def getJsonSamplesSet: Seq[String] = {
    Seq(
      /* pays suspect */ "{  \"@version\": \"1\",    \"@timestamp\": \"2016-05-03T09:34:53.628Z\",    \"host\": \"tupocbi005\",    \"path\": \"/logcisprod/LOGCISW-C-20160430-193741.CSV\",    \"type\": \"cis-web\",    \"NOM SERVICE\": \"WE01KS01K\",    \"ID TRANSAC\": \"W01K02570878784\",    \"COD ASI\": \"000000000000000\",    \"COD SOP\": \"0000\",    \"ID IP\": \"80.12.59.179\",    \"ID SEANCE\": \"90795\",    \"COD UTI SFW\": \"32354028\",    \"TYP UTIL\": \"2\",    \"NUM ORDRE\": null,    \"COD AGENT\": null,    \"NOM AGENT\": null,    \"NUM TEL\": null,    \"NIV ACCES\": \"2\",    \"COD UTI BRS\": null,    \"TYP ACCES\": \"I\",    \"ID INTERNE\": \"00729913\",    \"COD CANAL\": \"W\",    \"COD OPER\": \"OTRANSFR\",    \"ANN DEBUT\": \"2016\",    \"MOI DEBUT\": \"04\",    \"JOU DEBUT\": \"30\",    \"HEU DEBUT\": \"193730\",    \"HEU MSC DEB\": \"313\",    \"ANN FIN\": \"2016\",    \"MOI FIN\": \"04\",    \"JOU FIN\": \"30\",    \"HEU FIN\": \"193731\",    \"HEU MSC FIN\": \"218\",    \"COD FIN\": \"1\",    \"COD MSGEXT\": null,    \"LIB EXT\": null,    \"COD MSGINT\": null,    \"LIB INT\": null,    \"COD BQE OP\": \"40618\",    \"COD AGE OP\": \"20000\",    \"NUM CON OP\": \"00040327669\",    \"DEV CON OP\": \"978\",    \"MTT OP\": \"2000\",    \"DEV MTT\": \"978\",    \"MTT CVAL\": \"00000000000.00\",    \"DV MTT CVAL\": null,    \"QUAN OP\": \"000\",    \"INFO OPER\": \"02-05-2016 / 20000-00016185073     / GTSEPAP\",    \"INFO OPER2\": \"40618-80263-00040695894-978\",    \"COD ASI OP\": \"060200002195876\",    \"COD SOP OP\": \"0000\",    \"ANN MAJ\": \"2016\",    \"JOU MAJ\": \"30\",    \"MOI MAJ\": \"04\",    \"HEU MAJ\": \"193731\",    \"ID OPER\": \"1462037849\",    \"NOM ABR\": \"DEVAUDBRUNO\",   \"codePaysCible\": \"CH\", \"LIB TRANS\": \"Creation TRANSFERT\"\n}",
      /* pas suspect */  "{  \"@version\": \"1\",    \"@timestamp\": \"2016-05-03T09:34:53.628Z\",    \"host\": \"tupocbi005\",    \"path\": \"/logcisprod/LOGCISW-C-20160430-193741.CSV\",    \"type\": \"cis-web\",    \"NOM SERVICE\": \"WE01KS01K\",    \"ID TRANSAC\": \"W01K02570878785\",    \"COD ASI\": \"000000000000000\",    \"COD SOP\": \"0000\",    \"ID IP\": \"80.12.59.179\",    \"ID SEANCE\": \"90795\",    \"COD UTI SFW\": \"65545919\",    \"TYP UTIL\": \"2\",    \"NUM ORDRE\": null,    \"COD AGENT\": null,    \"NOM AGENT\": null,    \"NUM TEL\": null,    \"NIV ACCES\": \"2\",    \"COD UTI BRS\": null,    \"TYP ACCES\": \"I\",    \"ID INTERNE\": \"00729913\",    \"COD CANAL\": \"W\",    \"COD OPER\": \"OTRANSFR\",    \"ANN DEBUT\": \"2016\",    \"MOI DEBUT\": \"04\",    \"JOU DEBUT\": \"30\",    \"HEU DEBUT\": \"193730\",    \"HEU MSC DEB\": \"313\",    \"ANN FIN\": \"2016\",    \"MOI FIN\": \"04\",    \"JOU FIN\": \"30\",    \"HEU FIN\": \"193731\",    \"HEU MSC FIN\": \"218\",    \"COD FIN\": \"1\",    \"COD MSGEXT\": null,    \"LIB EXT\": null,    \"COD MSGINT\": null,    \"LIB INT\": null,    \"COD BQE OP\": \"40618\",    \"COD AGE OP\": \"20000\",    \"NUM CON OP\": \"00040327669\",    \"DEV CON OP\": \"978\",    \"MTT OP\": \"10000\",    \"DEV MTT\": \"978\",    \"MTT CVAL\": \"00000000000.00\",    \"DV MTT CVAL\": null,    \"QUAN OP\": \"000\",    \"INFO OPER\": \"02-05-2016 / 20000-00016185073     / GTSEPAP\",    \"INFO OPER2\": \"40618-80263-00040695894-978\",    \"COD ASI OP\": \"060200002195876\",    \"COD SOP OP\": \"0000\",    \"ANN MAJ\": \"2016\",    \"JOU MAJ\": \"30\",    \"MOI MAJ\": \"04\",    \"HEU MAJ\": \"193731\",    \"ID OPER\": \"1462037849\",    \"NOM ABR\": \"DEVAUDBRUNO\",   \"codePaysCible\": \"FR\", \"LIB TRANS\": \"Creation TRANSFERT\"\n}",
      /* pas suspect */  "{  \"@version\": \"1\",    \"@timestamp\": \"2016-05-03T09:34:53.628Z\",    \"host\": \"tupocbi005\",    \"path\": \"/logcisprod/LOGCISW-C-20160430-193741.CSV\",    \"type\": \"cis-web\",    \"NOM SERVICE\": \"WE01KS01K\",    \"ID TRANSAC\": \"W01K02570878786\",    \"COD ASI\": \"000000000000000\",    \"COD SOP\": \"0000\",    \"ID IP\": \"80.12.59.179\",    \"ID SEANCE\": \"90795\",    \"COD UTI SFW\": \"68656476\",    \"TYP UTIL\": \"2\",    \"NUM ORDRE\": null,    \"COD AGENT\": null,    \"NOM AGENT\": null,    \"NUM TEL\": null,    \"NIV ACCES\": \"2\",    \"COD UTI BRS\": null,    \"TYP ACCES\": \"I\",    \"ID INTERNE\": \"00729913\",    \"COD CANAL\": \"W\",    \"COD OPER\": \"OTRANSFR\",    \"ANN DEBUT\": \"2016\",    \"MOI DEBUT\": \"04\",    \"JOU DEBUT\": \"30\",    \"HEU DEBUT\": \"193730\",    \"HEU MSC DEB\": \"313\",    \"ANN FIN\": \"2016\",    \"MOI FIN\": \"04\",    \"JOU FIN\": \"30\",    \"HEU FIN\": \"193731\",    \"HEU MSC FIN\": \"218\",    \"COD FIN\": \"1\",    \"COD MSGEXT\": null,    \"LIB EXT\": null,    \"COD MSGINT\": null,    \"LIB INT\": null,    \"COD BQE OP\": \"40618\",    \"COD AGE OP\": \"20000\",    \"NUM CON OP\": \"00040327669\",    \"DEV CON OP\": \"978\",    \"MTT OP\": \"30\",    \"DEV MTT\": \"978\",    \"MTT CVAL\": \"00000000000.00\",    \"DV MTT CVAL\": null,    \"QUAN OP\": \"000\",    \"INFO OPER\": \"02-05-2016 / 20000-00016185073     / GTSEPAP\",    \"INFO OPER2\": \"40618-80263-00040695894-978\",    \"COD ASI OP\": \"060200002195876\",    \"COD SOP OP\": \"0000\",    \"ANN MAJ\": \"2016\",    \"JOU MAJ\": \"30\",    \"MOI MAJ\": \"04\",    \"HEU MAJ\": \"193731\",    \"ID OPER\": \"1462037849\",    \"NOM ABR\": \"DEVAUDBRUNO\",   \"codePaysCible\": \"FR\", \"LIB TRANS\": \"Creation TRANSFERT\"\n}",
      /* cavalerie */    "{  \"@version\": \"1\",    \"@timestamp\": \"2016-05-03T09:34:53.628Z\",    \"host\": \"tupocbi005\",    \"path\": \"/logcisprod/LOGCISW-C-20160430-193741.CSV\",    \"type\": \"cis-web\",    \"NOM SERVICE\": \"WE01KS01K\",    \"ID TRANSAC\": \"W01K02570878787\",    \"COD ASI\": \"000000000000000\",    \"COD SOP\": \"0000\",    \"ID IP\": \"80.12.59.179\",    \"ID SEANCE\": \"90795\",    \"COD UTI SFW\": \"68656476\",    \"TYP UTIL\": \"2\",    \"NUM ORDRE\": null,    \"COD AGENT\": null,    \"NOM AGENT\": null,    \"NUM TEL\": null,    \"NIV ACCES\": \"2\",    \"COD UTI BRS\": null,    \"TYP ACCES\": \"I\",    \"ID INTERNE\": \"00729913\",    \"COD CANAL\": \"W\",    \"COD OPER\": \"OTRANSFR\",    \"ANN DEBUT\": \"2016\",    \"MOI DEBUT\": \"04\",    \"JOU DEBUT\": \"30\",    \"HEU DEBUT\": \"193730\",    \"HEU MSC DEB\": \"313\",    \"ANN FIN\": \"2016\",    \"MOI FIN\": \"04\",    \"JOU FIN\": \"30\",    \"HEU FIN\": \"193731\",    \"HEU MSC FIN\": \"218\",    \"COD FIN\": \"1\",    \"COD MSGEXT\": null,    \"LIB EXT\": null,    \"COD MSGINT\": null,    \"LIB INT\": null,    \"COD BQE OP\": \"40618\",    \"COD AGE OP\": \"20000\",    \"NUM CON OP\": \"00040327669\",    \"DEV CON OP\": \"978\",    \"MTT OP\": \"10000\",    \"DEV MTT\": \"978\",    \"MTT CVAL\": \"00000000000.00\",    \"DV MTT CVAL\": null,    \"QUAN OP\": \"000\",    \"INFO OPER\": \"02-05-2016 / 20000-00016185073     / GTSEPAP\",    \"INFO OPER2\": \"40618-80263-00040695894-978\",    \"COD ASI OP\": \"060200002195876\",    \"COD SOP OP\": \"0000\",    \"ANN MAJ\": \"2016\",    \"JOU MAJ\": \"30\",    \"MOI MAJ\": \"04\",    \"HEU MAJ\": \"193731\",    \"ID OPER\": \"1462037849\",    \"NOM ABR\": \"DEVAUDBRUNO\", \"codePaysCible\": \"FR\", \"LIB TRANS\": \"Creation TRANSFERT\"\n}",

      /* cavalerie et
       pays suspect*/    "{  \"@version\": \"1\",    \"@timestamp\": \"2016-05-03T09:34:53.628Z\",    \"host\": \"tupocbi005\",    \"path\": \"/logcisprod/LOGCISW-C-20160430-193741.CSV\",    \"type\": \"cis-web\",    \"NOM SERVICE\": \"WE01KS01K\",    \"ID TRANSAC\": \"W01K02570878788\",    \"COD ASI\": \"000000000000000\",    \"COD SOP\": \"0000\",    \"ID IP\": \"80.12.59.179\",    \"ID SEANCE\": \"90795\",    \"COD UTI SFW\": \"68656476\",    \"TYP UTIL\": \"2\",    \"NUM ORDRE\": null,    \"COD AGENT\": null,    \"NOM AGENT\": null,    \"NUM TEL\": null,    \"NIV ACCES\": \"2\",    \"COD UTI BRS\": null,    \"TYP ACCES\": \"I\",    \"ID INTERNE\": \"00729913\",    \"COD CANAL\": \"W\",    \"COD OPER\": \"OTRANSFR\",    \"ANN DEBUT\": \"2016\",    \"MOI DEBUT\": \"04\",    \"JOU DEBUT\": \"30\",    \"HEU DEBUT\": \"193730\",    \"HEU MSC DEB\": \"313\",    \"ANN FIN\": \"2016\",    \"MOI FIN\": \"04\",    \"JOU FIN\": \"30\",    \"HEU FIN\": \"193731\",    \"HEU MSC FIN\": \"218\",    \"COD FIN\": \"1\",    \"COD MSGEXT\": null,    \"LIB EXT\": null,    \"COD MSGINT\": null,    \"LIB INT\": null,    \"COD BQE OP\": \"40618\",    \"COD AGE OP\": \"20000\",    \"NUM CON OP\": \"00040327669\",    \"DEV CON OP\": \"978\",    \"MTT OP\": \"12550\",    \"DEV MTT\": \"978\",    \"MTT CVAL\": \"00000000000.00\",    \"DV MTT CVAL\": null,    \"QUAN OP\": \"000\",    \"INFO OPER\": \"02-05-2016 / 20000-00016185073     / GTSEPAP\",    \"INFO OPER2\": \"40618-80263-00040695894-978\",    \"COD ASI OP\": \"060200002195876\",    \"COD SOP OP\": \"0000\",    \"ANN MAJ\": \"2016\",    \"JOU MAJ\": \"30\",    \"MOI MAJ\": \"04\",    \"HEU MAJ\": \"193731\",    \"ID OPER\": \"1462037849\",    \"NOM ABR\": \"DEVAUDBRUNO\", \"codePaysCible\": \"CH\", \"LIB TRANS\": \"Creation TRANSFERT\"\n}"
    )
  }

  protected var lines: mutable.Queue[RDD[String]] = _

  override def getInputStream(ssc: StreamingContext): DStream[String] = {
    clearContainers()

    println(">> getActionInputStream")
    lines = mutable.Queue()
    val dStream = ssc.queueStream(lines)
    println("<< getActionInputStream")
    dStream
  }

  override def afterStart(ssc: StreamingContext) : Unit = {
    println(">> afterStart")
    val sc = ssc.sparkContext
    lines += sc.makeRDD( getJsonSamplesSet )
    println("<< afterStart")
  }

  override val caseNotifier: SuspectNotifier[SortieFondSuspect] = SortieFondSuspectCaseWsNotifierMock
  def getWebServiceCalls: List[SortieFondSuspect] = SortieFondSuspectCaseWsNotifierMock.getWebServiceCalls

  override val mailNotifier: SuspectNotifier[SortieFondSuspect] = SortieFondSuspectMailNotifierMock
  def getMails : List[String] = SortieFondSuspectMailNotifierMock.getMails

  // Needed for sbt test, because it's an object and so, keep previous unit test's result in memory
  def clearContainers() = {
    SortieFondSuspectMailNotifierMock.clearMails()
    SortieFondSuspectCaseWsNotifierMock.clearWsCalls()
  }
}

object SortieFondPipelineMockKafka extends SortieFondPipelineMockKafka