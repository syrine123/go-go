package com.boursorama.spark.streaming.detector

object SortieFondPaysSuspectDetectorMock extends SortieFondPaysSuspectDetector {

  val codePaysSuspects = List("HR", "MC", "LT", "RO", "CH", "LI", "BG", "EE", "CZ", "CY")
  override def getFraudeParamsFromDb(): Map[String, String] = {
    Map("listePaysARisque" -> codePaysSuspects.mkString(","))
  }

  override def getFraudeParams() : Map[String, String] = {
    getFraudeParamsFromDb()
  }
 }
