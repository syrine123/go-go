package com.boursorama.spark.persistance.es

import com.boursorama.dtl.business.ActionInterneSuspect
import com.boursorama.test.{SimpleSpec, SparkStreamingTestHelper}
import com.boursorama.utils.AppConf._
import com.boursorama.utils.Conversion._
import org.apache.spark.SparkConf
import org.apache.spark.streaming.{Seconds, StreamingContext}
import org.scalatest.GivenWhenThen


class EsHelperActionInterneSuspectWithSparkIT extends SimpleSpec with GivenWhenThen {

  def getSparkConf() : SparkConf = {
    new SparkConf()
      .setMaster("local[2]")
      .setAppName("test-pipeline")
      .set("spark.executor.memory", "1g")
      .set("es.nodes", EsNodes)
      .set("es.port", EsPort)
      .set("es.index.auto.create", "true")
  }

   "La classe EsHelper" should "indexe les donnes dans ES via Spark" in {

     Given("Une collection de champs")

     val listeSuspect = List(
       ActionInterneSuspect ("TEST", 201303, 20130330, getDateTime(2013,3,30,20,0,0), "USER1", "OP1", "Operation 1", "OP1-SOP1", "Sous Operation 1.1", "1.1.1.1", 102, None, "10001.00000001.99", "USER1Nom", "USER1Prenom", "32354028789-1", "FRAUDE1", Map("param1" -> "1", "param2" -> "1"), "log-data-1"),
       ActionInterneSuspect ("TEST", 201304, 20130410, getDateTime(2013,4,10,23,0,0), "USER2", "OP2", "Operation 2", "OP2-SOP2", "Sous Operation 2.2", "2.2.2.2", 102, None, "10001.00000002.99", "USER2Nom", "USER2Prenom", "32354028789-2", "FRAUDE1", Map("param1" -> "2", "param2" -> "2"), "log-data-2")
     )

     When("On lance spark streaming avec la methode persisteSuspect et tempo de 10sec")

     val sparkConf = getSparkConf()
     val ssc = new StreamingContext(sparkConf, Seconds(1))
     //ssc.checkpoint("/tmp/spark-checkpoint")

     val SparkStreamingTestHelper = new SparkStreamingTestHelper[ActionInterneSuspect]()

     val actionInterneSuspectDStream = SparkStreamingTestHelper.initInputStream(ssc)
     var count = 0
     actionInterneSuspectDStream.foreachRDD( rdd => { count += rdd.collect().length} )
     EsHelper.persisteActionInterneSuspect(actionInterneSuspectDStream)

     ssc.start()

     SparkStreamingTestHelper.pushToStream(ssc, listeSuspect)

     ssc.awaitTerminationOrTimeout(5000)

     Then("Les (2) ActionInterneSuspects sont indexées")
     count should be (2)

     ssc.stop()
     }
 }

