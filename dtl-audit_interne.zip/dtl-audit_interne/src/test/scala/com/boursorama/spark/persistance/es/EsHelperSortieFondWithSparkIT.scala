package com.boursorama.spark.persistance.es

import com.boursorama.dtl.business.Client
import com.boursorama.test.{SimpleSpec, SparkStreamingTestHelper}
import com.boursorama.utils.AppConf._
import com.boursorama.utils.Conversion._
import org.apache.spark.SparkConf
import org.apache.spark.streaming.{Seconds, StreamingContext}
import org.scalatest.GivenWhenThen


class EsHelperSortieFondWithSparkIT extends SimpleSpec with GivenWhenThen {

  def getSparkConf() : SparkConf = {
    new SparkConf()
      .setMaster("local[2]")
      .setAppName("test-pipeline")
      .set("spark.executor.memory", "1g")
      .set("es.nodes", EsNodes)
      .set("es.port", EsPort)
      .set("es.index.auto.create", "true")
  }

   "La classe EsHelper" should "indexe les donnes dans ES via Spark" in {

     Given("Une collection de champs")

     val listeAction = List(
       SortieFond(
         "CIS",
         201404,
         20140430,
         getDateTime(2014, 4, 30, 19, 37, 30),
         "W01K02570878784",
         65545919,
         "80.12.59.179",
         10000.0,
         "-",
         "-",
         "OTRANSFR",
         "40618",
         "20000",
         "00040327669",
         "978",
         "406182000000040327669978",
         "40618-80263-00040695894-978",
         "FR",
         Some(Client(65545919, 65545919, "NOM-CLIENT", "Prenom-Client", getDateTime(2013, 1, 4, 10, 25, 15), -10000.0, 5000.0, 1)),
         1000,
         "log"
       ),
       SortieFond(
         "CIS",
         201604,
         20160430,
         getDateTime(2016, 4, 30, 19, 37, 30),
         "W01K02570878784",
         65545919,
         "80.12.59.179",
         10000.0,
         "-",
         "-",
         "OTRANSFR",
         "40618",
         "20000",
         "00040327669",
         "978",
         "406182000000040327669978",
         "40618-80263-00040695894-978",
         "FR",
         None,
         0,
         "log"
       )
     )
     When("On lance spark streaming par la methode process et tempo de 5sec")

     val sparkConf = getSparkConf()
     val ssc = new StreamingContext(sparkConf, Seconds(1))
     //ssc.checkpoint("/tmp/spark-checkpoint")

     val SparkStreamingTestHelper = new SparkStreamingTestHelper[SortieFond]()

     val actionDStream = SparkStreamingTestHelper.initInputStream(ssc)
     var count = 0
     actionDStream.foreachRDD( rdd => { count += rdd.collect().length} )
     EsHelper.persisteSortieFond(actionDStream)

     ssc.start()

     SparkStreamingTestHelper.pushToStream(ssc, listeAction)

     ssc.awaitTerminationOrTimeout(5000)

     Then("Les (2) actions sont indexées")
     count should be (2)

     ssc.stop()
     }
 }

