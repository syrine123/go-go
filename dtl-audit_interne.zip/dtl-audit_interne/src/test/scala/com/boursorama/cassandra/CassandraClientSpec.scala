package com.boursorama.cassandra

import com.boursorama.dtl.business.{FraudeParams, Client}
import com.boursorama.test.SimpleSpec
import com.boursorama.utils.Constants._
import com.boursorama.utils.Conversion._
import org.scalatest.GivenWhenThen

class CassandraClientSpec extends SimpleSpec with GivenWhenThen {

  override def beforeAll = {
    CassandraInitTablespace.initAll()
  }

  override def afterAll = {

  }

  "La méthode getFraudeParams" should "retourner parametres de fraude " in {

    Given(" le type de fraude")

    val fraudeExtCavalerie :String = TYPE_FRAUDE_EXT_CAVALERIE
    val fraudeIntHeureSuspecte :String = TYPE_FRAUDE_INT_HEURE_SUSPECTE

    When("On appelle getFraudeParams")

    Then("Les paramètres de fraude type Cavalerie sont récupérés")

    CassandraClient.getFraudeParams(fraudeExtCavalerie) should be (
      Some(
        FraudeParams(TYPE_FRAUDE_EXT_CAVALERIE, 1,
          Map("seuilAncienneteMoinsEgalQue" -> "730", "seuilCumulRmcPlusEgalQue" -> "1000", "seuilMontantPlusEgalQue" -> "1000", "seuilSoldeCumulMoinsEgalQue" -> "-5000")
        )
      )
    )

    Then("Les paramètres de fraude type Heure Suspecte sont récupérés")

    CassandraClient.getFraudeParams(fraudeIntHeureSuspecte) should be (
      Some(
        FraudeParams(TYPE_FRAUDE_INT_HEURE_SUSPECTE, 1,
          Map("seuilHeureSuspecteMoinsQue"-> "5", "seuilHeureSuspectePlusQue"-> "22")
        )
      )
    )

    Then("Pas de params pour un mauvais code fraude")

    CassandraClient.getFraudeParams("CAVALERIE") should be( None )
  }

  "La méthode getAllPaysSuspects" should "retourner les pays suspects " in {

    Given("La class CassandraClient")

    When("On appelle getAllPaysSuspects")

    Then("La liste des pays suspects est retournée")

    CassandraClient.getAllPaysSuspects should contain allOf ("RO", "MC", "LT", "LI", "HR", "EE", "CZ", "CY", "CH", "BG")
  }


  "La méthode getClientInformationByKey" should "retourner les informations d'un client" in {

    Given(" un id web")

    val idweb :Long = 68656476

    When("On appelle getClientInformationByKey")

    val client1 = CassandraClient.getClientInformationByKey(idweb)
    val client2 = CassandraClient.getClientInformationByKey(4L)

    Then("Les données sont récupérées du référentiel client")
    //CassandraClient.getClientInformationByKey(idweb.toLong) should be(Client("68656476", 68656476, "Oueslati", "fares", getDateTime("2015-11-20T14:22:54"), 10000, 1000, 5))

    client1 should be ( Some(Client(68656476,68656476, "Oueslati" , "fares", getDateTime("2015-11-20T14:22:54.000Z") ,10000.0,1000.0,5)) )
    client2 should be ( None )
  }
}

//INSERT INTO ref_data.prm_fraude (type_fraude, statut, param_fraude) VALUES ('EXTERNE-CAVALERIE-BOOSTER', 1, '{\'seuilAncienneteMoinsEgalQue\' : \'730\',   \'seuilCumulRmcPlusEgalQue\' : \'1000\',   \'seuilMontantPlusEgalQue\' : \'0\',   \'seuilSoldeCumulMoinsEgalQue\' : \'0\' }' ) ;
