package com.boursorama.dtl.business

import org.joda.time.DateTime
import java.util.Date

case class FraudeParams(
  type_fraude: String,
  statut: Int,
  param_fraude: Map[String, String])

case class PrmRisqueInterneInterne(
  action: String,
  sys_origine: String,
  ignore: Boolean)

case class UserInformation(
  login_user: String,
  login_web_pcc: String,
  nom_service_utilisateur: String,
  nom_utilisateur: String,
  prenom_utilisateur: String,
  statut_utilisateur: Int)

case class ClientContact(
  id_dim_personne: Long,
  identifiant_web: Long)

case class Client(
  id_dim_personne: Long,
  nom: String,
  prenom: String,
  encours_cash_cav: Double,
  encours_cash_epargne: Double,
  flag_employe: Int,
  segment_sc_libelle: String,
  flag_close_to_pep: Int,
  flag_pep: Int )

case class ActionInterne(
  sys_origine: String,
  annee_mois: Int,
  id_dim_temps: Int,
  timestamp: DateTime,
  login_user: String,
  login_web_pcc: String,
  code_operation: String,
  libelle_operation: String,
  code_sous_operation: String,
  libelle_sous_operation: String,
  adresse_ip: String,
  contact_id: Option[Long] = None,
  id_web: Option[Long] = None,
  client: Option[Client] = None,
  id_compte: String,
  nom_user: String,
  prenom_user: String,
  nom_service_utilisateur: String,
  session_id: String,
  log: String,
  timestampJavaDate: Date,
  suspect: Option[ActionInterneSuspect])

case class ActionInterneSuspect(

  suspect_client_pep: Boolean,
  suspect_client_employe: Boolean,
  suspect_client_en_cours: Boolean,
  suspect_client_heure: Boolean,
  suspect_client_comex: Boolean,
  param_fraude: Map[String, String])

case class Rejet(
  log: String,
  service: String,
  sys_origine: String,
  timestamp: DateTime,
  code_cause: Int,
  cause: String,
  stack_trace: String,
  login_user: String) 

