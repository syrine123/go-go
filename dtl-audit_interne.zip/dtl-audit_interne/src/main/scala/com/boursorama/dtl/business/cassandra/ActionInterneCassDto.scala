package com.boursorama.dtl.business.cassandra

import org.joda.time.DateTime

import scala.beans.BeanProperty

/**
 * Created by ubuntu on 22/06/16.
 */
class ActionInterneCassDto(
  @BeanProperty var sys_origine: String,
  @BeanProperty var annee_mois: Int,
  @BeanProperty var id_dim_temps: Int,
  @BeanProperty var timestamp: DateTime,
  @BeanProperty var login_user: String,
  @BeanProperty var login_web_pcc: String,
  @BeanProperty var code_operation: String,
  @BeanProperty var libelle_operation: String,
  @BeanProperty var code_sous_operation: String,
  @BeanProperty var libelle_sous_operation: String,
  @BeanProperty var adresse_ip: String,
  @BeanProperty var contact_id: Long,
  @BeanProperty var id_web: Long,
  @BeanProperty var id_compte: String,
  @BeanProperty var session_id: String,
  @BeanProperty var encours_client: Double,
  @BeanProperty var suspect_client_pep: Boolean,
  @BeanProperty var suspect_client_employe: Boolean,
  @BeanProperty var suspect_client_en_cours: Boolean,
  @BeanProperty var suspect_client_heure: Boolean,
  @BeanProperty var param_fraude: Map[String, String]) extends Serializable
