package com.boursorama.dtl.business.es

import scala.beans.BeanProperty

/**
 * Created by ubuntu on 22/06/16.
 */
class ActionInterneEsDto(
  @BeanProperty var sys_origine: String,
  @BeanProperty var annee_mois: Int,
  @BeanProperty var id_dim_temps: Int,
  @BeanProperty var timestamp: String,
  @BeanProperty var date_idx: String,
  @BeanProperty var code_operation: String,
  @BeanProperty var libelle_operation: String,
  @BeanProperty var code_sous_operation: String,
  @BeanProperty var libelle_sous_operation: String,
  @BeanProperty var session_id: String,
  @BeanProperty var adresse_ip: String,
  @BeanProperty var contact_id: Long,
  @BeanProperty var id_web: Long,
  @BeanProperty var nom_client: String,
  @BeanProperty var prenom_client: String,  
  @BeanProperty var login_user: String,
  @BeanProperty var login_web_pcc: String,
  @BeanProperty var nom_user: String,
  @BeanProperty var prenom_user: String,
  @BeanProperty var nom_service_utilisateur: String,
  @BeanProperty var id_compte: String,
  @BeanProperty var log: String,
  @BeanProperty var suspect_client_pep: Boolean,
  @BeanProperty var suspect_client_employe: Boolean,
  @BeanProperty var suspect_client_en_cours: Boolean,
  @BeanProperty var suspect_client_heure: Boolean,
  @BeanProperty var suspect_client_comex: Boolean,
  @BeanProperty var param_fraude: String,
  @BeanProperty var id_es: String) extends Serializable
