package com.boursorama.utils

object Constants {
  val EmptyStringField = "-"
  val EmptyLongField = -1
  val EmptyDoubleField = 0
  val TimeZoneParis = "Europe/Paris"
  val FluxCISE = "CISE"
  val FluxCIS5250 = "CIS5250"
  val FluxAtos = "ATOS"
  val FluxCrm = "CRM"
  val SUFFIX_BASE_FRAUDE = "-BASE-FRAUDE"

  val TYPE_FRAUDE_INT_HEURE_SUSPECTE: String = "INTERNE-HEURE-SUSPECTE"
  val TYPE_FRAUDE_INT_ENCOURS_SUPERIEUR: String = "INTERNE-ENCOURS-SUPERIEUR"
  val TYPE_FRAUDE_INT_CLIENT_PEP: String = "TYPE_FRAUDE_INT_CLIENT_PEP"
  val TYPE_FRAUDE_INT_CLIENT_EMPLOYE: String = "INTERNE-CLIENT-EMPLOYE"
  val TYPE_FRAUDE_INT_CLIENT_COMEX: String = "INTERNE-CLIENT-COMEX"

  // INTERNE
  val AUDIT_INTERNE_HEURE_SUSPECTE_PLUS_EGAL_QUE: String = "22"
  val AUDIT_INTERNE_HEURE_SUSPECTE_MOINS_QUE: String = "7"

  val AUDIT_INTERNE_LISTE_COMEX: String = "333,111"

  val CONSUMER_TREADS_PER_UNPUT_DSTREAM = 3

}
