package com.boursorama.utils

import com.boursorama.utils.Constants._
import org.joda.time._
import org.joda.time.format.{ DateTimeFormat, DateTimeFormatter }
import java.util.Date

object Conversion {

  DateTimeZone.setDefault(DateTimeZone.UTC)
  val timestampFormat: DateTimeFormatter = DateTimeFormat.forPattern("yyyy-MM-dd'T'HH:mm:ss").withZoneUTC()
  val yearMonthFormat: DateTimeFormatter = DateTimeFormat.forPattern("yyyyMM").withZoneUTC()
  val yearMonthDayFormat: DateTimeFormatter = DateTimeFormat.forPattern("yyyyMMdd").withZoneUTC()
  val ParisTimeZone: DateTimeZone = DateTimeZone.forID("Europe/Paris")

  def cleanTimeZone(timestamp: String): String = {
    timestamp.split('.')(0)
  }

  protected def now(): DateTime = {
    new DateTime(new Date(), DateTimeZone.UTC)
  }

  def nowToDateTime(): DateTime = {
    now()
  }

  def nowToString(): String = {
    timestampFormat.print(now())
  }

  def dateToDateTime(date: Date): DateTime = {
    new DateTime(date, DateTimeZone.UTC)
  }

  def getDateTime(time: Long): DateTime = {
    new DateTime(time, DateTimeZone.UTC)
  }

  def getDateTime(time: Long, dateTimeZone: DateTimeZone): DateTime = {
    new DateTime(time, dateTimeZone).withZone(DateTimeZone.UTC)
  }

  def getDateTime(year: Int, month: Int, day: Int, hour: Int, min: Int, sec: Int): DateTime = {
    new DateTime(year, month, day, hour, min, sec, DateTimeZone.UTC)
  }

  def getDateTime(year: Int, month: Int, day: Int, hour: Int, min: Int, sec: Int, dateTimeZone: DateTimeZone): DateTime = {
    new DateTime(year, month, day, hour, min, sec, dateTimeZone).withZone(DateTimeZone.UTC)
  }

  def dateTimeToString(timestamp: DateTime): String = {
    timestampFormat.print(timestamp)
  }

  def getYearMonth(date: DateTime): Int = {
    yearMonthFormat.print(date).toInt
  }

  def getYearMonthDay(date: DateTime): Int = {
    yearMonthDayFormat.print(date).toInt
  }

  def escapeSimpleQuote(line: String): String = {
    line.replace("'", "\\'")
  }

  def NoneToLong(num: Option[Long]): Long = {
    num match {
      case Some(v) => v
      case _       => EmptyLongField
    }
  }

  def NoneToDouble(num: Option[Double]): Double = {
    num match {
      case Some(v) => v
      case _       => EmptyDoubleField
    }
  }

  def NoneToString(num: Option[String]): String = {
    num match {
      case Some(v) => v
      case _       => EmptyStringField
    }
  }
  
    def NoneToBoolean(num: Option[Boolean]): Boolean = {
    num match {
      case Some(v) => v
      case _       => false
    }
  }

}
