package com.boursorama.utils

import javax.mail.internet.InternetAddress
import com.typesafe.config.ConfigFactory
import java.io.File

object AppConf extends Serializable {

  val fileInfra = sys.env("BRS_SPARK_ENV_CONF")
  
  val confInfra = ConfigFactory.parseFile(new File(fileInfra))
  
  val conf = ConfigFactory.load("application.conf")

  val SparkConcurrentJobs = conf.getString("SparkConcurrentJobs")

  val SenderAuditMail = confInfra.getString("MAIL_FROM")
  val RecipientAuditMail = conf.getString("RecipientAuditMail").split(";").map(new InternetAddress(_))

  val SmtpHost = confInfra.getString("SMTP_HOST")
  val SmtpPort = confInfra.getString("SMTP_PORT")

  val SparkBatchWindow = conf.getInt("SparkBatchWindow")

  val CassandraNodes = confInfra.getString("CASSANDRA_SERVERS")
  val CassandraUsername = confInfra.getString("CASSANDRA_LOGIN")
  val CassandraPassword = confInfra.getString("CASSANDRA_PASSWORD")

  val EsNodes = confInfra.getString("ES_SERVERS")
  val EsPort = confInfra.getString("ES_PORT")
  val EsUsername = confInfra.getString("ES_LOGIN")
  val EsPassword = confInfra.getString("ES_PASSWORD")

  val CassandraReferentielKeySpace = conf.getString("CassandraReferentielKeySpace")
  val CassandraInternalRiskKeySpace = conf.getString("CassandraInternalRiskKeySpace")
  val CassandraAuditDtlKeySpace = conf.getString("CassandraAuditDtlKeySpace")

  // val KafkaBroker = confInfra.getString("KAFKA_SERVERS")

  val zkQuorum = confInfra.getString("ZK_SERVERS")

  val KafkaTopicAtos = conf.getString("KafkaTopicAtos")
  val KafkaTopicCis = conf.getString("KafkaTopicCis")
  val KafkaTopicCrm = conf.getString("KafkaTopicCrm")


}
