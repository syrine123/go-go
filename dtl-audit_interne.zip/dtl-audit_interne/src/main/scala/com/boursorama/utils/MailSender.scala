package com.boursorama.utils

import javax.mail._
import javax.mail.internet._
import com.boursorama.utils.Constants._

object MailSender {

  def send(sender: String, recipients: Array[InternetAddress], subject: String, body: String, test: Boolean = false): String = {
    innerSend(sender, recipients, subject, body, test)
  }

  protected def innerSend(sender: String, recipients: Array[InternetAddress], subject: String, body: String, test: Boolean): String = {

    val properties = System.getProperties()
    properties.setProperty("mail.smtp.host", AppConf.SmtpHost)
    properties.setProperty("mail.smtp.port", AppConf.SmtpPort)
    properties.setProperty("mail.mime.charset", "UTF-8")
    val session = Session.getDefaultInstance(properties)
    val message = new MimeMessage(session)
    message.setFrom(new InternetAddress(sender))
    message.addRecipients(Message.RecipientType.TO, recipients.map(_.asInstanceOf[Address]))
    message.setSubject(subject)
    message.setText(body)

    if (!test) {
      Transport.send(message)
    }
    "{\"smtpHost\": \"" + AppConf.SmtpHost + ":" + AppConf.SmtpPort + "\", \"sender\": \"" + sender + "\", \"to\": \"" + recipients.toString + "\", \"subject\": \"" + subject + "\", \"body\": \"" + body + "\"}"
  }
}
