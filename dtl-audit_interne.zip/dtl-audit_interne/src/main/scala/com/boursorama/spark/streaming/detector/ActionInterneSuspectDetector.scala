package com.boursorama.spark.streaming.detector

import com.boursorama.dtl.business.ActionInterne
import com.boursorama.dtl.business.FraudeParams
import com.boursorama.dtl.business.ActionInterneSuspect

object ActionInterneSuspectDetector extends Serializable {

  val suspect1: (Option[ActionInterne], Array[FraudeParams]) => Option[ActionInterneSuspect] = ActionInterneClientPepDetector.suspect
  val suspect2: (Option[ActionInterne], Array[FraudeParams]) => Option[ActionInterneSuspect] = ActionInterneClientEmploye.suspect
  val suspect3: (Option[ActionInterne], Array[FraudeParams]) => Option[ActionInterneSuspect] = ActionInterneEncoursSupDetector.suspect
  val suspect4: (Option[ActionInterne], Array[FraudeParams]) => Option[ActionInterneSuspect] = ActionInterneHeureSuspecteDetector.suspect
  val suspect5: (Option[ActionInterne], Array[FraudeParams]) => Option[ActionInterneSuspect] = ActionInterneClientComex.suspect

  def suspect(actionInterne: Option[ActionInterne], arrayFraude: Array[FraudeParams]): Option[ActionInterne] = {
    val detectors = List(suspect1, suspect2, suspect3, suspect4, suspect5)

    val listActionInterneSuspect = detectors.flatMap(detector => detector(actionInterne, arrayFraude))
    if (listActionInterneSuspect.nonEmpty) {
      val actionInterneSuspect = listActionInterneSuspect.reduce((a, b) =>
        if (a != null && b != null) {
            a.copy(
              suspect_client_pep = a.suspect_client_pep || b.suspect_client_pep,
              suspect_client_employe = a.suspect_client_employe || b.suspect_client_employe,
              suspect_client_en_cours = a.suspect_client_en_cours || b.suspect_client_en_cours,
              suspect_client_heure = a.suspect_client_heure || b.suspect_client_heure,
              suspect_client_comex = a.suspect_client_comex || b.suspect_client_comex,
              param_fraude = (a.param_fraude.toList ++ b.param_fraude.toList).groupBy(_._1).map{case(k, v) => k -> v.map(_._2).mkString(" et ")})
        } else if (a != null && b == null) {
          a
        } else if (a == null && b != null) {
          b
        } else {
          null
        })
      Some(actionInterne.get.copy(suspect = Some(actionInterneSuspect)))
    } else {
      actionInterne
    }
  }
}

