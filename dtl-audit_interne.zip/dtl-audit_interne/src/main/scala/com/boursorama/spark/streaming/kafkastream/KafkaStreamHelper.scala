package com.boursorama.spark.streaming.kafkastream

import org.apache.spark.streaming.StreamingContext
import org.apache.spark.streaming.dstream.DStream
import org.apache.spark.streaming.kafka.KafkaUtils
import com.boursorama.utils.AppConf._
import kafka.serializer.StringDecoder
import com.boursorama.utils.Constants.CONSUMER_TREADS_PER_UNPUT_DSTREAM
import org.apache.spark.storage.StorageLevel

class KafkaStreamHelper extends Serializable {

  def getInputStream(ssc: StreamingContext, topicSet: Set[String], groupId: String): DStream[(String,String)] = {

    var topicMap = Map[String, Int]()

    for (x <- topicSet) {
      topicMap += (x -> CONSUMER_TREADS_PER_UNPUT_DSTREAM)
    }

    val kafkaParams = Map[String, String](
      "group.id" -> groupId,
      "auto.offset.reset" -> "smallest",
      "zookeeper.connect" -> zkQuorum,
      "zookeeper.connection.timeout.ms" -> "10000")

    KafkaUtils.createStream[String, String, StringDecoder, StringDecoder](ssc, kafkaParams, topicMap, StorageLevel.MEMORY_AND_DISK_SER_2)

  }

}

object KafkaStreamHelper extends KafkaStreamHelper
