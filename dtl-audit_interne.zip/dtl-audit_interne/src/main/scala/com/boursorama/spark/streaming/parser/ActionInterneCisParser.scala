package com.boursorama.spark.streaming.parser

import scala.util.Failure
import scala.util.Success
import scala.util.Try

import org.joda.time.DateTime
import org.json4s.DefaultFormats
import org.json4s.JsonAST.JValue
import org.json4s.jackson.JsonMethods.parse

import com.boursorama.dtl.business.ActionInterne
import com.boursorama.dtl.business.Rejet
import com.boursorama.utils.Constants.EmptyLongField
import com.boursorama.utils.Constants.EmptyStringField
import com.boursorama.utils.Constants.FluxCIS5250
import com.boursorama.utils.Constants.FluxCISE
import com.boursorama.utils.Conversion.ParisTimeZone
import com.boursorama.utils.Conversion.getDateTime
import com.boursorama.utils.Conversion.getYearMonth
import com.boursorama.utils.Conversion.getYearMonthDay
import com.datastax.spark.connector.cql.CassandraConnector
import com.boursorama.dtl.business.PrmRisqueInterneInterne

object ActionInterneCisParser extends ActionInterneParser[Either[Rejet, Option[ActionInterne]]] {

  @transient lazy val logger = org.apache.log4j.LogManager.getLogger("ActionInterneCisParser")

  def cleanActionLineCis(line: String): String = line match {
    case s if s.length() > 0 => line.replace("{", "e").replace("}", "e")
    case _                   => line
  }

  def makeTimestampFromCIS(year: String, month: String, day: String, time: String): DateTime = {
    Try(
      getDateTime(year.toInt, month.toInt, day.toInt, time.substring(0, 2).toInt, time.substring(2, 4).toInt, time.substring(4, 6).toInt, ParisTimeZone)) match {
        case Success(v) => v
        case Failure(v) => getDateTime(0, 0, 0, 0, 0, 0)
      }
  }
  override def parseLine(logLine: String, arrayPrmRisqueInterneInterne: Array[PrmRisqueInterneInterne]): Either[Rejet, Option[ActionInterne]] = {
    try {
      implicit val formats = DefaultFormats
      val json = parse(logLine)
      val log_type = (json \ "tags").extractOpt[List[String]].getOrElse(List())

      log_type match {
        case tags if tags.contains("CIS_5250") => parseLine_s5250(logLine, json, arrayPrmRisqueInterneInterne)
        case tags if tags.contains("CIS_E")    => parseLine_e(logLine, json, arrayPrmRisqueInterneInterne)
        case _                                 => Right(None)
      }
    } catch {
      case e: Exception =>
        Right(None)
    }
  }

  def getCliendId(num: Long): Option[Long] = {
    num match {
      case EmptyLongField => None
      case _              => Some(num)
    }
  }

  def parseLine_s5250(logLine: String, json: JValue, arrayPrmRisqueInterneInterne: Array[PrmRisqueInterneInterne]): Either[Rejet, Option[ActionInterne]] = {

    try {
      implicit val formats = DefaultFormats
      val year = (json \ "Annee operation").extractOpt[String].getOrElse("")
      val month = (json \ "Mois operation").extractOpt[String].getOrElse("")
      val day = (json \ "Jour operation").extractOpt[String].getOrElse("")
      val time = (json \ "Heure operation").extractOpt[String].getOrElse("")
      val timestamp = makeTimestampFromCIS(year, month, day, time)
      val anneeMois = getYearMonth(timestamp)
      val idDimTemps = getYearMonthDay(timestamp)
      val userLogin = (json \ "Nom user").extractOpt[String].getOrElse(EmptyStringField).toUpperCase
      val codeOperation = (json \ "Tache utilisee").extractOpt[String].getOrElse(EmptyStringField)
      val libelleOperation = cleanActionLineCis((json \ "Libelle Tache").extractOpt[String].getOrElse(EmptyStringField))
      val codeSousOperation = (json \ "Option choisie").extractOpt[String].getOrElse(EmptyStringField)
      val libelleSousOperation = (json \ "Libelle option").extractOpt[String].getOrElse(EmptyStringField)

      if (isIgnoredAction(libelleOperation, FluxCIS5250, arrayPrmRisqueInterneInterne)) {
        Right(None)
      } else {
        Right(Some(ActionInterne(
          FluxCIS5250,
          anneeMois,
          idDimTemps,
          timestamp,
          userLogin,
          null,
          codeOperation,
          libelleOperation,
          codeSousOperation,
          libelleSousOperation,
          EmptyStringField,
          None,
          None,
          None,
          EmptyStringField,
          EmptyStringField,
          EmptyStringField,
          EmptyStringField,
          EmptyStringField,
          logLine,
          timestamp.toDate(),
          None)))
      }
    } catch {
      case e: Exception => {
        //        Left(
        //          Rejet(
        //            logLine,
        //            "ActionInterneCisParser",
        //            FluxCIS5250,
        //            DateTime.now(),
        //            1,
        //            "PARSE ERROR",
        //            e.toString + " => " + e.getStackTrace.mkString("||"),
        //            ""))
        logger.error(logLine, e)
        Left(null)
      }
    }
  }

  /*
  CODE UTI BRS : login_web_pcc of the utilisateur
  CODE UTI : client web login (don't forget to do the match between CODE UTI and the web identifiant in dim_personne
   */
  def parseLine_e(logLine: String, json: JValue, arrayPrmRisqueInterneInterne: Array[PrmRisqueInterneInterne]): Either[Rejet, Option[ActionInterne]] = {

    try {
      implicit val formats = DefaultFormats
      val codeOperation = (json \ "COD OPER").extractOpt[String].getOrElse(EmptyStringField)

      val year = (json \ "ANN DEBUT").extractOpt[String].getOrElse("")
      val month = (json \ "MOI DEBUT").extractOpt[String].getOrElse("")
      val day = (json \ "JOU DEBUT").extractOpt[String].getOrElse("")
      val time = (json \ "HEU DEBUT").extractOpt[String].getOrElse("")
      val timestamp = makeTimestampFromCIS(year, month, day, time)
      val anneeMois = getYearMonth(timestamp)
      val idDimTemps = getYearMonthDay(timestamp)
      val login_web_pcc = (json \ "COD UTI BRS").extractOpt[String].getOrElse(EmptyStringField).toUpperCase
      val libelleOperation = cleanActionLineCis((json \ "LIB TRANS").extractOpt[String].getOrElse(EmptyStringField))
      val adresseIp = (json \ "ID IP").extractOpt[String].getOrElse(EmptyStringField)
      val id_web = getCliendId((json \ "COD UTI").extractOpt[String].getOrElse("-1").toLong)

      if (isIgnoredAction(libelleOperation, FluxCISE, arrayPrmRisqueInterneInterne)) {
        Right(None)
      } else {
        Right(Some(ActionInterne(
          FluxCISE,
          anneeMois,
          idDimTemps,
          timestamp,
          null,
          login_web_pcc,
          codeOperation,
          libelleOperation,
          EmptyStringField,
          EmptyStringField,
          adresseIp,
          None,
          id_web,
          None,
          EmptyStringField,
          EmptyStringField,
          EmptyStringField,
          EmptyStringField,
          EmptyStringField,
          logLine,
          timestamp.toDate(),
          None)))
      }
    } catch {
      case e: Exception => {
        //        Left(
        //        Rejet(
        //          logLine,
        //          "ActionInterneCisParser",
        //          FluxCISE,
        //          DateTime.now(),
        //          1,
        //          "PARSE ERROR",
        //          e.toString + " => " + e.getStackTrace.mkString("||"),
        //          ""))
        logger.error(logLine, e)
        Left(null)
      }
    }

  }
}

