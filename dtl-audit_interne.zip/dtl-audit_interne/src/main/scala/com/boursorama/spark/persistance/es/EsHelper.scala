package com.boursorama.spark.persistance.es

import com.boursorama.dtl.business._
import com.boursorama.dtl.business.es._
import com.boursorama.utils.Conversion._
import org.apache.spark.streaming.dstream.DStream
import org.elasticsearch.spark.streaming._

object EsHelper extends Serializable {

  def getActionInterneIndexName: String = "idx-action-interne-{annee_mois}/action-interne"

  def persisteActionInterne(actionInterneDStream: DStream[ActionInterne]): Unit = {
    actionInterneDStream
      .map(actionInterne => mapToDto(actionInterne))
      .saveToEs(getActionInterneIndexName, Map("es.mapping.id" -> "id_es", "es.write.operation" -> "upsert"))
  }

  def mapToDto(actionInterne: ActionInterne): ActionInterneEsDto = {
    var nomClient = ""
    var prenomClient = ""
    var suspect_client_pep = false
    var suspect_client_employe = false
    var suspect_client_en_cours = false
    var suspect_client_heure = false
    var suspect_client_comex = false
    var param_fraude = ""

    if (actionInterne.client != None) {
      nomClient = actionInterne.client.get.nom
      prenomClient = actionInterne.client.get.prenom
    }
    if (actionInterne.suspect != None) {

      suspect_client_pep = actionInterne.suspect.get.suspect_client_pep
      suspect_client_employe = actionInterne.suspect.get.suspect_client_employe
      suspect_client_en_cours = actionInterne.suspect.get.suspect_client_en_cours
      suspect_client_heure = actionInterne.suspect.get.suspect_client_heure
      suspect_client_comex = actionInterne.suspect.get.suspect_client_comex
      param_fraude = actionInterne.suspect.get.param_fraude.toString()
    }

    new ActionInterneEsDto(
      actionInterne.sys_origine,
      actionInterne.annee_mois,
      actionInterne.id_dim_temps,
      dateTimeToString(actionInterne.timestamp),
      nowToString(),
      actionInterne.code_operation,
      actionInterne.libelle_operation,
      actionInterne.code_sous_operation,
      actionInterne.libelle_sous_operation,
      actionInterne.session_id,
      actionInterne.adresse_ip,
      NoneToLong(actionInterne.contact_id),
      NoneToLong(actionInterne.id_web),
      nomClient,
      prenomClient,
      actionInterne.login_user,
      actionInterne.login_web_pcc,
      actionInterne.nom_user,
      actionInterne.prenom_user,
      actionInterne.nom_service_utilisateur,
      actionInterne.id_compte,
      actionInterne.log,
      suspect_client_pep,
      suspect_client_employe,
      suspect_client_en_cours,
      suspect_client_heure,
      suspect_client_comex,
      param_fraude,
      dateTimeToString(actionInterne.timestamp)+actionInterne.login_user+actionInterne.libelle_operation)
  }

}
