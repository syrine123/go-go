package com.boursorama.spark.streaming.notifier

import com.boursorama.dtl.business.ActionInterne
import com.boursorama.utils.AppConf._
import com.boursorama.utils.Conversion._
import com.boursorama.utils.MailSender

object ActionInterneSuspectMailNotifier extends SuspectFiltredNotifier[ActionInterne] with Serializable {

  @transient lazy val logger = org.apache.log4j.LogManager.getLogger("actionInterneMailNotifier")

  override def notifySuspect(actionInterne: ActionInterne): Unit = {
    sendMail(actionInterne, false)
  }

  override def filterSuspect(actionInterne: ActionInterne): Boolean = {
	actionInterne.suspect.isDefined && (actionInterne.suspect.get.suspect_client_comex || actionInterne.suspect.get.suspect_client_pep)
  }

  def sendMail(internSuspect: ActionInterne, testMode: Boolean): String = {
    logger.debug(s" - actionInterneMailNotifier.sendMail")
    val startTime = System.currentTimeMillis()
    val mailSubject = formatMailSubject(internSuspect)
    val mailBody = formatMailBody(internSuspect)
    val result = MailSender.send(SenderAuditMail, RecipientAuditMail, mailSubject, mailBody, testMode)
    val execTime = System.currentTimeMillis() - startTime
    logger.debug(s"     took : $execTime ms")
    result
  }

  def formatMailSubject(actionInterne: ActionInterne): String = {
    "Action suspecte : " + actionInterne.suspect.get.param_fraude.getOrElse("type_action", "")
  }

  def formatMailBody(actionInterne: ActionInterne): String = {
    var nomClient = ""
    var prenomClient = ""
    if (actionInterne.client != None) {
      nomClient = actionInterne.client.get.nom
      prenomClient = actionInterne.client.get.prenom
    }
    "Action suspecte détectée : \r\n\n" +
      "Contact ID : " + NoneToLong(actionInterne.contact_id) + "   \r\n" +
      "ID Web : " + NoneToLong(actionInterne.id_web) + "    \r\n" +
      "Nom du client: " + nomClient + "    \r\n" +
      "Prénom du client: " + prenomClient + "    \r\n" +
      "Date opération : " + actionInterne.timestamp.toString() + "    \r\n" +
      "Applicatif : " + actionInterne.sys_origine + "    \r\n" +
      "Libellé opération : " + actionInterne.libelle_operation + "    \r\n" +
      "Login utilisateur : " + actionInterne.login_user + "    \r\n" +
      "Nom utilisateur : " + actionInterne.nom_user + "    \r\n" +
      "Prénom utilisateur : " + actionInterne.prenom_user + "    \r\n" +
      "Service de rattachement de l'utilisateur : " + actionInterne.nom_service_utilisateur + "    \r\n" +
      "\r\n\r\n"
  }
}
