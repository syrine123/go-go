package com.boursorama.spark.streaming.notifier

import org.apache.spark.streaming.dstream.DStream

trait SuspectNotifier[T] extends Serializable {

  def notify(stream: DStream[T]): Unit = {
    stream.
      foreachRDD(rdd => rdd.foreach(action => notifySuspect(action)))
  }

  def notifySuspect(action: T) : Unit
}
