package com.boursorama.spark.streaming.detector

import com.boursorama.dtl.business.{ActionInterne, ActionInterneSuspect, FraudeParams}
import com.boursorama.utils.Constants.TYPE_FRAUDE_INT_ENCOURS_SUPERIEUR

object ActionInterneEncoursSupDetector extends Serializable {

  @transient lazy val logger = org.apache.log4j.LogManager.getLogger("ActionInterneEncoursSupDetector")

  def getFraudeParams(arrayFraude: Array[FraudeParams]): Map[String, String] = {
    val option = getFraudeParams(arrayFraude, TYPE_FRAUDE_INT_ENCOURS_SUPERIEUR)
    option match {
      case None               => Map()
      case Some(fraudeParams) => fraudeParams.param_fraude
    }
  }

  def getFraudeParams(arrayFraude: Array[FraudeParams], fraudeType: String): Option[FraudeParams] = {
    if (arrayFraude != null) {
      arrayFraude.
        find(x =>
          if (x.type_fraude != null && x.type_fraude.equals(fraudeType)) {
            true
          } else {
            false
          })
    } else {
      None
    }
  }

  def suspect(actionInterne: Option[ActionInterne], arrayFraude: Array[FraudeParams]): Option[ActionInterneSuspect] = {
    if (actionInterne != None && actionInterne.get.client != None) {
      var paramsMap = getFraudeParams(arrayFraude)
      var seuilEncoursPlusQue = paramsMap.getOrElse("seuilEncoursPlusEgalQue", "100000").toDouble
      if (seuilEncoursPlusQue < (actionInterne.get.client.get.encours_cash_cav + actionInterne.get.client.get.encours_cash_epargne)) {
        logger.debug(s"     - Action interne suspecte de type (consultation encours supérieur) détectée ! - ${actionInterne.toString}")
        Some(ActionInterneSuspect(
          suspect_client_pep = false,
          suspect_client_employe = false,
          suspect_client_en_cours = true,
          suspect_client_heure = false,
          suspect_client_comex = false,
          Map("type_action" -> TYPE_FRAUDE_INT_ENCOURS_SUPERIEUR, "seuilEncoursPlusQue" -> seuilEncoursPlusQue.toString())))
      } else None
    } else None
  }
}

