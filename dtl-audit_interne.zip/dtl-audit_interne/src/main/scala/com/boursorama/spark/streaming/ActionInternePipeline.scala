package com.boursorama.spark.streaming

import com.boursorama.dtl.business._
import com.boursorama.spark.persistance.cassandra.CassandraHelper
import com.boursorama.spark.persistance.es.EsHelper
import com.boursorama.spark.streaming.detector.ActionInterneSuspectDetector
import com.boursorama.spark.streaming.notifier._
import com.boursorama.spark.streaming.parser._
import com.boursorama.utils.Conversion._
import com.datastax.spark.connector.cql.CassandraConnector
import org.apache.spark.streaming.dstream.DStream

class ActionInternePipeline(connector: CassandraConnector, prmRisqueInterneInterne: Array[PrmRisqueInterneInterne], fraudes: Array[FraudeParams]) extends Serializable {

  val cassandraConnector: CassandraConnector = connector
  val arrayFraude: Array[FraudeParams] = fraudes
  val arrayPrmRisqueInterneInterne: Array[PrmRisqueInterneInterne] = prmRisqueInterneInterne

  @transient lazy val logger = org.apache.log4j.LogManager.getLogger("ActionInternePipeline")

  val UNKNOWN_LOGIN_IN_DWH_ERROR = 0
  val UNKNOWN_CONTACT_ID_IN_REF_CLIENT_360 = 1

  val causes = Map[Int, String](
    UNKNOWN_LOGIN_IN_DWH_ERROR -> "Login non trouvé dans le DWH",
    UNKNOWN_CONTACT_ID_IN_REF_CLIENT_360 -> "Contact id introuvable dans ref client 360")

  def process(dstream: DStream[(String, String)]): DStream[Either[Rejet, Option[ActionInterne]]] = {
    dstream.map(pair =>
      if (pair._1 != null && pair._1.contains("crm-interne")) {
        //"crm-interne-%{@timestamp}"
        enricheAction(ActionInterneCrmParser.parseLine(pair._2, arrayPrmRisqueInterneInterne))
      } else if (pair._1 != null && pair._1.contains("cis")) {
        //"cis-%{@timestamp}"
        enricheAction(ActionInterneCisParser.parseLine(pair._2, arrayPrmRisqueInterneInterne))
      } else if (pair._1 != null && pair._1.contains("atos")) {
        //"atos-%{@timestamp}"
        enricheAction(ActionInterneAtosParser.parseLine(pair._2, arrayPrmRisqueInterneInterne))
      } else {
        Right(None)
      })
  }

  def enricheAction(actionInterne: Either[Rejet, Option[ActionInterne]]): Either[Rejet, Option[ActionInterne]] = {
    if (actionInterne.isRight && actionInterne.right.get.isDefined) {
      detectSuspect(enrichWithClientInfo(enrichWithUserInfo(actionInterne)))
    } else {
      actionInterne
    }
  }

  def enrichWithUserInfo(actionInterne: Either[Rejet, Option[ActionInterne]]): Either[Rejet, Option[ActionInterne]] = {
    val userInformation: Option[UserInformation] = CassandraHelper.getUtilisateurInformation(actionInterne.right.get.get.login_user, actionInterne.right.get.get.login_web_pcc, cassandraConnector)

    userInformation match {
      case Some(userInformation) => {
        Right(Some(actionInterne.right.get.get.copy(
          nom_user = escapeSimpleQuote(userInformation.nom_utilisateur),
          prenom_user = escapeSimpleQuote(userInformation.prenom_utilisateur),
          nom_service_utilisateur = userInformation.nom_service_utilisateur,
          login_user = userInformation.login_user,
          login_web_pcc = userInformation.login_web_pcc)))
      }
      case None => {
        val errorMess: String = causes.getOrElse(UNKNOWN_LOGIN_IN_DWH_ERROR, "UNKNOWN")
        logger.debug(errorMess + " in log " + actionInterne.right.get.get.log)
        if (actionInterne.right.get.get.login_user == null) {
          Right(Some(actionInterne.right.get.get.copy(
            login_user = "-")))
        } else {
          actionInterne
        }
      }
    }
  }

  def enrichWithClientInfo(actionInterne: Either[Rejet, Option[ActionInterne]]): Either[Rejet, Option[ActionInterne]] = {
    var client: Option[Client] = None
    if (actionInterne.right.get.get.contact_id != None) {
      client = CassandraHelper.getClientInformation(NoneToLong(actionInterne.right.get.get.contact_id), cassandraConnector)
    } else if (actionInterne.right.get.get.id_web != None) {
      val clientcontact: Option[ClientContact] = CassandraHelper.getClientContactInformation(NoneToLong(actionInterne.right.get.get.id_web), cassandraConnector)
      clientcontact match {
        case None => {
          client = None
        }
        case Some(clientcontact) => {
          client = CassandraHelper.getClientInformation(clientcontact.id_dim_personne, cassandraConnector)
        }
      }
    }

    client match {
      case Some(client) => {
        Right(Some(actionInterne.right.get.get.copy(client = Some(client),
          contact_id = Some(client.id_dim_personne))))
      }
      case None => {
        val errorMess: String = causes.getOrElse(UNKNOWN_CONTACT_ID_IN_REF_CLIENT_360, "UNKNOWN")
        logger.debug(errorMess + " in log " + actionInterne.right.get.get.log)
        actionInterne
      }
    }
  }

  def detectSuspect(actionInterne: Either[Rejet, Option[ActionInterne]]): Either[Rejet, Option[ActionInterne]] = {
    Right(ActionInterneSuspectDetector.suspect(actionInterne.right.get, arrayFraude))
  }

  def persisteAction(actionInterneDStream: DStream[Either[Rejet, Option[ActionInterne]]]) = {
    //  Ne plus persister les erreurs dans cassandra : CassandraHelper.persistRejet(actionInterneDStream.filter(_.isLeft).map(_.left.get))
    CassandraHelper.persisteActionInterne(actionInterneDStream.filter(_.isRight).filter(_.right.get.isDefined).map(_.right.get.get))
    EsHelper.persisteActionInterne(actionInterneDStream.filter(_.isRight).filter(_.right.get.isDefined).map(_.right.get.get))
  }

  def notifySuspect(actionInterneDStream: DStream[Either[Rejet, Option[ActionInterne]]]) = {
    ActionInterneSuspectMailNotifier.notify(actionInterneDStream.filter(_.isRight).filter(_.right.get.isDefined).map(_.right.get.get))
  }

}
