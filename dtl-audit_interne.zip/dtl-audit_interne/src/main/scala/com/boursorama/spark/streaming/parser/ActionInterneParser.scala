package com.boursorama.spark.streaming.parser

import com.boursorama.dtl.business.ActionInterne
import com.boursorama.dtl.business.Rejet
import com.boursorama.spark.persistance.cassandra.CassandraHelper
import com.datastax.spark.connector.cql.CassandraConnector
import com.boursorama.dtl.business.PrmRisqueInterneInterne

trait ActionInterneParser[T] extends Serializable {

  def parseLine(logLine: String, arrayPrmRisqueInterneInterne: Array[PrmRisqueInterneInterne]): Either[Rejet, Option[ActionInterne]]

  def isIgnoredAction(action: String, sys_origine: String, arrayPrmRisqueInterneInterne: Array[PrmRisqueInterneInterne]): Boolean = {
    arrayPrmRisqueInterneInterne!=null && !arrayPrmRisqueInterneInterne.isEmpty && !arrayPrmRisqueInterneInterne.
      find(x =>
        if (x.action != null && x.action.equals(action) && x.sys_origine != null && x.sys_origine.equals(sys_origine) && x.ignore == true) {
          true
        } else {
          false
        }).isEmpty
  }

}
