package com.boursorama.spark.streaming.detector

import com.boursorama.dtl.business.ActionInterne
import com.boursorama.dtl.business.FraudeParams
import com.boursorama.utils.Constants.AUDIT_INTERNE_HEURE_SUSPECTE_MOINS_QUE
import com.boursorama.utils.Constants.AUDIT_INTERNE_HEURE_SUSPECTE_PLUS_EGAL_QUE
import com.boursorama.utils.Constants.TYPE_FRAUDE_INT_HEURE_SUSPECTE
import com.boursorama.dtl.business.ActionInterneSuspect

object ActionInterneHeureSuspecteDetector extends Serializable {

  @transient lazy val logger = org.apache.log4j.LogManager.getLogger("ActionInterneHeureSuspecteDetector")

  def getFraudeParams(arrayFraude: Array[FraudeParams]): Map[String, String] = {
    val option = getFraudeParams(arrayFraude, TYPE_FRAUDE_INT_HEURE_SUSPECTE)
    option match {
      case None               => Map()
      case Some(fraudeParams) => fraudeParams.param_fraude
    }
  }

  def getFraudeParams(arrayFraude: Array[FraudeParams], fraudeType: String): Option[FraudeParams] = {
    if (arrayFraude != null) {
      arrayFraude.
        find(x =>
          if (x.type_fraude != null && x.type_fraude.equals(fraudeType)) {
            true
          } else {
            false
          })
    } else {
      None
    }
  }

  def suspect(actionInterne: Option[ActionInterne], arrayFraude: Array[FraudeParams]): Option[ActionInterneSuspect] = {
    if (actionInterne != None) {
      var paramsMap = getFraudeParams(arrayFraude)
      val seuilHeureSuspectePlusQue = paramsMap.getOrElse("seuilHeureSuspectePlusQue", AUDIT_INTERNE_HEURE_SUSPECTE_PLUS_EGAL_QUE).toInt
      val seuilHeureSuspecteMoinsQue = paramsMap.getOrElse("seuilHeureSuspecteMoinsQue", AUDIT_INTERNE_HEURE_SUSPECTE_MOINS_QUE).toInt
      val hour = actionInterne.get.timestampJavaDate.getHours()
      if (hour >= seuilHeureSuspectePlusQue || hour < seuilHeureSuspecteMoinsQue) {
        logger.debug(s"     - Action interne suspecte de type (heure suspecte) détectée ! - ${actionInterne.toString}")
        Some(ActionInterneSuspect(
          suspect_client_pep = false,
          suspect_client_employe = false,
          suspect_client_en_cours = false,
          suspect_client_heure = true,
          suspect_client_comex = false,
          Map("type_action" -> TYPE_FRAUDE_INT_HEURE_SUSPECTE, "seuilHeureSuspectePlusQue" -> seuilHeureSuspectePlusQue.toString(),
            "seuilHeureSuspecteMoinsQue" -> seuilHeureSuspecteMoinsQue.toString())))
      } else None
    } else None
  }
}


