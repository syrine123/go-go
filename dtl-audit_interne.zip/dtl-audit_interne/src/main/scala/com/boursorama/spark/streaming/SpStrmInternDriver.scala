package com.boursorama.spark.streaming

import com.boursorama.spark.streaming.kafkastream.KafkaStreamHelper
import org.apache.spark.{ SparkConf, SparkContext }
import org.apache.spark.streaming.{ Seconds, StreamingContext }
import com.boursorama.utils.AppConf._
import org.apache.spark.streaming.dstream.DStream
import com.boursorama.spark.persistance.cassandra.CassandraHelper
import com.boursorama.dtl.business.ActionInterne
import com.boursorama.dtl.business.Rejet
import org.apache.spark.storage.StorageLevel
import com.boursorama.spark.streaming.parser.ActionInterneCisParser
import com.boursorama.spark.streaming.parser.ActionInterneCrmParser
import com.boursorama.spark.streaming.parser.ActionInterneAtosParser
import com.datastax.spark.connector.cql.CassandraConnector
import com.boursorama.dtl.business.FraudeParams
import com.boursorama.dtl.business.PrmRisqueInterneInterne
import org.apache.spark.rdd.RDD

object SpStrmInternDriver extends App {

  val sparkConf = getSparkConf

  var sc = new SparkContext(sparkConf)

  val ssc = new StreamingContext(sc, Seconds(SparkBatchWindow)) // new context

  val dstream: DStream[(String, String)] = KafkaStreamHelper.getInputStream(ssc, Set(KafkaTopicAtos, KafkaTopicCis, KafkaTopicCrm), "intern-group-id") // Get logs stream from Kafka

  val connector = CassandraConnector(ssc.sparkContext.getConf)

  val arrayPrmRisqueInterneInterne: Array[PrmRisqueInterneInterne] = CassandraHelper.getPrmRisqueInterneInterne(ssc)

  val arrayFraude: Array[FraudeParams] = CassandraHelper.getFraudeParams(ssc)

  val actionInternePipeline = new ActionInternePipeline(connector, arrayPrmRisqueInterneInterne, arrayFraude)

  val enrichedActionInterneDStream: DStream[Either[Rejet, Option[ActionInterne]]] = actionInternePipeline.process(dstream)

  enrichedActionInterneDStream.persist(StorageLevel.MEMORY_AND_DISK_SER_2)

  actionInternePipeline.persisteAction(enrichedActionInterneDStream)

  actionInternePipeline.notifySuspect(enrichedActionInterneDStream)

  ssc.start()
  ssc.awaitTermination()

  def getSparkConf: SparkConf = {
    new SparkConf()
      .setAppName("sp-strm-intern")
      .set("spark.cassandra.connection.host", CassandraNodes)
      .set("spark.cassandra.auth.username", CassandraUsername)
      .set("spark.cassandra.auth.password", CassandraPassword)
      .set("spark.cassandra.output.metrics", "false")
      .set("es.nodes", EsNodes)
      .set("es.port", EsPort)
      .set("es.net.ssl.cert.allow.self.signed", "true")
      .set("es.net.ssl", "true")
      .set("es.net.http.auth.user", EsUsername)
      .set("es.net.http.auth.pass", EsPassword)
      .set("es.index.auto.create", "true")
      .set("es.nodes.discovery", "true")
      .set("es.nodes.data.only", "true")
      .set("es.nodes.client.only", "false")
      .set("es.batch.write.refresh", "false")
      //.set("spark.streaming.kafka.maxRatePerPartition", "1000")
      //.set("es.write.operation","upsert")
      .set("spark.streaming.receiver.maxRate", "2000")
      .set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
  }

}
