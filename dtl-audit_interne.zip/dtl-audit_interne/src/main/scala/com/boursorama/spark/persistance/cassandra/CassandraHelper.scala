package com.boursorama.spark.persistance.cassandra

import com.boursorama.dtl.business._
import com.boursorama.dtl.business.cassandra._
import com.boursorama.utils.AppConf._
import com.boursorama.utils.Constants._
import com.boursorama.utils.Conversion._
import com.datastax.driver.core.Row
import com.datastax.spark.connector.cql.CassandraConnector
import com.datastax.spark.connector.streaming.toDStreamFunctions
import com.datastax.spark.connector.toSparkContextFunctions
import org.apache.spark.SparkContext
import org.apache.spark.rdd.RDD
import org.apache.spark.streaming.dstream.DStream
import com.boursorama.dtl.business.PrmRisqueInterneInterne
import com.boursorama.dtl.business.UserInformation
import com.boursorama.dtl.business.FraudeParams
import com.boursorama.dtl.business.ClientContact
import org.apache.spark.streaming.StreamingContext
import com.datastax.spark.connector.streaming._


object CassandraHelper extends Serializable {

  val emptyClient = Client(-1, "", "", -1, -1, 0, "", -1, -1)

  @transient lazy val logger = org.apache.log4j.LogManager.getLogger("CassandraHelper")

  def getPrmRisqueInterneInterne(scc: StreamingContext): Array[PrmRisqueInterneInterne] = {
    scc.cassandraTable[PrmRisqueInterneInterne](CassandraReferentielKeySpace, "prm_risque_interne_action").where("ignore = ?", true).collect
  }

  def getFraudeParams(scc: StreamingContext): Array[FraudeParams] = {
    scc.cassandraTable[FraudeParams](CassandraReferentielKeySpace, "prm_fraude").collect
  }

  def getUtilisateurInformation(login_user: String, login_web_pcc: String, cassandraConnector: CassandraConnector): Option[UserInformation] = {
    logger.debug("getUtilisateurInformation : login_user" + login_user + " : login_web_pcc " + login_web_pcc)
    if (login_user != null && !login_user.isEmpty() && !login_user.equals(EmptyStringField)) {
      cassandraConnector.withSessionDo(
        session =>
          mapUtilisateurInformation(session.execute(
            session.prepare(s"SELECT login_user,login_web_pcc,nom_service_utilisateur,nom_utilisateur,prenom_utilisateur,statut_utilisateur FROM $CassandraReferentielKeySpace.ref_utilisateur WHERE login_user = ?")
              .bind(login_user.toUpperCase)).one))
    } else if (login_web_pcc != null && !login_web_pcc.isEmpty() && !login_web_pcc.equals(EmptyStringField)) {
      cassandraConnector.withSessionDo(
        session =>
          mapUtilisateurInformation(session.execute(
            session.prepare(s"SELECT login_user,login_web_pcc,nom_service_utilisateur,nom_utilisateur,prenom_utilisateur,statut_utilisateur FROM $CassandraReferentielKeySpace.ref_utilisateur WHERE login_web_pcc = ?  and statut_utilisateur = 1 ALLOW FILTERING")
              .bind(login_web_pcc)).one))
    } else {
      None
    }
  }

  def mapUtilisateurInformation(row: Row): Option[UserInformation] = {
    if (row != null) {
      Some(UserInformation(
        row.getString("login_user"),
        row.getString("login_web_pcc"),
        row.getString("nom_service_utilisateur"),
        row.getString("nom_utilisateur"),
        row.getString("prenom_utilisateur"),
        row.getInt("statut_utilisateur")))
    } else {
      None
    }
  }

  def getClientInformation(contactId: Long, cassandraConnector: CassandraConnector): Option[Client] = {
    logger.debug("getClientInformation : contactId " + contactId)
    if (contactId != EmptyLongField) {
      cassandraConnector.withSessionDo(
        session =>
          mapClientInformation(session.execute(
            session.prepare(s"SELECT id_dim_personne,nom,prenom,encours_cash_cav,encours_cash_epargne,flag_employe,segment_sc_libelle,flag_close_to_pep,flag_pep FROM $CassandraReferentielKeySpace.ref_client WHERE id_dim_personne = ?")
              .bind(contactId: java.lang.Long)).one))
    } else {
      None
    }
  }

  def mapClientInformation(row: Row): Option[Client] = {
    if (row != null) {
      Some(Client(
        row.getLong("id_dim_personne"),
        row.getString("nom"),
        row.getString("prenom"),
        row.getDouble("encours_cash_cav"),
        row.getDouble("encours_cash_epargne"),
        row.getInt("flag_employe"),
        row.getString("segment_sc_libelle"),
        row.getInt("flag_close_to_pep"),
        row.getInt("flag_pep")))
    } else {
      None
    }
  }

  def getClientContactInformation(id_web: Long, cassandraConnector: CassandraConnector): Option[ClientContact] = {
    logger.debug("getClientInformation : id_web " + id_web)
    if (id_web != EmptyLongField) {
      cassandraConnector.withSessionDo(
        session =>
          mapClientContactInformation(session.execute(
            session.prepare(s"SELECT id_dim_personne,identifiant_web FROM $CassandraReferentielKeySpace.ref_client_contact WHERE identifiant_web = ? ALLOW FILTERING")
              .bind(id_web: java.lang.Long)).one))
    } else {
      None
    }
  }

  def mapClientContactInformation(row: Row): Option[ClientContact] = {
    if (row != null) {
      Some(ClientContact(
        row.getLong("id_dim_personne"),
        row.getLong("identifiant_web")))
    } else {
      None
    }
  }

//  def persistRejet(actionInterneDStream: DStream[Rejet]) = {
//    actionInterneDStream
//      .saveToCassandra(CassandraAuditDtlKeySpace, "rejet")
//  }

  def persisteActionInterne(actionInterneDStream: DStream[ActionInterne]) = {
    actionInterneDStream
      .map(actionInterne => mapToDto(actionInterne))
      .saveToCassandra(CassandraInternalRiskKeySpace, "action_interne")
  }

  def mapToDto(actionInterne: ActionInterne): ActionInterneCassDto = {

    var suspect_client_pep = false
    var suspect_client_employe = false
    var suspect_client_en_cours = false
    var suspect_client_heure = false
    var param_fraude : Map[String, String] = Map()

    if (actionInterne.suspect != None) {

      suspect_client_pep = actionInterne.suspect.get.suspect_client_pep
      suspect_client_employe = actionInterne.suspect.get.suspect_client_employe
      suspect_client_en_cours = actionInterne.suspect.get.suspect_client_en_cours
      suspect_client_heure = actionInterne.suspect.get.suspect_client_heure
      param_fraude = actionInterne.suspect.get.param_fraude
    }

    new ActionInterneCassDto(
      actionInterne.sys_origine,
      actionInterne.annee_mois,
      actionInterne.id_dim_temps,
      actionInterne.timestamp,
      actionInterne.login_user,
      actionInterne.login_web_pcc,
      actionInterne.code_operation,
      actionInterne.libelle_operation,
      actionInterne.code_sous_operation,
      actionInterne.libelle_sous_operation,
      actionInterne.adresse_ip,
      NoneToLong(actionInterne.contact_id),
      NoneToLong(actionInterne.id_web),
      actionInterne.id_compte,
      actionInterne.session_id,
      actionInterne.client.getOrElse(emptyClient).encours_cash_cav + actionInterne.client.getOrElse(emptyClient).encours_cash_epargne,
      suspect_client_pep,
      suspect_client_employe,
      suspect_client_en_cours,
      suspect_client_heure,
      param_fraude)
  }

}
