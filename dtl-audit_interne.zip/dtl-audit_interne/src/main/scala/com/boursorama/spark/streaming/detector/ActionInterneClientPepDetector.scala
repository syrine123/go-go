package com.boursorama.spark.streaming.detector

import com.boursorama.dtl.business.ActionInterne
import com.boursorama.dtl.business.FraudeParams
import com.boursorama.utils.Constants.TYPE_FRAUDE_INT_CLIENT_PEP
import com.boursorama.dtl.business.ActionInterneSuspect

object ActionInterneClientPepDetector extends Serializable {

  @transient lazy val logger = org.apache.log4j.LogManager.getLogger("ActionInterneClientPepDetector")

  def suspect(actionInterne: Option[ActionInterne], arrayFraude: Array[FraudeParams]): Option[ActionInterneSuspect] = {
    if (actionInterne != None && actionInterne.get.client != None && (1.equals(actionInterne.get.client.get.flag_pep) || 1.equals(actionInterne.get.client.get.flag_close_to_pep))) {
      logger.debug(s"     - Action interne suspecte de type (consultation client PEP) détectée ! - ${actionInterne.toString}")
      Some(ActionInterneSuspect(
        suspect_client_pep = true,
        suspect_client_employe = false,
        suspect_client_en_cours = false,
        suspect_client_heure = false,
        suspect_client_comex = false,
        Map("type_action" -> TYPE_FRAUDE_INT_CLIENT_PEP, "flag_pep" -> "1")))
    } else None
  }
}

