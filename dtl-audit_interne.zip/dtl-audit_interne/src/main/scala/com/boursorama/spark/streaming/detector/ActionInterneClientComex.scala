package com.boursorama.spark.streaming.detector

import com.boursorama.dtl.business._
import com.boursorama.utils.Constants._

object ActionInterneClientComex extends Serializable {

  @transient lazy val logger = org.apache.log4j.LogManager.getLogger("ActionInterneClientComex")

  def getFraudeParams(arrayFraude: Array[FraudeParams], fraudeType: String): Option[FraudeParams] = {
    if (arrayFraude != null) {
      arrayFraude.
        find(x =>
          if (x.type_fraude != null && x.type_fraude.equals(fraudeType)) {
            true
          } else {
            false
          })
    } else {
      None
    }
  }

  def getFraudeParams(arrayFraude: Array[FraudeParams]): Map[String, String] = {
    val option = getFraudeParams(arrayFraude, TYPE_FRAUDE_INT_CLIENT_COMEX)
    option match {
      case None               => Map()
      case Some(fraudeParams) => fraudeParams.param_fraude
    }
  }

  def suspect(actionInterne: Option[ActionInterne], arrayFraude: Array[FraudeParams]): Option[ActionInterneSuspect] = {
    val paramsMap = getFraudeParams(arrayFraude)
    val comexList = paramsMap.getOrElse("comexList", AUDIT_INTERNE_LISTE_COMEX)
    if (actionInterne.get.client.isDefined && comexList.split(",").contains(actionInterne.get.contact_id.get.toString)) {
      logger.debug(s"     - Action interne suspecte de type (consultation client comex) détectée ! - ${actionInterne.toString}")
      Some(ActionInterneSuspect(
        suspect_client_pep = false,
        suspect_client_employe = false,
        suspect_client_en_cours = false,
        suspect_client_heure = false,
        suspect_client_comex = true,
        Map("type_action" -> TYPE_FRAUDE_INT_CLIENT_COMEX, "liste_comex" -> comexList)))
      } else None
  }
}

