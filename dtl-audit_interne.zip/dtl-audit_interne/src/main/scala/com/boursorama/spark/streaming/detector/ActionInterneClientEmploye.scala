package com.boursorama.spark.streaming.detector

import com.boursorama.dtl.business._
import com.boursorama.utils.Constants._

object ActionInterneClientEmploye extends Serializable {

  @transient lazy val logger = org.apache.log4j.LogManager.getLogger("ActionInterneClientEmploye")

  def suspect(actionInterne: Option[ActionInterne], arrayFraude: Array[FraudeParams]): Option[ActionInterneSuspect] = {
    if (actionInterne.get.client.isDefined && actionInterne.get.client.get.flag_employe == 1) {
      logger.debug(s"     - Action interne suspecte de type (consultation client employe) détectée ! - ${actionInterne.toString}")
      Some(ActionInterneSuspect(
        suspect_client_pep = false,
        suspect_client_employe = true,
        suspect_client_en_cours = false,
        suspect_client_heure = false,
        suspect_client_comex = false,
        Map("type_action" -> TYPE_FRAUDE_INT_CLIENT_EMPLOYE, "flag_employe" -> "1")))
      } else None
  }
}

