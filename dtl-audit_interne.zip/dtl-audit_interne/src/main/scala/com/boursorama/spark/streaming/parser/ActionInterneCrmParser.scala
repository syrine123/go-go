package com.boursorama.spark.streaming.parser

import com.boursorama.dtl.business.{ActionInterne, PrmRisqueInterneInterne, Rejet}
import com.boursorama.utils.Constants.{EmptyStringField, FluxCrm}
import com.boursorama.utils.Conversion.{getYearMonth, getYearMonthDay}
import org.joda.time.DateTime
import org.json4s.JsonAST.JValue
import org.json4s.jackson.JsonMethods.parse
import org.json4s.{DefaultFormats, jvalue2extractable, jvalue2monadic, string2JsonInput}

import scala.util.{Failure, Success, Try}
import scala.util.control.Breaks.{break, breakable}

object ActionInterneCrmParser extends ActionInterneParser[Either[Rejet, Option[ActionInterne]]] {

  @transient lazy val logger = org.apache.log4j.LogManager.getLogger("ActionInterneCrmParser")

  def cleanActionLineCrm(line: String): String = {
    var new_line = line
    val idx_start_method_http = line.indexOf("[")
    if (idx_start_method_http >= 0) {
      new_line = new_line.substring(0, idx_start_method_http)
    }

    new_line match {
      case s if s.lastIndexOf("=") >= 0 => s.substring(s.lastIndexOf("=") + 1)
      case s if s.lastIndexOf("/") >= 0 => s.split("/").last
      case _                            => line
    }
  }

  def getClientIdCrm(json: JValue): Option[Long] = {

    implicit val formats = DefaultFormats
    val client_id_fields = Vector("contactID", "contactId", "idPersonnePhysique", "id", "idPersPhys")
    var converted_id: Option[Long] = None

    breakable {
      for (client_id_field <- client_id_fields) {
        val id = (json \ client_id_field).extractOpt[String].getOrElse("")
        if (id.length() > 0) {
          converted_id = Try(id.trim.toLong) match {
            case Success(v) => Some(v)
            case Failure(v) => None
          }
          if (converted_id != None) {
            break()
          }
        }
      }
    }
    converted_id
  }

  override def parseLine(logLine: String, arrayPrmRisqueInterneInterne: Array[PrmRisqueInterneInterne]): Either[Rejet, Option[ActionInterne]] = {

    try {
      implicit val formats = DefaultFormats
      val json = parse(logLine)
      val rawTimestamp = (json \ "@timestamp").extractOpt[String].getOrElse(EmptyStringField)
      val timestamp = DateTime.parse(rawTimestamp)
      val anneeMois = getYearMonth(timestamp)
      val idDimTemps = getYearMonthDay(timestamp)
      val userLogin = (json \ "login").extractOpt[String].getOrElse(EmptyStringField).toUpperCase
      val codeOperation = EmptyStringField
      val libelleOperation = cleanActionLineCrm((json \ "service").extractOpt[String].getOrElse(EmptyStringField))
      val codeSousOperation = EmptyStringField
      val libelleSousOperation = EmptyStringField
      val adresseIp = (json \ "remoteIP").extractOpt[String].getOrElse(EmptyStringField)
      val contact_id = getClientIdCrm(json)
      val compteId = (json \ "numeroCompteRIB").extractOpt[String].getOrElse(EmptyStringField)
      val sessionId = (json \ "sessionID").extractOpt[String].getOrElse(EmptyStringField)

      if (isIgnoredAction(libelleOperation, FluxCrm, arrayPrmRisqueInterneInterne)) {
        Right(None)
      } else {
        Right(Some(ActionInterne(
          FluxCrm,
          anneeMois,
          idDimTemps,
          timestamp,
          userLogin,
          null,
          codeOperation,
          libelleOperation,
          codeSousOperation,
          libelleSousOperation,
          adresseIp,
          contact_id,
          None,
          None,
          compteId,
          EmptyStringField,
          EmptyStringField,
          EmptyStringField,
          sessionId,
          logLine,
          timestamp.toDate(),
          None)))
      }
    } catch {
      case e: Exception => {
        //        Left(
        //        Rejet(
        //          logLine,
        //          "ActionInterneAtosParser",
        //          FluxCrm,
        //          DateTime.now(),
        //          1,
        //          "PARSE ERROR",
        //          e.toString + " => " + e.getStackTrace.mkString("||"),
        //          ""))
        logger.error(logLine, e)
        Left(null)
      }
    }
  }
}
