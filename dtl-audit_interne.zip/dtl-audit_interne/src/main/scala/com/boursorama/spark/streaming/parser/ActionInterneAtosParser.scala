package com.boursorama.spark.streaming.parser

import org.joda.time.DateTime
import org.json4s.DefaultFormats
import org.json4s.jackson.JsonMethods.parse

import com.boursorama.dtl.business._
import com.boursorama.utils.Constants._
import com.boursorama.utils.Conversion._

import scala.util.{ Failure, Success, Try }
import com.datastax.spark.connector.cql.CassandraConnector

object ActionInterneAtosParser extends ActionInterneParser[ActionInterne] {

  @transient lazy val logger = org.apache.log4j.LogManager.getLogger("ActionInterneAtosParser")

  override def parseLine(logLine: String, arrayPrmRisqueInterneInterne: Array[PrmRisqueInterneInterne]): Either[Rejet, Option[ActionInterne]] = {

    try {
      implicit val formats = DefaultFormats
      val json = parse(logLine)

      val clientId = isLong((json \ "UserID").extractOpt[String].getOrElse(EmptyStringField)) // null
      val managerId = (json \ "ManagerID").extractOpt[String].getOrElse(EmptyStringField) // Can be the user or the client

      if (clientId != None && isLong(managerId) != None && NoneToLong(clientId).toString() != managerId) {

        val rawTimestamp = (json \ "@timestamp").extractOpt[String].getOrElse("-")
        val timestamp = DateTime.parse(rawTimestamp)
        val anneeMois = getYearMonth(timestamp)
        val idDimTemps = getYearMonthDay(timestamp)
        val codeOperation = EmptyStringField
        val libelleOperation = cleanActionLineAtos((json \ "Information").extractOpt[String].getOrElse(EmptyStringField))
        val codeSousOperation = EmptyStringField
        val libelleSousOperation = EmptyStringField
        val adresseIp = (json \ "IP Adress").extractOpt[String].getOrElse(EmptyStringField)
        val sessionId = (json \ "sessionID").extractOpt[String].getOrElse(EmptyStringField)

        if (isIgnoredAction(libelleOperation, FluxAtos, arrayPrmRisqueInterneInterne)) {
          Right(None)
        } else {
          Right(Some(ActionInterne(
            FluxAtos,
            anneeMois,
            idDimTemps,
            timestamp,
            null,
            managerId,
            codeOperation,
            libelleOperation,
            codeSousOperation,
            libelleSousOperation,
            adresseIp,
            None,
            clientId,
            None,
            EmptyStringField,
            EmptyStringField,
            EmptyStringField,
            EmptyStringField,
            sessionId,
            logLine,
            timestamp.toDate(),
            None)))
        }
      } else {
        Right(None)
      }
    } catch {
      case e: Exception =>
        {
          //       Left(
          //        Rejet(
          //          logLine,
          //          "ActionInterneAtosParser",
          //          FluxAtos,
          //          DateTime.now(),
          //          1,
          //          "PARSE ERROR",
          //          e.toString + " => " + e.getStackTrace.mkString("||"),
          //          ""))
          logger.error(logLine, e)
          Left(null)
        }
    }
  }

  def cleanActionLineAtos(line: String): String = line match {
    case s if s.length() > 0 => line
    case _                   => "-"
  }

  def isLong(line: String): Option[Long] = {
    Try(line.toLong) match {
      case Success(v) => Some(v)
      case Failure(v) => None
    }
  }
}

