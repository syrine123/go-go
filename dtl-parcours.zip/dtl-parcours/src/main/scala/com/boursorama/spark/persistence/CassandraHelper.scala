package com.boursorama.spark.persistence

import com.boursorama.business._
import com.boursorama.utils.AppConf.{CassandraAuditDtlKeySpace, CassandraParcoursKeySpace}
import com.datastax.spark.connector.SomeColumns
import com.datastax.spark.connector.streaming.toDStreamFunctions
import org.apache.spark.streaming.dstream.DStream
/**
  * Created by fares on 10/05/17.
  */

object CassandraHelper {

  def persistServicesAndRejects(serviceDStream: DStream[Either[Rejet,Service]]): Unit = {
    serviceDStream
      .filter(_.isLeft)
      .map(_.left.get)
      .saveToCassandra(CassandraAuditDtlKeySpace, "rejet")
    persistServices(serviceDStream.filter(_.isRight).map(_.right.get))
  }

  /*
  def persist[T](serviceDStream: DStream[T])(implicit tag: TypeTag[T]): Unit = serviceDStream match {
    case _ :DStream[CreerFicheProspectDto] =>  persistCreerFicheProspect _
    case _ :DStream[AmendContactInformationDto] => persistAmendContactInformation _
    case _ :DStream[AjouterCbDto] => persistAjouterCb _
    case _ :DStream[LinkFilleulParrainDto] => persistLinkFilleulParrain _
  }
*/
  def persistCreerFicheProspect(creerFicheProspectDStream: DStream[CreerFicheProspectDto]): Unit = {
    creerFicheProspectDStream.saveToCassandra(
      CassandraParcoursKeySpace,
      "referentiel_prospects",
      // Choosing columns to update when inserting into Cassandra
      SomeColumns(
        "contactid",
        "mailing_accord",
        "service",
        "campaign",
        "civilite",
        "code_postal",
        "country_connexion_name",
        "date_naissance",
        "mail",
        "pays",
        "timestamp",
        "campagne",
        "id_dim_temps",
        "annee_mois"))
  }

  def persistAmendContactInformation(amendContactInformationDstream: DStream[AmendContactInformationDto]): Unit = {
    amendContactInformationDstream.saveToCassandra(
      CassandraParcoursKeySpace,
      "referentiel_prospects",
      // Choosing columns to update when inserting into Cassandra
      SomeColumns(
        "contactid",
        "csp",
        "service",
        "timestamp",
        "flag_epargne",
        "patrimoine",
        "revenus_annuels",
        "regime_matrimonial",
        "flag_banque_principale",
        "annee_mois",
        "code_postal_naissance",
        "pays_naissance"))
  }

    def persistSfolCreateBankCard(SfolCreateBankCardDstream: DStream[SfolCreateBankCardDto]): Unit = {
      SfolCreateBankCardDstream.saveToCassandra(
      CassandraParcoursKeySpace,
      "referentiel_prospects",
      // Choosing columns to update when inserting into Cassandra
      SomeColumns(
      "contactid",
      "debit_cb",
      "nature_cb",
      "timestamp",
      "service",
      "id_dim_temps",
      "annee_mois"))
  }

  def persistLinkFilleulParrain(linkFilleulParrainDstream: DStream[LinkFilleulParrainDto]): Unit = {
    linkFilleulParrainDstream.saveToCassandra(CassandraParcoursKeySpace,"referentiel_prospects",SomeColumns(
      "contactid",
      "firstnamesponsor",
      "namesponsor",
      "timestamp",
      "service",
      "id_dim_temps",
      "annee_mois"))
  }

  def persistInitialCustomerValidation(InitialCustomerValidationDstream: DStream[InitialCustomerValidationDto]): Unit = {
    InitialCustomerValidationDstream.saveToCassandra(CassandraParcoursKeySpace,"referentiel_prospects",SomeColumns(
      "contactid",
      "code_offre",
      "timestamp",
      "service",
      "annee_mois"))
  }

  def persistSfolAddSavingAccount(SfolAddSavingAccountDstream: DStream[SfolAddSavingAccountDto]): Unit = {
    SfolAddSavingAccountDstream.saveToCassandra(CassandraParcoursKeySpace,"referentiel_prospects",SomeColumns(
      "contactid",
      "csl_flag",
      "timestamp",
      "service",
      "annee_mois"))
  }

  def persistAccountInsuranceSubscribeSfol(AccountInsuranceSubscribeSfolDstream: DStream[AccountInsuranceSubscribeSfolDto]): Unit = {
    AccountInsuranceSubscribeSfolDstream.saveToCassandra(CassandraParcoursKeySpace,"referentiel_prospects",SomeColumns(
      "contactid",
      "prevoyance_flag",
      "timestamp",
      "service",
      "annee_mois"))
  }

  def persistServices(serviceDStream: DStream[Service]): Unit = {
    persistCreerFicheProspect(serviceDStream.filter(_.isInstanceOf[CreerFicheProspectDto]).asInstanceOf[DStream[CreerFicheProspectDto]])
    persistAmendContactInformation(serviceDStream.filter(_.isInstanceOf[AmendContactInformationDto]).asInstanceOf[DStream[AmendContactInformationDto]])
    persistSfolCreateBankCard(serviceDStream.filter(_.isInstanceOf[SfolCreateBankCardDto]).asInstanceOf[DStream[SfolCreateBankCardDto]])
    persistLinkFilleulParrain(serviceDStream.filter(_.isInstanceOf[LinkFilleulParrainDto]).asInstanceOf[DStream[LinkFilleulParrainDto]])
    persistInitialCustomerValidation(serviceDStream.filter(_.isInstanceOf[InitialCustomerValidationDto]).asInstanceOf[DStream[InitialCustomerValidationDto]])
    persistAccountInsuranceSubscribeSfol(serviceDStream.filter(_.isInstanceOf[AccountInsuranceSubscribeSfolDto]).asInstanceOf[DStream[AccountInsuranceSubscribeSfolDto]])
    persistSfolAddSavingAccount(serviceDStream.filter(_.isInstanceOf[SfolAddSavingAccountDto]).asInstanceOf[DStream[SfolAddSavingAccountDto]])
  }

}
