package com.boursorama.spark.streaming.parser

import com.boursorama.business._
import com.boursorama.utils.Codes
import com.boursorama.utils.Conversion.{getYearMonthDay, _}
import com.boursorama.utils.Constants._
import org.joda.time.DateTime
import org.json4s.DefaultFormats
import org.json4s.jackson.JsonMethods._

class ProspectServicesParser {

   @transient lazy val logger = org.apache.log4j.LogManager.getLogger("ProspectServicesParser")

   def parseService(logLine: String): Either[Rejet, Service] = {

     try {
       implicit val formats = DefaultFormats

       val json = parse(logLine)
       val service = (json \ "Service").extractOpt[String].getOrElse("")
       service match {
         case ServiceCreateProspect => parseCreerFicheProspect(logLine)
         case ServiceLinkParrain => parseLinkFilleulParrain(logLine)
         case ServiceAmendContactInformation => parseAmendContactInformation(logLine)
         case ServiceCreateBankCard => parseSfolCreateBankCard(logLine)
         case ServiceInitialCustomerValidation => parseInitialCustomerValidation(logLine)
         case ServiceSfolAddSavingAccount => parseSfolAddSavingAccountDto(logLine)
         case ServiceAccountInsuranceSubscribeSfol => parseAccountInsuranceSubscribeSfol(logLine)
       }
     }  catch {

       case e: Exception => Right(
        null
       )
     }
     }

   def parseCreerFicheProspect(logLine: String): Either[Rejet, CreerFicheProspectDto] = {
    try {
      implicit val formats = DefaultFormats

      val json = parse(logLine)
      val service = (json \ "Service").extractOpt[String].getOrElse("")
        val timestamp = (json \ "timestamp").extractOpt[String].getOrElse("")
        //val rawTimestamp = (json \ "@timestamp").extractOpt[String].getOrElse("")
        //val timestamp = DateTime.parse(rawTimestamp)
        //val anneeMois = getYearMonth(timestamp)
        val contactId = (json \ "ContactID").extractOpt[String].getOrElse("1")
        val connectionCountryName = ((json \\ "geoip") \ "country_name").extractOpt[String].getOrElse("")
        val ip = ((json \\ "geoip") \ "ip").extractOpt[String].getOrElse("")
        val login = (json \ "Login").extractOpt[String].getOrElse("")
        val errorMessage = (json \ "Message_Erreur").extractOpt[String].getOrElse("").replace("'", " ")
        val civility = (json \ "Civilite").extractOpt[String].getOrElse("")
        val lastName = (json \ "Nom").extractOpt[String].getOrElse("").replace("'", " ")
        val firstName = (json \ "Prenom").extractOpt[String].getOrElse("").replace("'", " ")
        val adresseLigne1 = (json \ "Adresse_ligne_1").extractOpt[String].getOrElse("").replace("'", " ")
        val postalCode = (json \ "Code_postal").extractOpt[String].getOrElse("")
        val city = (json \ "Ville").extractOpt[String].getOrElse("")
        val country = (json \ "Pays").extractOpt[String].getOrElse("")
        val phoneFixe = (json \ "phone_fixe").extractOpt[String].getOrElse("")
        val phoneMobile = (json \ "phone_mobile").extractOpt[String].getOrElse("")
        val mail = (json \ "Mail").extractOpt[String].getOrElse("").replace("'", " ")
        val birthDate = (json \ "Date_Naissance").extractOpt[String].getOrElse("")
        val sourceUrl = (json \ "Source_URL").extractOpt[String].getOrElse(DefaultInt)
        val accordMailing = (json \ "Accord_Mailing").extractOpt[String].getOrElse("")
        val codeTypeDemandeWeb = (json \ "Code_Type_Demande_Web").extractOpt[String].getOrElse("")
        val ipAdress = (json \ "IP").extractOpt[String].getOrElse("")
        val dedoublonnage = (json \ "Dedoublonnage").extractOpt[String].getOrElse("")
        val campagne = toLabel(sourceUrl, Codes.codesCampagneMap)

        Right(
          CreerFicheProspectDto(
            service,
            contactId,
            accordMailing,
            campagne,
            civility,
            postalCode,
            connectionCountryName,
            birthDate,
            mail,
            ipAdress,
            //lastName,
            country,
            phoneFixe,
            phoneMobile,
            firstName,
            timestamp,
            codeTypeDemandeWeb,
            sourceUrl,
            city,
            adresseLigne1,
            getYearMonth(DateTime.parse(timestamp)),
            getYearMonthDay(timestamp)
          )
        )
    } catch {
      case e: Exception => /*Left(
        Rejet(
        logLine,
        ServiceCreateProspect,
        sysOrigine,
        DateTime.now(),
        0,
        //TODO : declare constant value
        "PARSE ERROR",
        e.toString + " => " + e.getStackTrace.mkString("||"),
        ""
      )
      )*/
        logger.error(logLine, e)
        Left(null)
    }
  }

  def parseAmendContactInformation(logLine: String): Either[Rejet, AmendContactInformationDto] = {
    try {
      implicit val formats = DefaultFormats

      val json = parse(logLine)
      val service = (json \ "Service").extractOpt[String].getOrElse("")
      val timestamp = (json \ "timestamp").extractOpt[String].getOrElse("")
      val contactId = (json \ "ContactID").extractOpt[String].getOrElse("1")
      val connectionCountryName = ((json \\ "geoip") \ "country_name").extractOpt[String].getOrElse("")
      val ip = ((json \\ "geoip") \ "ip").extractOpt[String].getOrElse("")
      val login = (json \ "Login").extractOpt[String].getOrElse("")
      val errorMessage = (json \ "Message_Erreur").extractOpt[String].getOrElse("").replace("'", " ")
      val civility = (json \ "Civilite").extractOpt[String].getOrElse("")
      val lastName = (json \ "Nom").extractOpt[String].getOrElse("").replace("'", " ")
      val firstName = (json \ "Prenom").extractOpt[String].getOrElse("").replace("'", " ")
      val ipAdress = (json \ "IP").extractOpt[String].getOrElse("")
      val csp = (json \ "csp").extractOpt[String].getOrElse(DefaultInt)
      val revenus = (json \ "revenus").extractOpt[String].getOrElse(DefaultInt)
      val flagEpargne = (json \ "flag_epargne").extractOpt[String].getOrElse("")
      val flagBanquePrincipale = (json \ "flag_banque_principale").extractOpt[String].getOrElse(DefaultInt)
      val patrimoine = (json \ "patrimoine").extractOpt[String].getOrElse(DefaultInt)
      val maritalSituation = (json \ "situation_maritale").extractOpt[String].getOrElse(DefaultInt)
      val birthCountry = (json \ "pays_naissance").extractOpt[String].getOrElse("")
      val birthPostalCode = (json \ "code_postal_naissance").extractOpt[String].getOrElse("")
      val cspLabel = toLabel(csp, Codes.codesCspMap)
      val patrimoineLabel = toLabel(patrimoine, Codes.codesPatrimoineMap)
      val revenusLabel = toLabel(revenus, Codes.codesRevenusMap)

        Right(
        AmendContactInformationDto(
          service,
          contactId,
          civility,
          connectionCountryName,
          csp,
          flagEpargne,
          ipAdress,
          patrimoine,
          firstName,
          lastName,
          timestamp,
          revenus,
          maritalSituation,
          flagBanquePrincipale,
          cspLabel,
          patrimoineLabel,
          revenusLabel,
          getYearMonth(DateTime.parse(timestamp)),
          birthPostalCode,
          birthCountry
        )
      )
     } catch {
      case e: Exception => /*Left(
        Rejet(
          logLine,
          ServiceAmendContactInformation,
          sysOrigine,
          DateTime.now(),
          0,
          "PARSE ERROR",
          e.toString + " => " + e.getStackTrace.mkString("||"),
          ""
        )
      )*/
        logger.error(logLine, e)
        Left(null)
    }
  }

  def parseLinkFilleulParrain(logLine: String): Either[Rejet, LinkFilleulParrainDto] = {
    try {
      implicit val formats = DefaultFormats

      val json = parse(logLine)
      val service = (json \ "Service").extractOpt[String].getOrElse("")
      val timestamp = (json \ "timestamp").extractOpt[String].getOrElse("")
      val contactId = (json \ "ContactID").extractOpt[String].getOrElse("1")
      val sponsorLastName = (json \ "nameSponsor").extractOpt[String].getOrElse("")
      val sponsorFirstName = (json \ "firstNameSponsor").extractOpt[String].getOrElse("")

        Right(
          LinkFilleulParrainDto(
            service,
            contactId,
            sponsorFirstName,
            sponsorLastName,
            timestamp,
            getYearMonth(DateTime.parse(timestamp)),
            getYearMonthDay(timestamp)
          )
        )
    } catch {
      case e: Exception => /*Left(
        Rejet(
          logLine,
          ServiceLinkParrain,
          sysOrigine,
          DateTime.now(),
          0,
          "PARSE ERROR",
          e.toString + " => " + e.getStackTrace.mkString("||"),
          ""
        )
      )*/
        logger.error(logLine, e)
        Left(null)
    }
  }

  def parseSfolCreateBankCard(logLine: String): Either[Rejet, SfolCreateBankCardDto] = {
    try {
      implicit val formats = DefaultFormats

      val json = parse(logLine)
      val service = (json \ "Service").extractOpt[String].getOrElse("")

      val timestamp = (json \ "timestamp").extractOpt[String].getOrElse("")
      val contactId = (json \ "ContactID").extractOpt[String].getOrElse("1")
      val natureCb = (json \ "Nature").extractOpt[String].getOrElse(DefaultInt)
      val debitCb = (json \ "Debit").extractOpt[String].getOrElse("") match {
        case "false" => "0"
        case "true" => "1"
        case _ => DefaultInt
      }
      val debitCbLabel = toLabel(debitCb, Codes.codesTypeRetraitCbMap)
      val natureCbLabel = toLabel(natureCb, Codes.codesNatureCbMap)

        Right(
          SfolCreateBankCardDto(
            service,
            contactId,
            debitCb,
            natureCb,
            timestamp,
            natureCbLabel,
            debitCbLabel,
            getYearMonth(DateTime.parse(timestamp)),
            getYearMonthDay(timestamp)
          )
        )
    } catch {
      case e: Exception => /*Left(
        Rejet(
          logLine,
          ServiceCreateBankCard,
          sysOrigine,
          DateTime.now(),
          0,
          "PARSE ERROR",
          e.toString + " => " + e.getStackTrace.mkString("||"),
          ""
        )
      )*/
        logger.error(logLine, e)
        Left(null)
    }
  }

  def parseInitialCustomerValidation(logLine: String): Either[Rejet, InitialCustomerValidationDto] = {
    try {
      implicit val formats = DefaultFormats

      val json = parse(logLine)
      val service = (json \ "Service").extractOpt[String].getOrElse("")

      val timestamp = (json \ "timestamp").extractOpt[String].getOrElse("")
      val contactId = (json \ "ContactID").extractOpt[String].getOrElse("1")
      val offerCode = (json \ "Code_Offre").extractOpt[String].getOrElse("")

      Right(
        InitialCustomerValidationDto(
          service,
          contactId,
          getYearMonth(DateTime.parse(timestamp)),
          timestamp,
          offerCode
        )
      )
    } catch {
      case e: Exception => /*Left(
        Rejet(
          logLine,
          ServiceCreateBankCard,
          sysOrigine,
          DateTime.now(),
          0,
          "PARSE ERROR",
          e.toString + " => " + e.getStackTrace.mkString("||"),
          ""
        )
      )*/
        logger.error(logLine, e)
        Left(null)
    }
  }

  def parseAccountInsuranceSubscribeSfol(logLine: String): Either[Rejet, AccountInsuranceSubscribeSfolDto] = {
    try {
      implicit val formats = DefaultFormats

      val json = parse(logLine)
      val service = (json \ "Service").extractOpt[String].getOrElse("")

      val timestamp = (json \ "timestamp").extractOpt[String].getOrElse("")
      val contactId = (json \ "ContactID").extractOpt[String].getOrElse("1")

      Right(
        AccountInsuranceSubscribeSfolDto(
          service,
          contactId,
          getYearMonth(DateTime.parse(timestamp)),
          timestamp,
          1
        )
      )
    } catch {
      case e: Exception => /*Left(
        Rejet(
          logLine,
          ServiceCreateBankCard,
          sysOrigine,
          DateTime.now(),
          0,
          "PARSE ERROR",
          e.toString + " => " + e.getStackTrace.mkString("||"),
          ""
        )
      )*/
        logger.error(logLine, e)
        Left(null)
    }
  }

  def parseSfolAddSavingAccountDto(logLine: String): Either[Rejet, SfolAddSavingAccountDto] = {
    try {
      implicit val formats = DefaultFormats

      val json = parse(logLine)
      val service = (json \ "Service").extractOpt[String].getOrElse("")

      val timestamp = (json \ "timestamp").extractOpt[String].getOrElse("")
      val contactId = (json \ "ContactID").extractOpt[String].getOrElse("1")

      Right(
        SfolAddSavingAccountDto(
          service,
          contactId,
          getYearMonth(DateTime.parse(timestamp)),
          timestamp,
          1
        )
      )
    } catch {
      case e: Exception => /*Left(
        Rejet(
          logLine,
          ServiceCreateBankCard,
          sysOrigine,
          DateTime.now(),
          0,
          "PARSE ERROR",
          e.toString + " => " + e.getStackTrace.mkString("||"),
          ""
        )
      )*/
        logger.error(logLine, e)
        Left(null)
    }
  }
  }

object ProspectServicesParser extends ProspectServicesParser


