package com.boursorama.spark.streaming

import com.boursorama.spark.streaming.kafkastream.KafkaStreamHelper
import org.apache.spark.{SparkConf, SparkContext}
import org.apache.spark.streaming.{Seconds, StreamingContext}
import com.boursorama.utils.AppConf._
import org.apache.spark.streaming.dstream.DStream

object MainDriver extends App {

   val sparkConf = getSparkConf
   var sc = new SparkContext(sparkConf)
   val ssc = new StreamingContext(sc, Seconds(SparkBatchWindow)) // new context

   val webServiceDStream: DStream[String] = KafkaStreamHelper.getInputStream(ssc) // Get logs stream from Kafka

   ProspectPipeline.process(webServiceDStream) // get logs stream from kafka and process it

   ssc.start()
   ssc.awaitTermination()

   def getSparkConf: SparkConf = {
    new SparkConf()
      .setAppName(AppName)
      .set("spark.cassandra.connection.host", CassandraNodes)
      .set("spark.cassandra.auth.username", CassandraUsername)
      .set("spark.cassandra.auth.password", CassandraPassword)
      .set("es.nodes", EsNodes)
      .set("es.port", EsPort)
      .set("es.net.ssl.cert.allow.self.signed", "true")
      .set("es.net.ssl", "true")
      .set("es.net.http.auth.user", EsUsername)
      .set("es.net.http.auth.pass", EsPassword)
      .set("es.index.auto.create", "true")
      .set("es.nodes.discovery", "true")
      .set("es.batch.write.refresh", "false")
      //.set("es.nodes.data.only", "true")
      //.set("es.nodes.client.only", "false")
      .set("spark.streaming.kafka.maxRatePerPartition", "1000")
      .set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
      .set("es.update.retry.on.conflict", "5")
      //.set("es.write.operation","upsert")
  }

}
