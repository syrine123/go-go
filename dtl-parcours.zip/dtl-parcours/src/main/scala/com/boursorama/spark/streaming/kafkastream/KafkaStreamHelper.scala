package com.boursorama.spark.streaming.kafkastream

import org.apache.spark.streaming.StreamingContext
import org.apache.spark.streaming.dstream.DStream
import org.apache.spark.streaming.kafka.KafkaUtils
import kafka.serializer.StringDecoder
import com.boursorama.utils.AppConf._
import org.apache.spark.storage.StorageLevel

class KafkaStreamHelper extends Serializable {

  @transient lazy val logger = org.apache.log4j.LogManager.getLogger("KafkaStreamHelper")

  def getInputStream(ssc: StreamingContext): DStream[String] = {

    val CONSUMER_THREADS_PER_INPUT_DSTREAM = 8
    val topicMap = Map[String, Int](KafkaTopicWebServices -> CONSUMER_THREADS_PER_INPUT_DSTREAM)

    val kafkaParams = Map[String, String](
      "group.id" -> GroupId,
      "auto.offset.reset" -> "largest",
      "zookeeper.connect" -> zkQuorum,
      "zookeeper.connection.timeout.ms" -> "10000")

    KafkaUtils.createStream[String, String, StringDecoder, StringDecoder](ssc, kafkaParams, topicMap, StorageLevel.MEMORY_AND_DISK_SER_2)
      .map(_._2)
  }
}

object KafkaStreamHelper extends KafkaStreamHelper