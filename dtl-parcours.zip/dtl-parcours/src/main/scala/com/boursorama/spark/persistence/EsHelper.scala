package com.boursorama.spark.persistence

import com.boursorama.business._
import org.apache.spark.streaming.dstream.DStream
import org.elasticsearch.spark.streaming._

/**
  * Created by fares on 10/05/17.
  */

object EsHelper {

  def getValorisationProspectIndexName: String = "idx-valorisation-prospect-{anneeMois}/valorisation-prospect"

  def persistServices(serviceDStream: DStream[Either[Rejet,Service]]): Unit = {
    serviceDStream
      .filter(_.isRight)
      .map(_.right.get)
      .filter(_ != null)
      .saveToEs(getValorisationProspectIndexName, Map("es.mapping.id" -> "contactid", "es.write.operation" -> "upsert"))
  }
}
