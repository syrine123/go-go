package com.boursorama.spark.streaming

import com.boursorama.business._
import com.boursorama.spark.persistence.CassandraHelper
import com.boursorama.spark.persistence.EsHelper
import com.boursorama.spark.streaming.parser.ProspectServicesParser
import org.apache.spark.streaming.dstream.DStream

object ProspectPipeline {

  def process(rawStream : DStream[String]): Unit = {
    persistServices(parseServiceDStream(rawStream))
  }

  /*
   Parsing
   */

  def parseServiceDStream(logDStream: DStream[String]): DStream[Either[Rejet, Service]] = {
    logDStream.map(log => ProspectServicesParser.parseService(log))
  }

    /*
  Enriching
   */


  /*
  Detecting
   */


  /*
  Persisting
   */

  def persistServices(serviceDStream: DStream[Either[Rejet, Service]]): Unit = {
    EsHelper.persistServices(serviceDStream)
    CassandraHelper.persistServicesAndRejects(serviceDStream)
  }
}
