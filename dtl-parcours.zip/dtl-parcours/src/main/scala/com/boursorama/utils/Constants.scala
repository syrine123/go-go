package com.boursorama.utils

/**
  * Created by ubuntu on 15/05/17.
  */
object Constants {

  val DefaultInt = "-2"
  val sysOrigine = "CRM-WEB-SERVICES"
  val UnknownService = "Unknown Service"
  val ServiceCreateProspect = "monprofil.PROSPECT/CREER_FICHE_PROSPECT"
  val ServiceAmendContactInformation = "monprofil.CONTACT_MANAGEMENT/amendContactInformation"
  val ServiceLinkParrain = "LINK_FILLEUL_PARRAIN"
  val ServiceInitialCustomerValidation = "monprofil.SET_COMMERCIAL_OFFER_CONTACT/INITIAL_CUSTOMER_VALIDATION"
  val ServiceAccountInsuranceSubscribeSfol = "monprofil.ACCOUNT_INSURANCE/SUBSCRIBE_SFOL"
  val ServiceCreateBankCard = "monprofil.BANK_CARD/sfolCreateBankCard"
  val ServiceSfolAddSavingAccount = "monprofil.ACCOUNT_MANAGEMENT/SFOL_ADD_SAVING_ACCOUNT"

}
