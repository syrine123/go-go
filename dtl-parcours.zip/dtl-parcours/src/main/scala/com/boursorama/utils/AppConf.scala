package com.boursorama.utils

import com.typesafe.config.ConfigFactory
import java.io.File

object AppConf extends Serializable {

  val fileInfra = sys.env("BRS_SPARK_ENV_CONF")

  val confInfra = ConfigFactory.parseFile(new File(fileInfra))

  val conf = ConfigFactory.load("application.conf")

  val AppName = conf.getString("AppName")

  val SparkConcurrentJobs = conf.getString("SparkConcurrentJobs")

  val SmtpHost = confInfra.getString("SMTP_HOST")
  val SmtpPort = confInfra.getString("SMTP_PORT")

  val ProxyHttpHost = conf.getString("ProxyHttpHost")
  val ProxyHttpPort = conf.getString("ProxyHttpPort")

  val SparkBatchWindow = conf.getInt("SparkBatchWindow")

  val CassandraReplicationFactor = conf.getInt("CassandraReplicationFactor")
  val CassandraNodes = confInfra.getString("CASSANDRA_SERVERS")
  val CassandraUsername = confInfra.getString("CASSANDRA_LOGIN")
  val CassandraPassword = confInfra.getString("CASSANDRA_PASSWORD")
  val CassandraKeepAliveMs = conf.getString("CassandraKeepAliveMs")

  val EsNodes = confInfra.getString("ES_SERVERS")
  val EsPort = confInfra.getString("ES_PORT")
  val EsUsername = confInfra.getString("ES_LOGIN")
  val EsPassword = confInfra.getString("ES_PASSWORD")

  val CassandraAuditDtlKeySpace = conf.getString("CassandraAuditDtlKeySpace")
  val CassandraParcoursKeySpace = conf.getString("CassandraParcoursKeySpace")

  val zkQuorum = confInfra.getString("ZK_SERVERS")
  val KafkaTopicWebServices = conf.getString("KafkaTopicWebServices")
  val GroupId = conf.getString("GroupId")

  //val connTimeoutMs = conf.getString("connTimeoutMs")
  //val readTimeoutMs = conf.getString("readTimeoutMs")

  // val NbThreadsPerKafkaTopic = conf.getString("NbThreadsPerKafkaTopic")

}