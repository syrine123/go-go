package com.boursorama.utils

import java.util.Date

import org.joda.time.{DateTime, DateTimeZone, LocalDateTime}
import org.joda.time.format.{DateTimeFormat, DateTimeFormatter}
import scala.util.{Failure, Success, Try}

/**
  * Created by fares on 10/05/17.
  */
object Conversion {

  val timestampFormatWithTZ : DateTimeFormatter = DateTimeFormat.forPattern("yyyy-MM-dd'T'HH:mm:ss.SSSZ").withZoneUTC()
  val yearMonthDayFormat : DateTimeFormatter = DateTimeFormat.forPattern("yyyyMMdd").withZoneUTC()
  val timestampFormat : DateTimeFormatter = DateTimeFormat.forPattern("yyyy-MM-dd'T'HH:mm:ss").withZoneUTC()
  val yearMonthFormat : DateTimeFormatter = DateTimeFormat.forPattern("yyyyMM").withZoneUTC()

  def getYearMonthDayWithTZ(timestamp: String): String = {
    yearMonthDayFormat.print(timestampFormatWithTZ.parseDateTime(timestamp))
  }

  def toInt(s: String): Option[Int] = {
    try {
      Some(s.toInt)
    } catch {
      case e: Exception => None
    }
  }

  def toDouble(s: String): Option[Double] = {
    try {
      Some(s.toDouble)
    } catch {
      case e: Exception => None
    }
  }

  def getYearMonth(timestamp: String): Int = {
    yearMonthFormat.print( timestampFormat.parseDateTime(timestamp) ).toInt
  }

  def getYearMonth(date: DateTime): Int = {
    yearMonthFormat.print(date).toInt
  }

  def getYearMonth(date: LocalDateTime): Int = {
    yearMonthFormat.print(date).toInt
  }

  def getYearMonthDay(timestamp: String): Int = {
    yearMonthDayFormat.print(timestampFormatWithTZ.parseDateTime(timestamp)).toInt
  }

  def getYearMonthDay(date: DateTime): Int = {
    yearMonthDayFormat.print(date).toInt
  }

  def getYearMonthDay(date: LocalDateTime): Int = {
    yearMonthDayFormat.print(date).toInt
  }

  protected def now(): DateTime = {
    new DateTime(new Date(), DateTimeZone.UTC)
  }

  def nowToDateTime(): DateTime = {
    now()
  }

  def toLabel(code: String, map: collection.mutable.Map[String, String]): String = {
    var matchCode = Try(Codes(code, map).get)
    var label = ""
    matchCode match {
      case Success(v) => label = v.toString()
      case Failure(e) => label = "Libellé non trouvé"
    }
    label
  }
}
