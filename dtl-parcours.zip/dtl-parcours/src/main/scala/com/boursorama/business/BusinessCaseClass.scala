package com.boursorama.business

import org.joda.time.DateTime
import com.boursorama.utils.Constants._
import com.boursorama.utils.Conversion._

class Service(
  service: String,
  anneeMois: Int
) extends Serializable

case class SfolCreateBankCardDto (
  service: String = ServiceCreateBankCard,
  contactid: String,
  debitCb: String,
  natureCb: String,
  timestamp: String,
  natureCbLabel: String,
  debitCbLabel: String,
  anneeMois: Int,
  idDimTemps: Int
) extends Service(service, anneeMois)

case class LinkFilleulParrainDto (
  service: String = ServiceLinkParrain,
  contactid: String,
  firstnamesponsor: String,
  namesponsor: String,
  timestamp: String,
  anneeMois: Int,
  idDimTemps: Int
) extends Service(service, anneeMois)

case class CreerFicheProspectDto (
  service: String = ServiceCreateProspect,
  contactid: String,
  mailingAccord: String,
  campaign: String,
  civilite: String,
  codePostal: String,
  countryConnexionName: String,
  dateNaissance: String,
  mail: String,
  ip:String,
  //lastName : String,
  pays: String,
  phone: String,
  mobilePhone: String,
  firstname: String,
  timestamp: String,
  codeTypeDemandeWeb: String,
  //TODO : decide which label to use
  campagne: String,//source_url: String,
  city: String,
  addressLine1: String,
  anneeMois: Int,
  idDimTemps: Int
) extends Service(service, anneeMois)

case class AmendContactInformationDto (
  service: String = ServiceAmendContactInformation,
  contactid: String,
  civilite: String,
  connectionCountryName: String,
  csp: String,
  flagEpargne: String,
  ipAdress: String,
  patrimoine: String,
  firstName:String,
  lastName: String,
  timestamp: String,
  revenusAnnuels: String,
  regimeMatrimonial: String,
  flagBanquePrincipale: String,
  cspLabel: String,
  patrimoineLabel: String,
  revenusLabel: String,
  anneeMois: Int,
  codePostalNaissance: String,
  pays_naissance: String
) extends Service(service, anneeMois)

case class InitialCustomerValidationDto (
  service: String = ServiceInitialCustomerValidation,
  contactid: String,
  anneeMois: Int,
  timestamp: String,
  codeOffre: String
) extends Service(service, anneeMois)

case class AccountInsuranceSubscribeSfolDto (
  service: String = ServiceAccountInsuranceSubscribeSfol,
  contactid: String,
  anneeMois: Int,
  timestamp: String,
  prevoyanceFlag: Int
) extends Service(service, anneeMois)

case class SfolAddSavingAccountDto (
  service: String = ServiceSfolAddSavingAccount,
  contactid: String,
  anneeMois: Int,
  timestamp: String,
  cslFlag: Int
) extends Service(service, anneeMois)

case class Rejet (
  log: String,
  service: String,
  sysOrigine: String,
  timestamp: DateTime,
  codeCause: Int,
  cause: String,
  stackTrace: String,
  loginUser: String
) extends Service(service, getYearMonth(timestamp))