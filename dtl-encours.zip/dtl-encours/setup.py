__author__ = 'ubuntu'
import os
from setuptools import setup

def read(fname):
    return open(os.path.join(os.path.dirname(__file__), fname)).read()

setup(
    name = "encours_modules",
    version = "0.3",
    author = "Fares Oueslati",
    author_email = "fares.oueslati@boursorama.fr",
    description = ("Scoring des prospects et stockage en Y "
                   "Indexation du resultat de la retro dans ES"),
    license = "BSD",
    keywords = "encours scoring prospects boursorama",
    url = "http://packages.python.org/",
    packages=['encours_modules'],
    long_description=read('README'),
    classifiers=[
        "License :: OSI Approved :: BSD License",
    ],
    install_requires=[
#       'mock'
	    'scipy',
        'scikit-learn<0.18',
        'elasticsearch',
        'six >=1.6',
        'futures',
        'cassandra-driver>=3.0.8',
        'pandas>=0.11.0',
        'numpy>=1.6.1'
    ],
    #tests_require=['pytest', 'mock'],
    entry_points = {
        'console_scripts': [
            'score-prospects = encours_modules.encours_pipeline:main',
            'retro-boucle = encours_modules.retro:main', 
            'learning = encours_modules.modeling:main'
        ],
    },
)
