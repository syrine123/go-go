__author__ = 'ubuntu'

import pandas as pd

def data_management(merged):
    ### USELESS COLUMNS
    del merged['annee_mois_m_x']
    del merged['annee_mois_x']
    del merged['annee_mois_y']
    del merged['firstnamesponsor']
    del merged['id_dim_temps_x']
    del merged['id_dim_temps_y']
    del merged['id_dim_personne']
    del merged['cible_encours_predit']
    del merged['date_entree_relation']
    del merged['encours']
    del merged['score_prospect_encours']
    del merged['x_mois_anterieurs_cumules']
    del merged['timestamp']
    del merged['service']
    del merged['identifiant_web']
    del merged['delai_transfo']
    ### Get domain from mail
    merged['domain'] = merged['mail'].map(lambda x: x.split("@")[1] if x else None)
    merged['domain'] = merged.domain.str.lower()
    ### Get age from birth date
    get_age(merged)
    ### Clean CB Infos
    merged['debit_cb'] = merged['debit_cb'].replace(np.nan,'-1')
    merged['nature_cb'] = merged['nature_cb'].replace(np.nan,'-1')
    merged['nature_cb'] = pd.to_numeric(merged['nature_cb'])
    merged['debit_cb'] = pd.to_numeric(merged['nature_cb'])
    ### Get flag parrain from namesponsor
    merged['Parrain'] = merged['namesponsor'].map(lambda x : 1 if x else 0 )
    ### Get Sex from Civility
    merged['Sex'] = merged['civilite'].map(get_sex)
    ### Del useless cols
    del merged['civilite']
    del merged['campaign']
    del merged['mail']
    del merged['namesponsor']
    del merged['pays']
    ### transform to numeric when possible
    merged = merged.apply(lambda x: pd.to_numeric(x, errors='ignore'))
    merged = merged.dropna()
    merged.loc[merged['country_connexion_name'].value_counts()[merged['country_connexion_name']].values < 40, 'country_connexion_name'] = 'other'
    merged.loc[merged['domain'].value_counts()[merged['domain']].values < 40, 'domain'] = 'other'
    merged.loc[merged['pays_naissance'].value_counts()[merged['pays_naissance']].values < 40, 'pays_naissance'] = 'other'
    ### Get estimator X & y
    features_df = merged.drop('cible_reelle', axis=1)
    target = merged['cible_reelle']
    return features_df, target


def get_sex(x):
    if x == "0":
        return 1
    elif (x == "1"):
        return 0
    elif (x == "2"):
        return 0
    elif (x == "MR"):
        return 1
    elif (x == "MLE"):
        return 0
    elif (x == "MME"):
        return 0
    else :
        return -1

def get_age(X):
    from datetime import datetime
    now = datetime.now()
    X['AGE'] = X['date_naissance'].dropna()
    X['AGE'] = pd.to_datetime(X['AGE'],errors='coerce')
    X['AGE'] = X['AGE'].map(lambda x : now.year-x.year  if now.month-x.month>0 else now.year - x.year -1 )
    del X['date_naissance']


def get_id_dim_temps_from_timestamp(df):
    df['timestamp'] = pd.to_datetime(df['timestamp'])
    df['id_dim_temps'] = df['timestamp'].apply(lambda x: x.date())
    return df

def get_domain(X):
    X['domain'] = X['mail'].map(lambda x: x.split("@")[1] if x else None)
    X['domain'] = X.domain.str.lower()

def replace_rare_values(X, threshold, replacement_value):
    # Remove items less than or equal to threshold
    for col in X:
        vc = X[col].value_counts()
        vals_to_remove = vc[vc <= threshold].index.values
        X[col].replace(vals_to_remove, replacement_value, inplace=True)

def mesure(table,cible):
    u= cible
    v="proba"
    probabilite="%s_%s" %(u,v)
    table.sort_values(by='probabilite',ascending=True)
    decoup=pd.qcut(table['probabilite'],10,labels=[9,8,7,6,5,4,3,2,1,0])
    U=pd.DataFrame(decoup)
    U.rename(columns={'probabilite':"decile"},inplace=True)
    decile=pd.concat([table,U],axis=1)
    T1=decile[cible].groupby(decile['decile'])
    T2=pd.DataFrame(T1.mean())
    T2.rename(columns={'probabilite':"taux_cible"},inplace=True)
    T2=T2.reset_index()
    result=(T2[T2['decile']==0][cible]/table[cible].mean())
    return result

def proba_reco(table,cible):
    u= cible
    v="proba"
    probabilite="%s_%s" %(u,v)
    table.sort_values(by='probabilite',ascending=True)
    decoup=pd.qcut(table['probabilite'],10,labels=[9,8,7,6,5,4,3,2,1,0])
    U=pd.DataFrame(decoup)
    U.rename(columns={'probabilite':"decile"},inplace=True)
    decile=pd.concat([table,U],axis=1)
    T1=decile['probabilite'].groupby(decile['decile'])
    T2=pd.DataFrame(T1.min())
    T2.rename(columns={'probabilite':"proba_min_decile"},inplace=True)
    T2=T2.reset_index()
    proba=(T2[T2['decile']==0]["proba_min_decile"])
    return proba