# -*- coding: utf-8 -*-
__author__ = 'ubuntu'

import logging
import urllib3
import warnings
# Create the filter.
def should_log(record):
        if ((record.name.startswith("elasticsearch") and record.levelname=='INFO') or (record.name.startswith("py.warnings") and record.levelname=='WARNING')): 
            return False
        return True
    
logging.captureWarnings('warn')    
logging_filter = logging.Filter()
logging_filter.filter = should_log
log = logging.getLogger()
log.setLevel('INFO')
handler = logging.StreamHandler()
handler.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(name)s: %(message)s"))
handler.addFilter(logging_filter)
log.addHandler(handler)
urllib3.disable_warnings()

from cassandra.cluster import Cluster
from cassandra.auth import PlainTextAuthProvider
from encours_modules import config
import pandas as pd

class CassandraClient:

    def __init__(self, keyspace):
        self.auth_provider = None
        self.cluster = None
        self.session = None
        self.keyspace = keyspace
        self.create_session()
        self.prepare_statements()

    def create_session(self):
        self.auth_provider = PlainTextAuthProvider(username=config.cassandra_username, password=config.cassandra_password)
        self.cluster = Cluster(contact_points = [config.cassandra_host], protocol_version=3, auth_provider=self.auth_provider)
        self.session = self.cluster.connect(config.parcours_keyspace)
        
        
    def get_session(self):
        return self.session

    def prepare_statements(self):
        self.statement_get_prospects = self.session.prepare('select * from ' + config.prospect_table + ' WHERE csp>-1 ALLOW FILTERING')
        self.statement_get_insee = self.session.prepare('select * from ' + config.referentiel_keyspace + '.'+ config.insee_table)
        self.statement_get_valo_retro_one_month = self.session.prepare('select * from ' + config.valo_retro_one_month_table)
        self.statement_get_scored_prospects = self.session.prepare('select * from ' + config.score_prospect_encours_table)
        #self.statement_get_valo_retro_one_month_test = self.session.prepare('select * from ' + config.valo_retro_one_month_table_test + ' WHERE id_dim_personne = \'6810864969\' ')
        #+ ' WHERE id_dim_personne=\'6737208161\' ALLOW FILTERING'
        self.statement_truncate_score_prospect = self.session.prepare('TRUNCATE ' + config.score_prospect_encours_table)
        self.statement_insert_six_months_score_encours = self.session.prepare(self.get_statement_insert('six_months'))
        self.statement_insert_one_months_score_encours = self.session.prepare(self.get_statement_insert('one_month'))
        self.statement_insert_one_months_retro = self.session.prepare(self.get_statement_insert('retro_one_month'))
        self.statement_insert_one_months_retro_rejection = self.session.prepare(self.get_statement_insert('retro_one_month_rejection'))

    def get_statement_insert(self, target):
        return {
            'one_month' : 'INSERT INTO ' + config.score_prospect_encours_table + ' (contactid, timestamp, id_dim_temps, cible_encours_un_mois) VALUES (?,?,?,?)',
            'six_months': 'INSERT INTO ' + config.score_prospect_encours_table + ' (contactid, score_prospect_encours_six_mois, timestamp, id_dim_temps, cible_encours_six_mois) VALUES (?,?,?,?,?)',
            'retro_one_month': 'INSERT INTO ' + config.valo_retro_one_month_table + ' (id_dim_personne, annee_mois, annee_mois_m_x, cible_encours_predit,cible_reelle, date_entree_relation, encours, id_dim_temps, identifiant_web, score_prospect_encours,x_mois_anterieurs_cumules) VALUES (?,?,?,?,?,?,?,?,?,?,?)',
            #'retro_one_month_rejection': 'INSERT INTO ' + config.valo_retro_rejection_one_month_table + ' (id_dim_personne, identifiant_web, date_entree_relation, annee_mois, cible, encours, delai_transfo) VALUES (?,?,?,?,?,?,?)',
            'retro_one_month_rejection': 'INSERT INTO ' + config.valo_retro_rejection_one_month_table + ' (id_dim_personne, identifiant_web, date_entree_relation, annee_mois, cible, encours, delai_transfo) VALUES (?,?,?,?,?,?,?)',
        }.get(target, 'Unknown target specified')

    def insert_one_month_retro_rejection(self, data_frame):
        #values = data_frame[["id_dim_personne","identifiant_web","date_entree_relation","annee_mois","cible","encours","delai_transfo"]].values
        data_frame = data_frame.fillna(-1)
        values = data_frame[["id_dim_personne","identifiant_web","date_entree_relation","annee_mois", "cible", "encours","delai_transfo"]].values
        for i in range(data_frame.iloc[0:data_frame["id_dim_personne"].count()].shape[0]):
            #bound_stmt = self.statement_insert_one_months_retro_rejection.bind([values[i,0],values[i,1],values[i,2],values[i,3],values[i,4],values[i,5],values[i,6]])
            bound_stmt = self.statement_insert_one_months_retro_rejection.bind([values[i,0],values[i,1],values[i,2],values[i,3],values[i,4],values[i,5],values[i,6]])
            self.session.execute(bound_stmt)

    def insert_one_month_retro(self, data_frame):
        values = data_frame[["contactid","annee_mois","annee_mois_m-x", "cible_encours_predit", "cible_reelle","date_entree_relation","encours","id_dim_temps","identifiant_web","score_prospect_encours","x_mois_anterieurs_cumules"]].values
        for i in range(data_frame.iloc[0:data_frame["contactid"].count()].shape[0]):
            bound_stmt = self.statement_insert_one_months_retro.bind([values[i,0],values[i,1],values[i,2],values[i,3],values[i,4],values[i,5],values[i,6],values[i,7],values[i,8],values[i,9],values[i,10]])
            self.session.execute(bound_stmt)
            
    def insert_one_month_score_encours(self, data_frame):
        values = data_frame[["contactid","timestamp","id_dim_temps","predicted_target_ENCOURS_1MOIS"]].values
        for i in range(data_frame.iloc[0:data_frame["predicted_target_ENCOURS_1MOIS"].count()].shape[0]):
            bound_stmt = self.statement_insert_one_months_score_encours.bind([values[i,0],values[i,1],values[i,2],values[i,3]])
            self.session.execute(bound_stmt)

    #def insert_one_month_score_encours(self, data_frame):
        #values = data_frame[["contactid","ENCOURS_1MOIS_proba","timestamp","id_dim_temps","predicted_target_ENCOURS_1MOIS"]].values
        #for i in range(data_frame.iloc[0:data_frame["ENCOURS_1MOIS_proba"].count()].shape[0]):
            #bound_stmt = self.statement_insert_one_months_score_encours.bind([values[i,0],values[i,1],values[i,2],values[i,3],values[i,4]])
            #self.session.execute(bound_stmt)

    def insert_six_month_score_encours(self, data_frame):
        values = data_frame[["contactid","ENCOURS_6MOIS_proba","timestamp","id_dim_temps","predicted_target_ENCOURS_6MOIS"]].values
        for i in range(data_frame.iloc[0:data_frame["ENCOURS_6MOIS_proba"].count()].shape[0]):
            bound_stmt = self.statement_insert_six_months_score_encours.bind([values[i,0],values[i,1],values[i,2],values[i,3],values[i,4]])
            self.session.execute(bound_stmt)

    def get_df_from_query(self,prepared_query):
        resultset = self.session.execute(prepared_query)
        resultset[0]
        df = pd.DataFrame()
        for num_col in range(len(resultset.column_names)):
            result_col = []
            for row in resultset:
                result_col.append(row[num_col])
            df[resultset.column_names[num_col]] = result_col
        return df

    def get_df_from_query2(self,prepared_query):
        resultset = self.session.execute(prepared_query)
        resultset[0]
        df = pd.DataFrame()
        for r in resultset:
            df = df.append(r)
        return df

