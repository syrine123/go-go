# -*- coding: utf-8 -*-
__author__ = 'ubuntu'
import logging

from datetime import datetime
from smtp_client import send_mail
import encours_modules.prod_data_management as dm
from encours_modules.cassandra_client import CassandraClient, config
from encours_modules.elasticsearch_client import ElasticsearchClient
import pandas as pd
log = logging.getLogger()

def main():
    begin = datetime.now()
    log.info("lancement Score encours: %s" , begin)

    ### Setting cassandra Keyspace ###
    cc = CassandraClient(config.parcours_keyspace)
    
    ### Get clean rows of propsects ###
    ### TODO : filter prospects based on time window ###
    prospects_ref = cc.get_df_from_query(cc.statement_get_prospects)
    ### Get INSEE indicators ###
    insee_ref = cc.get_df_from_query(cc.statement_get_insee)

    prospects_ref = pd.merge(prospects_ref, insee_ref, on = 'code_postal')
    prospects_ref = prospects_ref.set_index(['contactid'])

    ### Model application ###

    predicted_target = "predicted_target_" + config.one_month_target_name
    
    #one_month_scored_prospects = dm.application(prospects_ref,config.one_month_target_name,config.path_to_one_month_pickle).join(prospects_ref['timestamp'], how='inner')
    #one_month_scored_prospects = dm.application_b20_subscription(prospects_ref, config.one_month_target_name, config.path_to_one_month_pickle_new).join(prospects_ref['timestamp'], how='inner')
    #one_month_scored_prospects = one_month_scored_prospects.join(prospects_ref['annee_mois'], how='inner')
    #one_month_scored_prospects = dm.get_id_dim_temps_from_timestamp(one_month_scored_prospects).reset_index()
    #print(one_month_scored_prospects.head())
    
    six_months_scored_prospects = dm.application_six_months_model(prospects_ref, config.six_months_target_name, config.path_to_six_months_pickle).join(prospects_ref['timestamp'], how='inner')
    six_months_scored_prospects = six_months_scored_prospects.join(prospects_ref['annee_mois'], how='inner')
    six_months_scored_prospects = dm.get_id_dim_temps_from_timestamp(six_months_scored_prospects).reset_index()    

    
    #Classification 1 month without proba
    prospects_ref = dm.data_mngt(prospects_ref)
    one_month_scored_prospects = dm.application(prospects_ref, config.one_month_target_name, config.path_to_one_month_pickle).join(prospects_ref['timestamp'], how='inner')
    one_month_scored_prospects = one_month_scored_prospects.join(prospects_ref['annee_mois'], how='inner')
    one_month_scored_prospects = dm.get_id_dim_temps_from_timestamp(one_month_scored_prospects).reset_index()
    
    del(one_month_scored_prospects['ENCOURS_1MOIS'])
    del(six_months_scored_prospects['ENCOURS_6MOIS'])
    
    log.info('One month scored prospects: %s', one_month_scored_prospects.head())
    log.info('Six month scored prospects: %s', six_months_scored_prospects.head())
    
    ### Truncate score_prospect table ###
    cc.get_session().execute(cc.statement_truncate_score_prospect)

    ### Insert prospects with calculated scores into cassandra ###
    cc.insert_one_month_score_encours(one_month_scored_prospects)
    #cc.insert_six_month_score_encours(six_months_scored_prospects)

    log.info("CASSANDRA INSERT DONE %s")
    
    ### Create ES Instance ###
    es = ElasticsearchClient()
    es.create_session()

    #es.index_purgatory('valorisation-prospect')

    ### Insert prospects with calculated scores into ES ###

    #es.index_table(one_month_scored_prospects, 'valorisation-prospect', 'encours_1mois', 'contactid')
    ### TODO : parse annee_mois field ###

    es.update_index(one_month_scored_prospects, 'idx-valorisation-prospect-', 'valorisation-prospect', 'contactid')
    es.update_index(six_months_scored_prospects, 'idx-valorisation-prospect-', 'valorisation-prospect', 'contactid')
    #es.create_indices()

    end = datetime.now()

    send_mail(end - begin, config.recipient)

    log.info("temps calcul: %s" ,end - begin)

if __name__ == '__main__':
    main()
