# -*- coding: utf-8 -*-
__author__ = 'ubuntu'
import logging
import sys, traceback, threading
import pandas as pd
import numpy as np
from encours_modules.cassandra_client import CassandraClient, config
from encours_modules.elasticsearch_client import ElasticsearchClient
import datetime
log = logging.getLogger()
def main():
    ### Setting cassandra Keyspace ###
    cc = CassandraClient(config.parcours_keyspace)

    ### Get scored prospects in order to check their real scores after the period ###
    scored_prospects = cc.get_df_from_query(cc.statement_get_scored_prospects)
    scored_prospects['contactid'] = pd.to_numeric(scored_prospects['contactid'])

    ### Get clean rows of real client values from today's encours file ###
    #retro_encours_one_month = cc.get_df_from_query(cc.statement_get_valo_retro_one_month)
    today = datetime.date.today()
    verif_encours_df = pd.read_csv('/data/logs/bi_datalake/REF_DTL_VERIF_ENCOURS_' + today.strftime('%Y%m%d') + '.csv', delimiter='|', dtype={'encours': 'float'})
    log.info('PRINT REF_DTL_VERIF_ENCOURS_ %s' + today.strftime('%Y%m%d') + '.csv')
    

    # Renaming columns
    verif_encours_df['cible_reelle'] = verif_encours_df['cible']
    scored_prospects['score_prospect_encours'] = scored_prospects['score_prospect_encours_un_mois'].astype(str)
    scored_prospects['cible_encours_predit'] = scored_prospects['cible_encours_un_mois']
    #print("table datalake", verif_encours_df.head()) 
    #print("table des scores", scored_prospects.head()) 
    
    ### merge scored and real rows ###
    merged_retro = pd.merge(left=scored_prospects[['contactid','cible_encours_predit','id_dim_temps','score_prospect_encours','timestamp']], right=verif_encours_df, how='right', right_on='id_dim_personne', left_on='contactid')
    merged_retro['date_entree_relation'] = pd.to_datetime(merged_retro['date_entree_relation'], format='%Y-%m-%d')
    merged_retro['id_dim_temps'] = merged_retro['id_dim_temps'].dt.strftime('%Y-%m-%d')
    #print ("merged result",merged_retro)

    ### store merged_retro[ pd.isnull(merged_retro.cible_encours_un_mois) ] into table de rejets

    ### get df with not scored clients and not transformed prospects
    score_null_df = merged_retro[pd.isnull(merged_retro.cible_encours_predit)]
    ### persist only not scored clients as rejections

    cc.insert_one_month_retro_rejection(score_null_df[pd.notnull(score_null_df.encours)])
    log.info('Cassandra rejects insert done %s')


### store merged_retro[ pd.isnull(merged_retro.cible_encours_un_mois) == False ] into table de retro and ES
    matched_retro = merged_retro[pd.notnull(merged_retro.cible_encours_predit)]
    
    cc.insert_one_month_retro(matched_retro)
    log.info('Cassandra matchs insert done %s')
    
    #query_score = SimpleStatement( Sql_score ,consistency_level=ConsistencyLevel.QUORUM,fetch_size = 1000)

    #retro_encours_one_month.id_dim_personne = retro_encours_one_month.id_dim_personne.astype(str)
    matched_retro.id_dim_personne = matched_retro.id_dim_personne.astype(str)

    #retro_encours_one_month = retro_encours_one_month.set_index(['id_dim_personne'])

    es = ElasticsearchClient()
    es.create_session()
    
    # ff retro_encours_one_month = retro_encours_one_month[['id_dim_personne','identifiant_web','cible_reelle','cible_encours_predit','date_entree_relation','annee_mois','score_prospect_encours','encours']]
    ## ZZ retro_encours_one_month = matched_retro[['id_dim_personne','identifiant_web','cible_reelle','cible_encours_predit','date_entree_relation','annee_mois','score_prospect_encours','encours']]
    retro_encours_one_month = matched_retro[['id_dim_personne','identifiant_web','cible_reelle','cible_encours_predit','date_entree_relation','date_devenu_client','annee_mois','score_prospect_encours','encours','delai_transfo']]
    retro_encours_one_month = retro_encours_one_month[~np.isnan(retro_encours_one_month.encours)]
    
    # ZZ retro_encours_one_month['timestamp_boucle_retro'] = pd.to_datetime(pd.datetime.now())

    if retro_encours_one_month.empty:
        sys.exit()
    else:
        if len(retro_encours_one_month.annee_mois.astype(str).values[0]) >= 1:
            year_month = retro_encours_one_month.annee_mois.astype(str).values[0]
        else:
            year_month = (datetime.date.today().replace(day=1) ).strftime('%Y%m')
    
        previous_year_month = (datetime.date.today().replace(day=1) - datetime.timedelta(days=1)).strftime('%Y%m')
        print( 'ANNEE MOIS CONCERNES: ' + year_month + ' ' + previous_year_month)
        for col in retro_encours_one_month.columns :
            retro_encours_one_month[col].fillna(-4)#fillna only values from REF_DTL_VERRIF_ENCOURS
        ### TODO : add timestamp field to show lines in ES
        es.update_index_retro(retro_encours_one_month, 'idx-valorisation-prospect-' + year_month, 'valorisation-prospect', 'id_dim_personne')
        es.update_index_retro(retro_encours_one_month, 'idx-valorisation-prospect-' + previous_year_month, 'valorisation-prospect', 'id_dim_personne')
        print('ES update done')
        es.index_table(retro_encours_one_month, 'retro', 'retro', 'id_dim_personne')
        print('ES insert done')
        
        #es.index_table(retro_encours_one_month, 'idx-valorisation-prospect-' + annee_mois, 'valorisation-prospect', 'id_dim_personne')

if __name__ == '__main__':
    main()
