__author__ = 'ubuntu'

import sys
#sys.path.append('/home/foueslat/dtl-pnb/')
import encours_pipeline

def main(args=None):
    """The main routine."""
    if args is None:
        args = sys.argv[1:]

    print("This is the main routine.")
    encours_pipeline.process()

if __name__ == "__main__":
    main()