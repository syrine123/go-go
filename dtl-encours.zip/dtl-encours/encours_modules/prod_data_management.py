__author__ = 'ubuntu'

import pandas as pd
from math import exp, log

### Data management
def data_mngt(df):

    column_list=list(pd.read_csv("VARIABLE.csv",sep=';',encoding="latin-1")['level_1'].values)
    df = pd.DataFrame(df, columns=column_list)

    ### Get flag parrain from namesponsor
    df['Parrain'] = df['namesponsor'].map(lambda x: 0 if pd.isnull(x) else 1).astype(int)
    del df['firstnamesponsor']
    del df['namesponsor']

    ### Get domain from mail
    df['mail'] = df.mail.replace ([np.nan], '')
    df['domain'] = df['mail'].map(lambda x: x.split("@")[1] if x else None)
    df['domain'] = df.domain.str.lower()

    ### Get Sex from Civility
    df['Sexe'] = df['civilite'].map(get_sex)

    ### Delete useless cols
    del df['civilite']
    del df['mail']
    del df['annee_mois']
    del df['mailing_accord']
    del df['id_dim_temps']
    del df['id_dim_personne']
    del df['encours']
    del df['timestamp']
    del df['service']
    del df['campaign']
    del df['pays']
    del df['debit_cb']
    del df['code_postal']
    del df['nature_cb']

    ### Impute empty rows
    df['date_naissance'] = df['date_naissance'].replace('','01/01/1800')
    df = df.replace ([np.nan,None,''], -2)

    ### Get age from birthdate
    get_age(df)

    ### transform to numeric when possible
    df = df.apply(lambda x: pd.to_numeric(x, errors='ignore'))
    
    ### filter the most reccurent ones
    df.loc[df['country_connexion_name'].value_counts()[df['country_connexion_name']].values < 40, 'country_connexion_name'] = 'other'
    df.loc[df['domain'].value_counts()[df['domain']].values < 40, 'domain'] = 'other'
    df.loc[df['pays_naissance'].value_counts()[df['pays_naissance']].values < 40, 'pays_naissance'] = 'other'
    ### Get country connexion name
    df = process_country_connexion(df)
    ### Get pays de naissance
    df = process_pays_naissance(df)
    ### Process the domain
    df = process_domain (df)
    ### Drop NaN
    df = df.replace([np.nan,None,''], -2)

    return df

def application(X,cible,cheminmodel):
    import os
    predicted_target = "predicted_target_" + cible

    if os.path.isdir(cheminmodel):
        os.chdir(cheminmodel)

    ### Load selected Model ###
    import cPickle
    with open("Model_v2.pkl",'rb') as selected_model:
        m = cPickle.load(selected_model)

    ### Applicate Model and store predicted probas in "pred" df ###

    pred = pd.DataFrame(None)

    pred[predicted_target] = m.predict(X)
    pred = pred.apply(lambda x: pd.to_numeric(x, errors='ignore'))
    return pred


def application_six_months_model(X,cible,cheminmodel):

    #*************************** I- chargement des donnees pour datamanagement ******************
    import os
    import numpy as np
    import pandas as pd

    u= cible
    v="proba"
    probabilite = "%s_%s" %(u,v)
    predicted_target = "predicted_target_" + cible

    if os.path.isdir(cheminmodel):
        os.chdir(cheminmodel)

    column_list=list(pd.read_csv("VARIABLE.csv",sep=';',encoding="latin-1")['level_1'].values)
    X=pd.DataFrame(X, columns=column_list)
    X.rename(columns={'LABEL':cible},inplace=True)

    #*************************** II- retaitement manuel de variables ******************


    from datetime import datetime
    X['civilite']=X['civilite'].replace(np.nan,'NR')
    X['code_postal']=X['code_postal'].replace('Vide','-2')
    X['code_postal']=X['code_postal'].replace(np.nan,'-2')

    now=datetime.now()
    X['AGE']=X['date_naissance'].replace(np.nan,'01/01/1800')
    X['AGE']= pd.to_datetime(X['AGE'],errors='coerce')
    X['AGE']=X['AGE'].map(lambda x : now.year-x.year  if now.month-x.month>0 else now.year - x.year -1 )
    del X['date_naissance']

    X['debit_cb']=X['debit_cb'].replace(np.nan,'SANS_CB')
    X['nature_cb']=X['nature_cb'].replace(np.nan,'SANS_CB')

    X['Parrain']=X['firstnamesponsor'].map(lambda x : 0 if x == np.nan else 1 )
    del X['firstnamesponsor']

    X['pays']=X['pays'].replace(np.nan,'NR')
    X['pays_naissance_iso']=X['pays_naissance_iso'].replace(np.nan,'NR')

    nb=-2
    X['regime_matrimonial']=X['regime_matrimonial'].fillna(nb)
    X['patrimoine']=X['patrimoine'].fillna(nb)
    X['revenus_annuels']=X['revenus_annuels'].fillna(nb)

    X.rename(columns={'LABEL':cible},inplace=True)

    ### Get reference score ###
    proba_reco = pd.read_csv(cible + "_reco_proba.csv", sep=';' )

    #*************************** III- transformation de donnees ******************

    #3.1. transformation de coxbox
    columns1 = set(X.columns)
    columns1.remove(cible)
    for col in columns1:
        if os.path.exists(cheminmodel+col+'_param.csv') == True:
            param=float(pd.read_csv(col+'_param.csv',encoding='utf-8',sep=';')['valeur'].values)
            paramprod=float(X[col].min())
            if param>=0 and paramprod>=0:
                lambda_=float(pd.read_csv(col+"_coxbox.csv",sep=';',encoding='utf-8')['valeur'].values)
                if lambda_>= 0.0 and lambda_<= 0.09:
                    X[col]=X[col].map(lambda x : log(x+1))
                else:
                    X[col]=X[col].map(lambda x : ((x+1)**lambda_ -1)/lambda_)
            if param>=0 and paramprod<0:
                lambda_=float(pd.read_csv(col+"_coxbox.csv",sep=';',encoding='utf-8')['valeur'].values)
                if lambda_>= 0.0 and lambda_<= 0.09:
                    X[col]=X[col].map(lambda x : log(x-paramprod+1))
                else:
                    X[col]=X[col].map(lambda x : ((x-paramprod+1)**lambda_ -1)/lambda_)
            if param<0 and paramprod<param:
                lambda_=float(pd.read_csv(col+"_coxbox.csv",sep=';',encoding='utf-8')['valeur'].values)
                if lambda_>= 0.0 and lambda_<= 0.09:
                    X[col]=X[col].map(lambda x : log(x-paramprod+1))
                else:
                    X[col]=X[col].map(lambda x : ((x-paramprod+1)**lambda_ -1)/lambda_)
            if param<0 and paramprod>=param:
                lambda_=float(pd.read_csv(col+"_coxbox.csv",sep=';',encoding='utf-8')['valeur'].values)
                if lambda_>= 0.0 and lambda_<= 0.09:
                    X[col]=X[col].map(lambda x : log(x-param+1))
                else:
                    X[col]=X[col].map(lambda x : ((x-param+1)**lambda_ -1)/lambda_)
        if X[col].dtype == np.dtype('object'):
            regroup=pd.read_csv(col+'.csv',encoding='utf-8',sep=';',names= ['valeur',col,'count'])
            X=X.merge(regroup,on=col, how="left").set_index(X.index)
            del X['count']
            del X[col]
            X.rename(columns={'valeur':col},inplace=True)

    ### Fill na with calculated fit value ###

    columns_list_2 = set(X.columns)
    columns_list_2.remove(cible)
    for col in columns_list_2:
        vide=float(pd.read_csv(col+"_gestiondesvides.csv",sep=';',encoding='utf-8')['valeur'].values)
        X[col]=X[col].fillna(vide)

    y = X[cible]
    del X[cible]
    sorted_columns = list(X.columns)
    sorted_columns.sort()
    X = pd.DataFrame(X, columns = sorted_columns)

    ### Load selected Model ###
    import cPickle
    with open("MODELE.pickle",'rb') as selected_model:
        m = cPickle.load(selected_model)

    ### Applicate Model and store predicted probas in "proba" df ###
    proba = pd.DataFrame(y)
    P = m.predict_proba(X)[:, 1]
    proba[probabilite] = P
    proba[predicted_target] = proba[probabilite].map(lambda x: 1 if x >= float(list(proba_reco.columns.values)[1]) else 0)
   
    return proba

def application_b20_subscription(X,cible,cheminmodel):

    #*************************** I- chargement des donnees pour datamanagement ******************

    import os
    import numpy as np
    import pandas as pd

    u= cible
    v="proba"
    probabilite = "%s_%s" %(u,v)
    predicted_target = "predicted_target_" + cible

    if os.path.isdir(cheminmodel):
        os.chdir(cheminmodel)

    column_list=list(pd.read_csv("VARIABLE.csv",sep=';',encoding="latin-1")['level_1'].values)
    column_list.remove('LABEL')
    print(column_list)
    X=pd.DataFrame(X, columns=column_list)
    #X.rename(columns={'LABEL':cible},inplace=True)

    X['Sexe'] = X['civilite'].map(get_sex)
    X['code_postal']=X['code_postal'].replace(np.nan,'-2')
    X['code_postal_naissance']=X['code_postal_naissance'].replace(np.nan,'-2')
    #X['mailing_accord']=X['mailing_accord'].replace(np.nan,'-2')
    X.code_postal = pd.to_numeric(X.code_postal, errors='coerce')
    X.code_postal_naissance = pd.to_numeric(X.code_postal_naissance, errors='coerce')
    #X.mailing_accord = pd.to_numeric(X.mailing_accord, errors='coerce')
    X['Sexe'] = X['Sexe'].map(lambda x: '-1' if x=='NA' else x)
    X['Sexe'] = pd.to_numeric(X.Sexe, errors='coerce')
    get_age(X)
    #X['domain'] = X['mail'].map(lambda x: x.split("@")[1] if x else None)

    X['Parrain'] = X['namesponsor'].map(lambda x : 1 if x else 0 )
    del X['namesponsor']
    X['pays']=X['pays'].dropna()
    X['pays_naissance']=X['pays_naissance'].dropna()

    nb=-2
    X['regime_matrimonial']=X['regime_matrimonial'].fillna(nb)
    X['patrimoine']=X['patrimoine'].fillna(nb)
    X['revenus_annuels']=X['revenus_annuels'].fillna(nb)

    #X.rename(columns={'LABEL':cible},inplace=True)

    from sklearn import preprocessing
    le = preprocessing.LabelEncoder()
    X['pays'] = le.fit_transform(X['pays'])
    X['pays_naissance'] = le.fit_transform(X['pays_naissance'])
    X = X.dropna()
    #y = X[cible]
    #del X[cible]
    sorted_columns = [
        'AGE',
        'Parrain','campagne',
        'code_postal','code_postal_naissance',
        'csp','flag_banque_principale',
        'patrimoine','pays',
        'pays_naissance','regime_matrimonial',
        'revenus_annuels','Sexe']
    X = pd.DataFrame(X, columns = sorted_columns)

    ### Load selected Model ###
    import cPickle
    with open("MODELE.pickle",'rb') as selected_model:
        m = cPickle.load(selected_model)

    ### Applicate Model and store predicted probas in "proba" df ###
    X[cible] = None
    proba = pd.DataFrame(X[cible])
    del X[cible]

    P = m.predict_proba(X)[:, 1]
    proba[probabilite] = P
    proba[predicted_target] = proba[probabilite].map(lambda x: 1 if x >= 0.43 else 0)
    return proba

def get_sex(x):
    if x == "0":
        return 1
    elif (x == "1"):
        return 0
    elif (x == "2"):
        return 0
    elif (x == "MR"):
        return 1
    elif (x == "MLE"):
        return 0
    elif (x == "MME"):
        return 0
    else :
        return -1

def get_age(X):
    from datetime import datetime
    now = datetime.now()
    X['AGE'] = X['date_naissance'].dropna()
    X['AGE'] = pd.to_datetime(X['AGE'],errors='coerce')
    X['AGE'] = X['AGE'].map(lambda x : now.year-x.year  if now.month-x.month>0 else now.year - x.year -1 )
    del X['date_naissance']


def get_id_dim_temps_from_timestamp(df):
    df['timestamp'] = pd.to_datetime(df['timestamp'])
    df['id_dim_temps'] = df['timestamp'].apply(lambda x: x.date())
    return df

###########################  Adding new version  ##################################
def application_data_mngt(X,cible,cheminmodel):

    #*************************** I- chargement des donnees pour datamanagement ******************   
    
    import os
    predicted_target = "predicted_target_" + cible
    nb=-2
    
    if os.path.isdir(cheminmodel):
        os.chdir(cheminmodel)
       
    column_list=list(pd.read_csv("VARIABLE.csv",sep=';',encoding="latin-1")['level_1'].values)

    #*************************************Merge with INSEE***************************************

    X = pd.DataFrame(X, columns=column_list)

    
#*************************** II- retaitement manuel de variables ******************
    
    X['Sexe'] = X['civilite'].map(get_sex)
    del X['civilite']
    
    get_age(X)
    
    X['Parrain'] = X['namesponsor'].map(lambda x : 1 if x else 0)
    del X['namesponsor']
    
    X['mail'] = X.mail.replace ([np.nan], '')
    X['domain'] = X['mail'].map(lambda x: x.split("@")[1] if x else None)
    X['domain'] = X.domain.str.lower()
    process_domain(X)
    
    X['country_connexion_name'] = X['country_connexion_name'].replace([np.nan,'',None],-2) 
    X.loc[X['country_connexion_name'].value_counts()[X['country_connexion_name']].values < 40, 'country_connexion_name'] = 'other'
    process_country_connexion (X)
    
    X.code_postal = pd.to_numeric(X.code_postal, errors='coerce')
    X.code_postal_naissance = pd.to_numeric(X.code_postal_naissance, errors='coerce')
    X.flag_epargne = pd.to_numeric(X.flag_epargne, errors='coerce')
    
    X['campagne'] = X['campagne'].replace([np.nan,'',None], -2)
    X['code_postal'] = X['code_postal'].replace([np.nan,'',None], -2)
    X['AGE'] = X['AGE'].replace([np.nan,'',None], -2)
    X['domain'] = X['domain'].replace([np.nan,'',None], -2)   
    
    X = X.dropna()

    sorted_columns = [
        'campagne',
        'code_postal_naissance','csp',
        'flag_banque_principale','flag_epargne','patrimoine','regime_matrimonial'
        'revenus_annuels','code_postal',
        'AGE','Parrain','domain','Sexe','country_connexion','salaire_net_horaire_moyen_en_2014_euro'
        ]

    ### Load selected Model ###
    import cPickle
    with open("Model_v2.pkl",'rb') as selected_model:
        m = cPickle.load(selected_model)

    ### Applicate Model and store predicted probas in "pred" df ###
    X[cible] = None
    y = X[cible]
    del X[cible]
    pred = pd.DataFrame(y)

    pred = pd.DataFrame(None)

    pred[predicted_target] = m.predict(X)
    pred = pred.apply(lambda x: pd.to_numeric(x, errors='ignore'))
    return pred, X


def process_country_connexion(df):
    """
    Process country_connexion
    """
    dict_ = {'France':1, 'United Kingdom':2, 'other': 3, 'Germany': 4, 'Switzerland': 5, 'Netherlands': 6, 'Europe': 7, 'United States': 8, 'Reunion': 9, -2: -2}
    df['country_connexion'] = df['country_connexion_name'].map(dict_)
    del df['country_connexion_name']
    return df

def process_pays_naissance(df):
    """
    Process pays naissance
    """
    dict_ = {'FRA':1, 'ITA':2, 'other': 3, 'DZA': 4, 'BEN': 5, 'ESP': 6, 'VNM': 7, 'DEU': 8, 'MAR': 9, 'CIV': 10, 'CMR': 11, 'GTO': 12,
             'SEN': 13,'BEL': 14, 'CHN': 15, 'ROU':16, 'BRA': 17, 'MDG': 18,
             'PRT': 19, 'GBR': 20, 'LBN': 21, 'TUR': 22, 'IND': 23}
    df['pays_de_naissance'] = df['pays_naissance'].map(dict_)
    del df['pays_naissance']
    return df

def process_domain(df):
    """
    Process the domain features
    """
    dict_ = {'yahoo.fr':0, 'hotmail.fr':1, 'hotmail.com': 2, 'gmail.com': 3, 'orange.fr': 4, 'outlook.com': 5, 'free.fr': 6, 'laposte.net': 7, 'other': 8, 'neuf.fr': 9, 'wanadoo.fr': 10, 'me.com': 11, 'ymail.com': 12, 'sfr.fr': 13, 'live.fr': 14, 'bbox.fr': 15, 'outlook.fr': 16, 'msn.com': 17, 'yahoo.com': 18, 'aol.com': 19, 'icloud.com': 20, 'cegetel.net': 21, 'club-internet.fr': 22}
    df['domain'] = df['domain'].map(dict_)
    return df

