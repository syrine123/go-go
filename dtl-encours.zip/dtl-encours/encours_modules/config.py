__author__ = 'ubuntu'

from ConfigParser import SafeConfigParser
import os

# get config parser metadata

parser = SafeConfigParser(os.environ)
parser.read(os.environ['HOME']+'/conf/dtl-encours/default.ini')

print parser.sections()

# Cassandra metadata
cassandra_port = parser.getint("CassandraSection", "cassandra_port")
cassandra_host = parser.get("CassandraSection", "cassandra_host")
cassandra_username = parser.get("CassandraSection", "cassandra_username")
cassandra_password = parser.get("CassandraSection", "cassandra_password")
parcours_keyspace = 'parcours'
referentiel_keyspace = 'ref_data'
prospect_table = 'referentiel_prospects'
insee_table = 'ref_insee'
valo_retro_one_month_table = 'retro_valo_client_un_mois'
valo_retro_one_month_table_test = 'retro_valo_client_un_mois_test'
top_prospect_one_month_table = 'top_prospect_encours_un_mois'
top_prospect_six_months_table = 'top_prospect_encours_six_mois'
score_prospect_encours_table = 'score_prospect_encours'
valo_retro_rejection_one_month_table = 'rejet_retro_valo_client_un_mois'

# Elasticsearch metadata

es_user = parser.get("ElasticsearchSection", "es_login")
es_secret = parser.get("ElasticsearchSection", "es_password")
es_host = parser.get("ElasticsearchSection", "es_host")
es_port = parser.getint("ElasticsearchSection", "es_port")

# Path to pickle one month 'encours' and csv matching files
#path_to_one_month_pickle = "./MODEL/ENCOURS_1MOIS/"
models_path = parser.get("ApplicationSection", "models")
#path_to_one_month_pickle = models_path+"/ENCOURS_1MOIS/"
#path_to_one_month_pickle_new = models_path+"/ENCOURS_1MOIS_NEW/"
path_to_one_month_pickle = models_path+"/ENCOURS_1MOIS_NEW_CLASSIF/"
#path_to_six_months_pickle = "./MODEL/ENCOURS_6MOIS/"
path_to_six_months_pickle = models_path+"/ENCOURS_6MOIS/"

# Path to datalake ref's tables
ref_datalake = parser.get("ReferentialsSection", "path")

# Path to module's parent dir in dev env

# One month model target name
one_month_target_name = 'ENCOURS_1MOIS'
six_months_target_name = 'ENCOURS_6MOIS'

# Mail recipients
recipient = ['fares.oueslati@boursorama.fr']
