__author__ = 'ubuntu'

# Import smtplib for the actual sending function
import smtplib
import config

# Import the email modules we'll need
from email.mime.text import MIMEText

def send_mail(execution_time, recipient):
    # Open a plain text file for reading.  For this example, assume that
    # the text file contains only ASCII characters.

    # Create a text/plain message
    msg = MIMEText('>>> Scoring batch execution time : ' + str(execution_time) + ' <<< ' + '\n'
                   '>>> Cassandra Hostname : ' + str(config.cassandra_host) + ' <<< ' + '\n'
                   '>>> ES Hostname : ' + str(config.es_host) + ' <<< ' + '\n')


    # me == the sender's email address
    # you == the recipient's email address
    #msg['Subject'] = 'The contents of %s' % textfile
    msg['Subject'] = 'Scoring/Storage Prospects Into ES Cassandra TEST MULTIPLE RECEIVERS'
    msg['From'] = 'fares.oueslati@boursorama.fr'
    msg['To'] = 'fares.oueslati@boursorama.fr'

    # Send the message via SMTP server, but don't include the
    # envelope header.
    s = smtplib.SMTP('localhost')
    s.sendmail('fares.oueslati@boursorama.fr', recipient, msg.as_string())
    s.quit()
