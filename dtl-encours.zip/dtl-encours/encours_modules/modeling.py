__author__ = 'ubuntu'

import sys
import encours_modules.prod_data_management as dm
from sklearn.pipeline import Pipeline
from encours_modules.cassandra_client import CassandraClient, config
import cPickle
import pandas as pd

def main():

    ### Setting cassandra Keyspace ###
    cc = CassandraClient(config.parcours_keyspace)
    ### Get clean rows of propsects ###
    prospects_ref = cc.get_df_from_query(cc.statement_get_prospects)
    prospects_ref['contactid'] = pd.to_numeric(prospects_ref['contactid'])
    ### Get clean rows of real prospect values ###
    retro_encours_one_month = cc.get_df_from_query(cc.statement_get_valo_retro_one_month)

    merged = pd.merge(prospects_ref,retro_encours_one_month[['id_dim_personne','encours']], right_on='id_dim_personne', left_on='contactid')
    merged = merged[pd.notnull(merged.encours)]
    merged.code_postal = pd.to_numeric(merged.code_postal)

    ### Get INSEE referential
    insee_ref = cc.get_df_from_query(cc.statement_get_insee)

    merge_2 = pd.merge(merged,insee_ref, on= 'code_postal')
    merge_2 = merge_2.set_index('contactid')

    #Fix encours of good costumers (1200)
    merge_2['cible_seuil_1200'] = merge_2['encours'].map(lambda x: 0 if x < 1200.00 else 1).astype(int)

    y = merge_2['cible_seuil_1200']

    X = dm.data_mngt(merge_2)
    # Modèle : nearest_centroid

    from sklearn.neighbors.nearest_centroid import NearestCentroid
    classifier = NearestCentroid(metric='euclidean', shrink_threshold = 1.5)
    classifier.fit(X,y)

    ## save the model to disk
    import cPickle
    with open(path_to_one_month_pickle + 'Model_v2.pkl', 'wb') as f:
        cPickle.dump(classifier, f)
        
    log.info("Re-learning done %s")   
    
    ''''
    # Sampling
    X0_train,X0_test,y0_train,y0_test=train_test_split(X,y,random_state=42)

    X0_cat_features = X.loc[:, X.dtypes == object]

    # build the pipeline
    pipe = Pipeline([
        ('encoder',  EncodeCategorical(X0_cat_features.keys())),
        ('imputer', DataFrameImputer()),
        ('classifier', RandomForestClassifier(n_estimators=200, n_jobs=-1))
    ])

    # fit the pipeline
    pipe.fit(X0_train, y0_train)

    try:
        parameters = {'n_estimators':[150,300,350], 'n_jobs':[-1]}
        rfc = RandomForestClassifier()
        #m0=grid_search.GridSearchCV(pipe,parameters,cv=6,n_jobs=-1).fit(X0_train,y0_train)
        m0=pipe.fit(X0_train,y0_train)
        proba0=pd.DataFrame(y0_test)
        P = m0.predict_proba(X0_test)[:, 1]
        proba0["probabilite"]= P
        R0=mesure(proba0,'cible_un_mois')
        R0=pd.DataFrame(R0)
        R0.rename(columns={'cible_un_mois':"R0"},inplace=True)
        print(R0)

    except ValueError:
        R0=pd.DataFrame([0],index=[9],columns=["R0"])
        print(R0 , 'ERROR')

    # Export pickle
    with open("delle.pickle",'wb') as f:
        cPickle.dump(m0,f)
    export=proba_reco(proba0,'cible_un_mois')
    print(export)
    export.to_csv("encours_un_mois_reco_proba.csv",sep=';',encoding='utf-8')
    '''''

############################################# II- modelisation: construction du modele  ######################################
def modelisation (X,y,cible,chemin):
    import numpy as np
    import pandas as pd
    import os
    u= cible
    v="proba"
    probabilite="%s_%s" %(u,v)

    #***********************************I-indicateurs de mesure de performence***********************

    def mesure(table,cible):
        import pandas as pd

        u= cible
        v="proba"
        probabilite="%s_%s" %(u,v)
        table.sort_values(by=probabilite,ascending=True)
        decoup=pd.qcut(table[probabilite],10,labels=[9,8,7,6,5,4,3,2,1,0])
        U=pd.DataFrame(decoup)
        U.rename(columns={probabilite:"decile"},inplace=True)
        decile=pd.concat([table,U],axis=1)
        T1=decile[cible].groupby(decile['decile'])
        T2=pd.DataFrame(T1.mean())
        T2.rename(columns={probabilite:"taux_cible"},inplace=True)
        T2=T2.reset_index()
        result=(T2[T2['decile']==0][cible]/table[cible].mean())
        return result

    def proba_reco(table,cible):
        import pandas as pd

        u= cible
        v="proba"
        probabilite="%s_%s" %(u,v)
        table.sort_values(by=probabilite,ascending=True)
        decoup=pd.qcut(table[probabilite],10,labels=[9,8,7,6,5,4,3,2,1,0])
        U=pd.DataFrame(decoup)
        U.rename(columns={probabilite:"decile"},inplace=True)
        decile=pd.concat([table,U],axis=1)
        T1=decile[probabilite].groupby(decile['decile'])
        T2=pd.DataFrame(T1.min())
        T2.rename(columns={probabilite:"proba_min_decile"},inplace=True)
        T2=T2.reset_index()
        proba=(T2[T2['decile']==0]["proba_min_decile"])
        return proba

    #***********************************II-modelisation *****************************************

    #1.0.echantillionnage
    from sklearn.cross_validation import train_test_split
    X0_train,X0_test,y0_train,y0_test=train_test_split(X,y,random_state=42)

    #1.1. modules necessaire

    from sklearn import linear_model
    from sklearn.pipeline import Pipeline
    from sklearn.feature_selection import SelectFromModel
    from sklearn import  grid_search
    from sklearn.ensemble import RandomForestClassifier,ExtraTreesClassifier,GradientBoostingClassifier
    from sklearn.calibration import CalibratedClassifierCV
    #1.2. modele 1
    try:
        parameters = {'n_estimators':[150,300,350], 'n_jobs':[-1]}
        rfc= RandomForestClassifier()
        m0=grid_search.GridSearchCV(rfc,parameters,cv=6,n_jobs=-1)
        m0 = m0.fit(X0_train,y0_train)
        proba0=pd.DataFrame(y0_test)
        P = m0.predict_proba(X0_test)[:, 1]
        proba0[probabilite]= P
        R0=mesure(proba0,cible)
        R0=pd.DataFrame(R0)
        R0.rename(columns={cible:"R0"},inplace=True)
        print(R0)

    except ValueError:
        R0=pd.DataFrame([0],index=[9],columns=["R0"])
        print(R0)

    #1.3. modele 2
    try:
        parameters = {'n_estimators':[300,400], 'n_jobs':[-1]}
        rfc= ExtraTreesClassifier()
        m1=grid_search.GridSearchCV(rfc,parameters,cv=6,n_jobs=-1)
        m1 = m1.fit(X0_train,y0_train)
        proba1=pd.DataFrame(y0_test)
        P = m1.predict_proba(X0_test)[:, 1]
        proba1[probabilite]= P
        R1=mesure(proba1,cible)
        R1=pd.DataFrame(R1)
        R1.rename(columns={cible:"R1"},inplace=True)
        print(R1)

    except ValueError:
        R1=pd.DataFrame([0],index=[9],columns=["R1"])
        print(R1)

    #1.4. modele 3
    try:
        parameters = {'n_estimators':[150,300,350]}
        rfc= GradientBoostingClassifier(max_depth=7)
        m2=grid_search.GridSearchCV(rfc,parameters,cv=6)
        m2 = m2.fit(X0_train,y0_train)
        P=m2.predict(X0_test)
        proba2=pd.DataFrame(y0_test)
        P = m2.predict_proba(X0_test)[:, 1]
        proba2[probabilite]= P
        R2=mesure(proba2,cible)
        R2=pd.DataFrame(R2)
        R2.rename(columns={cible:"R2"},inplace=True)
        print(R2)


    except ValueError:
        R2=pd.DataFrame([0],index=[9],columns=["R2"])
        print(R2)

    #1.5.modele 4
    try:
        rfc= RandomForestClassifier(n_estimators=200, n_jobs=-1)
        logistic = linear_model.LogisticRegression(solver='liblinear',C=100,n_jobs=-1)
        select=SelectFromModel(logistic,threshold="median")
        a0 = CalibratedClassifierCV(rfc, cv=6, method='isotonic')
        m3 = Pipeline(steps=[('feature_selection', select),('regression', a0)])
        m3 = m3.fit(X0_train,y0_train)
        P = m3.predict_proba(X0_test)[:, 1]
        proba3=pd.DataFrame(y0_test)
        proba3[probabilite]= P
        R3=mesure(proba3,cible)
        R3=pd.DataFrame(R3)
        R3.rename(columns={cible:"R3"},inplace=True)
        print(R3)

    except ValueError:
        R3=pd.DataFrame([0],index=[9],columns=["R3"])
        print(R3)

    #1.6.modele 5
    try:
        rfc= GradientBoostingClassifier(n_estimators=200,max_depth=8)
        logistic = linear_model.LogisticRegression(solver='liblinear',C=100,n_jobs=-1)
        select=SelectFromModel(logistic,threshold="median")
        a0 = CalibratedClassifierCV(rfc, cv=6, method='sigmoid')
        m4 = Pipeline(steps=[('feature_selection', select),('regression', a0)])
        m4 = m4.fit(X0_train,y0_train)
        P = m4.predict_proba(X0_test)[:, 1]
        proba4=pd.DataFrame(y0_test)
        proba4[probabilite]= P
        R4=mesure(proba4,cible)
        R4=pd.DataFrame(R4)
        R4.rename(columns={cible:"R4"},inplace=True)
        print(R4)

    except ValueError:
        R4=pd.DataFrame([0],index=[9],columns=["R4"])
        print(R4)

    #1.7.modele 6
    try:
        etc= ExtraTreesClassifier(n_estimators=400,max_depth=10,n_jobs=-1)
        m5=etc.fit(X0_train,y0_train)
        P = m5.predict_proba(X0_test)[:, 1]
        proba5=pd.DataFrame(y0_test)
        proba5[probabilite]= P
        R5=mesure(proba5,cible)
        R5=pd.DataFrame(R5)
        R5.rename(columns={cible:"R5"},inplace=True)
        print(R5)

    except ValueError:
        R5=pd.DataFrame([0],index=[9],columns=["R5"])
        print(R5)

    #1.8.modele 7
    try:
        parameters = {'n_estimators':[200,300], 'max_depth':[10,18],'n_jobs':[-1]}
        rfc= RandomForestClassifier()
        m6=grid_search.GridSearchCV(rfc,parameters,cv=6,n_jobs=-1).fit(X0_train,y0_train)
        proba6=pd.DataFrame(y0_test)
        P = m6.predict_proba(X0_test)[:, 1]
        proba6[probabilite]= P
        R6=mesure(proba6,cible)
        R6=pd.DataFrame(R6)
        R6.rename(columns={cible:"R6"},inplace=True)
        print(R6)

    except ValueError:
        R6=pd.DataFrame([0],index=[9],columns=["R6"])
        print(R6)

    try:
        coef=[0.14,0.14,0.14,0.14,0.14,0.14,0.14]
        proba7=coef[0]*proba0+coef[1]*proba1+coef[2]*proba2+coef[3]*proba3+coef[4]*proba4+coef[5]*proba5+coef[6]*proba6
        R7=mesure(proba7,cible)
        R7=pd.DataFrame(R7)
        R7.rename(columns={cible:"R7"},inplace=True)
        coef2=coef
        coef=pd.DataFrame(coef2,columns=['valeur'])
        coef.to_csv("coefmodel.csv",sep=';',encoding='utf-8')
        print(R7)
    except ValueError:
        R7=pd.DataFrame([0],index=[9],columns=["R7"])
        print(R7)

    try:
        R9=R7
        R9.rename(columns={"R7":"R8"},inplace=True)

        for i in xrange(1,100000):
            li=list(np.random.random(7))
            li=li/sum(li)
            coef=list(li)
            proba8=coef[0]*proba0+coef[1]*proba1+coef[2]*proba2+coef[3]*proba3+coef[4]*proba4+coef[5]*proba5+coef[6]*proba6
            R8=mesure(proba8,cible)
            R8=pd.DataFrame(R8)
            R8.rename(columns={cible:"R8"},inplace=True)
            if float(R8["R8"])>float(R9["R8"]):
                R9=R8
                coef2=coef
        coef=pd.DataFrame(coef2,columns=['valeur'])
        coef.to_csv("coefmodel.csv",sep=';',encoding='utf-8')
        print(R9)
    except ValueError:
        R8=pd.DataFrame([0],index=[9],columns=["R8"])
        print(R8)


    #***********************************III-choix du modele *****************************************
    import cPickle
    plus0="/"
    plus1=cible
    plus2="MOD"
    chemin1=chemin+plus2+plus0+plus1+plus0

    if os.path.isdir(chemin1)==True:
        os.chdir(chemin1)
    else:
        os.makedirs(chemin1)
        os.chdir(chemin1)


    R=pd.concat([R0,R1,R2,R3,R4,R5,R6,R7],axis=1)
    RR=R.T
    RR=pd.DataFrame(RR)
    RR.rename(columns=lambda x: 'valeur',inplace=True)
    RR.sort_values(by='valeur',ascending=False,inplace=True)
    RRR=pd.DataFrame(RR.head(1))
    param=RRR.index


    if param=="R0":
        with open(chemin1+"MODELE.pickle",'wb') as f:
            cPickle.dump(m0,f)
        export=proba_reco(proba0,cible)
        print(export)
        export.to_csv(chemin1+cible+"_reco_proba.csv",sep=';',encoding='utf-8')
    if param=="R1":
        with open(chemin1+"MODELE.pickle",'wb') as f:
            cPickle.dump(m1,f)
        export=proba_reco(proba1,cible)
        print(export)
        export.to_csv(chemin1+cible+"_reco_proba.csv",sep=';',encoding='utf-8')
    if param=="R2":
        with open(chemin1+"MODELE.pickle",'wb') as f:
            cPickle.dump(m2,f)
        export=proba_reco(proba2,cible)
        print(export)
        export.to_csv(chemin1+cible+"_reco_proba.csv",sep=';',encoding='utf-8')

    if param=="R3":
        with open(chemin1+"MODELE.pickle",'wb') as f:
            cPickle.dump(m3,f)
        export=proba_reco(proba3,cible)
        print(export)
        export.to_csv(chemin1+cible+"_reco_proba.csv",sep=';',encoding='utf-8')

    if param=="R4":
        with open(chemin1+"MODELE.pickle",'wb') as f:
            cPickle.dump(m4,f)
        export=proba_reco(proba4,cible)
        print(export)
        export.to_csv(chemin1+cible+"_reco_proba.csv",sep=';',encoding='utf-8')

    if param=="R5":
        with open(chemin1+"MODELE.pickle",'wb') as f:
            cPickle.dump(m5,f)
        export=proba_reco(proba5,cible)
        print(export)
        export.to_csv(chemin1+cible+"_reco_proba.csv",sep=';',encoding='utf-8')

    if param=="R6":
        with open(chemin1+"MODELE.pickle",'wb') as f:
            cPickle.dump(m6,f)
        export=proba_reco(proba6,cible)
        print(export)
        export.to_csv(chemin1+cible+"_reco_proba.csv",sep=';',encoding='utf-8')

    if param=="R7":
        with open(chemin1+"M0.pickle",'wb') as f:
            cPickle.dump(m0,f)
        with open(chemin1+"M1.pickle",'wb') as f:
            cPickle.dump(m1,f)
        with open(chemin1+"M2.pickle",'wb') as f:
            cPickle.dump(m2,f)
        with open(chemin1+"M3.pickle",'wb') as f:
            cPickle.dump(m3,f)
        with open(chemin1+"M4.pickle",'wb') as f:
            cPickle.dump(m4,f)
        with open(chemin1+"M5.pickle",'wb') as f:
            cPickle.dump(m5,f)
        with open(chemin1+"M6.pickle",'wb') as f:
            cPickle.dump(m6,f)
        export=proba_reco(proba7,cible)
        print(export)
        export.to_csv(chemin1+cible+"_reco_proba.csv",sep=';',encoding='utf-8')


    print(param)

if __name__ == '__main__':
    main()
