package com.boursorama.dtl.business.cassandra

import org.joda.time.DateTime
import scala.beans.BeanProperty

/**
 * Created by ubuntu on 12/05/17.
 */
class TelChangesCassDto(
  @BeanProperty var web_id: Long,
  @BeanProperty var contact_id: Long,
  @BeanProperty var timestamp: DateTime,
  @BeanProperty var id_dim_temps: Int,
  @BeanProperty var infos: String,
  @BeanProperty var old_info: String
)