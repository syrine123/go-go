package com.boursorama.dtl.business

import org.joda.time.DateTime

case class EmailChanges(
  webID: Long,
  contactID: Long,
  timestamp: DateTime,
  id_dim_temps: Int,
  infos: String,
  old_info: String

                       )

case class TelChanges(
  webID: Long,
  contactID: Long,
  timestamp: DateTime,
  id_dim_temps: Int,
  infos: String,
  old_info: String
)

case class IbanChanges(
  webID: Long,
  contactID: Long,
  timestamp: DateTime,
  id_dim_temps: Int,
  infos: String
)