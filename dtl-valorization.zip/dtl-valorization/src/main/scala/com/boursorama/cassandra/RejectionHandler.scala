package com.boursorama.cassandra

object RejectionHandler extends Serializable {

  val PARSING_ERROR = 0
  val TYPE_PARSING_ERROR = 1


  val causes = Map[Int, String](
    PARSING_ERROR -> "Erreur de parsing",
    TYPE_PARSING_ERROR -> "Parsing du type provenant de logstash non trouvé")

  def handleRejection(sysOrigine: String, erroCode: Int, stackTrace: String, loginUser: String, log: String): Unit = {
    val errorMess: String = causes.getOrElse(erroCode, "UNKNOWN")
    CassandraClient.writeRejection(sysOrigine, erroCode, errorMess.trim, stackTrace.trim, loginUser, log.trim)
  }
}
