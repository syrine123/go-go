package com.boursorama.cassandra

import com.boursorama.utils.AppConf._
import com.boursorama.utils.Conversion._
import com.datastax.driver.core._
import com.datastax.driver.core.policies.{DefaultRetryPolicy, ExponentialReconnectionPolicy}

object CassandraClient extends Serializable {

  private val auth_provider = new PlainTextAuthProvider(CassandraUsername, CassandraPassword)
  private val nodes = CassandraNodes.split(",").map(_.trim())

  private val cluster = Cluster.builder()
    .addContactPoints(nodes.toArray: _*)
    .withAuthProvider(auth_provider)
    .withQueryOptions(new QueryOptions().setConsistencyLevel(ConsistencyLevel.LOCAL_QUORUM))
    .withRetryPolicy(DefaultRetryPolicy.INSTANCE)
    .withReconnectionPolicy(new ExponentialReconnectionPolicy(100, 60000))
    .withSocketOptions(new SocketOptions().setKeepAlive(true))
    .build()

  private val session = cluster.connect()

  private val statementWriteRejection = session.prepare(s"INSERT INTO $CassandraAuditDtlKeySpace.rejet (sys_origine, timestamp, code_cause, cause, stack_trace, login_user, log) VALUES (?, ?, ?, ?, ?, ?, ?)")
  private val statmentMailClient = session.prepare(s"select email from $CassandraReferentielClientKeySpace.ref_client where id_dim_personne = ?")
  private val statmentTelClient = session.prepare(s"select telephone_portable from $CassandraReferentielClientKeySpace.ref_client where id_dim_personne = ?")
  private val statmentIdDimPerson = session.prepare(s"select id_dim_personne from $CassandraReferentielClientKeySpace.ref_client_contact where identifiant_web = ?")

  def writeRejection(sysOrigine: String, errorCode: Int, errorMess: String, stackTrace: String, loginUser: String, log: String): Unit = {
    session.executeAsync(statementWriteRejection.bind(
      sysOrigine,
      nowToDateTime().toDate,
      errorCode: Integer,
      errorMess,
      stackTrace,
      loginUser,
      log
    ))
  }


  def getMailClient(idContact : Long) : Option[String]= {
    val result = session.execute(statmentMailClient.bind(idContact : java.lang.Long)).all
    if (result.size() > 0) {
      Some(result.get(0).getString("email").replaceAll(" ", ""))
    } else {
      None
    }
  }

  def getTelClient(idContact : Long) : Option[String] = {
    val result = session.execute(statmentTelClient.bind(idContact : java.lang.Long)).all
    if (result.size() > 0) {
      Some(result.get(0).getString("telephone_portable").replaceAll(" ", ""))
    } else {
      None
    }
  }

  def getContactIdClient(idWeb : Long) : Option[Long] = {
    val result = session.execute(statmentIdDimPerson.bind(idWeb : java.lang.Long)).all
    if (result.size() > 0) {
      Some(result.get(0).getLong("id_dim_personne"))
    } else {
      None
    }
  }

}
