package com.boursorama.utils

import com.typesafe.config.ConfigFactory
import java.io.File

object AppConf extends Serializable {

  val fileInfra = sys.env("BRS_SPARK_ENV_CONF")
  
  val confInfra = ConfigFactory.parseFile(new File(fileInfra))
  
  val conf = ConfigFactory.load("application.conf")

  val SparkValorizationCheckpointDirectory = conf.getString("SparkValorizationCheckpointDirectory")

  val SparkConcurrentJobs = conf.getString("SparkConcurrentJobs")

  val ProxyHttpHost = conf.getString("ProxyHttpHost")
  val ProxyHttpPort = conf.getString("ProxyHttpPort")

  val SparkBatchWindow = conf.getInt("SparkBatchWindow")

  val CassandraReplicationFactor = conf.getInt("CassandraReplicationFactor")
  val CassandraNodes = confInfra.getString("CASSANDRA_SERVERS")
  val CassandraUsername = confInfra.getString("CASSANDRA_LOGIN")
  val CassandraPassword = confInfra.getString("CASSANDRA_PASSWORD")
  val CassandraKeepAliveMs = conf.getString("CassandraKeepAliveMs")

  val CassandraReferentielKeySpace = conf.getString("CassandraReferentielKeySpace")
  val CassandraAuditDtlKeySpace = conf.getString("CassandraAuditDtlKeySpace")
  val CassandraReferentielClientKeySpace = conf.getString("CassandraReferentielClientKeySpace")


  val KafkaBroker = confInfra.getString("KAFKA_SERVERS")

  val zkQuorum = confInfra.getString("ZK_SERVERS")

  val KafkaTopicWebService = conf.getString("KafkaTopicWebService")

}
