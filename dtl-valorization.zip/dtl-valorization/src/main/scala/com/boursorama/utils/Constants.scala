package com.boursorama.utils

object Constants {
  val EmptyStringField = "-"
  val EmptyLongField = -1
  val TimeZoneParis = "Europe/Paris"
  val FluxCISE = "CISE"
  val FluxCIS5250 = "CIS5250"
  val FluxAtos = "ATOS"
  val FluxCrm = "CRM"
  val CONSUMER_TREADS_PER_UNPUT_DSTREAM = 8
}
