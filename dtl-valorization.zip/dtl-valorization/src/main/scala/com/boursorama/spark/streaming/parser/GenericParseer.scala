package com.boursorama.spark.streaming.parser

/**
  * Created by ubuntu on 12/05/17.
  */
trait GenericParseer[T] extends Serializable{

  def parseLine(logLine: String): Option[T]

}