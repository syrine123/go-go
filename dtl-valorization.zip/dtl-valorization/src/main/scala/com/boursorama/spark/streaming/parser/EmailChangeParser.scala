package com.boursorama.spark.streaming.parser

import com.boursorama.cassandra.RejectionHandler.PARSING_ERROR
import com.boursorama.dtl.business.EmailChanges
import com.boursorama.spark.persistance.cassandra.CassandraHelper
import com.boursorama.utils.Constants.{EmptyStringField, FluxCrm}
import com.boursorama.utils.Conversion.getYearMonthDay
import org.joda.time.DateTime
import org.json4s.DefaultFormats
import org.json4s.jackson.JsonMethods.parse
/**
  * Created by ubuntu on 12/05/17.
  */
class EmailChangeParser extends GenericParseer[EmailChanges]{

  @transient lazy val logger = org.apache.log4j.LogManager.getLogger("EmailChangeParser")

  override def parseLine(logLine: String): Option[EmailChanges] = {
    try {
          implicit val formats = DefaultFormats

          val filteredServices = List(
            "monprofil.CONTACT_MANAGEMENT/MODIFY_EMAIL",
            "monprofil.CONTACT_MANAGEMENT/MODIFIER_EMAIL"
          )

      val json = parse(logLine)
          val service = (json \ "Service").extractOpt[String].getOrElse(EmptyStringField)
          val rawTimestamp = (json \ "timestamp").extractOpt[String].getOrElse(EmptyStringField)

          if (filteredServices.contains(service)) {
            val timestamp = DateTime.parse(rawTimestamp)
            var webId = (json \ "Login").extractOpt[String].getOrElse("-1")
            var contactID = (json \ "ContactID").extractOpt[String].getOrElse(EmptyStringField)
            val idDimTemps = getYearMonthDay(timestamp)
            val email = (json \ "Email").extractOpt[String].getOrElse(EmptyStringField)

            var contactClient : Long = contactID.toLong


            if(contactID == EmptyStringField){
              contactClient = CassandraHelper.getContactIdClient(webId.toLong).getOrElse(-1)
              contactID = contactClient.toString
            }

            val old_mail = CassandraHelper.getMailClient(contactClient).getOrElse(EmptyStringField)

            Some(
              EmailChanges(
                webId.toLong,
                contactID.toLong,
                timestamp,
                idDimTemps,
                email.replaceAll(" ", ""),
                old_mail
              )
            )

          } else {
            None
          }

    } catch {
      case e : Throwable => {
        //RejectionHandler.handleRejection(FluxCrm, PARSING_ERROR, e.toString + " => " + e.getStackTrace.mkString("||"), EmptyStringField, logLine)
        logger.debug(FluxCrm, PARSING_ERROR, e.toString + " => " + e.getStackTrace.mkString("||"), EmptyStringField, logLine)
        None
      }
    }
  }

}

object EmailChangeParser extends EmailChangeParser