package com.boursorama.spark.streaming.pipeline

import com.boursorama.spark.streaming.parser.{EmailChangeParser, IbanChangeParser, TelChangeParser}
import com.boursorama.dtl.business.{EmailChanges, IbanChanges, TelChanges}
import com.boursorama.utils.AppConf
import org.apache.spark.streaming.dstream.DStream
import org.apache.spark.streaming.StreamingContext

class ValorizationPipeline extends ChangesPipeline {

  def getAppName: String = "sp-strm-valorization"

  def getCheckpointDir: String = AppConf.SparkValorizationCheckpointDirectory

  def getTopicSet: Set[String] = Set(AppConf.KafkaTopicWebService)

  def getGroupId : String = "dtl-valorization"

  def process(ssc: StreamingContext, timeout: Long): Unit = {

    val logDStream: DStream[String] = getInputStream(ssc)

    /*
       Mail changes process
     */
    val mailChangeDStream: DStream[EmailChanges] = parseToMailChange(logDStream)
    processMailChange(mailChangeDStream)

    /*
       Tel changes process
     */
    val telChangeDStream: DStream[TelChanges] = parseToTelChange(logDStream)
    processTelChange(telChangeDStream)

    /*
       Iban changes process
     */
    val ibanChangeDStream: DStream[IbanChanges] = parseToIbanChange(logDStream)
    processIbanChange(ibanChangeDStream)

  }

  def parseToMailChange: String => Option[EmailChanges] = EmailChangeParser.parseLine

  def parseToTelChange: String => Option[TelChanges] = TelChangeParser.parseLine

  def parseToIbanChange: String => Option[IbanChanges] = IbanChangeParser.parseLine

}

object ValorizationPipeline extends ValorizationPipeline
