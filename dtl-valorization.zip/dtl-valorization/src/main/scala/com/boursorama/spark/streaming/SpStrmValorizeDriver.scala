package com.boursorama.spark.streaming

import com.boursorama.spark.streaming.pipeline.ValorizationPipeline

object SpStrmValorizeDriver extends Serializable {

  def main(args: Array[String]) : Unit = {
    ValorizationPipeline.start()
  }
}
