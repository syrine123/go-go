package com.boursorama.spark.streaming.parser

import com.boursorama.cassandra.RejectionHandler.PARSING_ERROR
import com.boursorama.dtl.business.IbanChanges
import com.boursorama.utils.Constants.{EmptyStringField, FluxCrm}
import com.boursorama.utils.Conversion.getYearMonthDay
import org.joda.time.DateTime
import org.json4s.DefaultFormats
import org.json4s.jackson.JsonMethods.parse

/**
  * Created by ubuntu on 12/05/17.
  */
class IbanChangeParser extends GenericParseer[IbanChanges]{

  @transient lazy val logger = org.apache.log4j.LogManager.getLogger("IbanChangeParser")

  override def parseLine(logLine: String): Option[IbanChanges] = {
    try {
      implicit val formats = DefaultFormats

      val filteredServices = List(
        "AJOUTER_BICIBAN_EXTERNE"
      )

      val json = parse(logLine)
      val service = (json \ "Service").extractOpt[String].getOrElse(EmptyStringField)
      val rawTimestamp = (json \ "timestamp").extractOpt[String].getOrElse(EmptyStringField)

      if (filteredServices.contains(service)) {
        val timestamp = DateTime.parse(rawTimestamp)
        var webId = (json \ "Login").extractOpt[String].getOrElse("-1")
        var contactID = (json \ "ContactID").extractOpt[String].getOrElse("-1")
        val idDimTemps = getYearMonthDay(timestamp)
        val iban = (json \ "IBAN").extractOpt[String].getOrElse(EmptyStringField)
        val bic = (json \ "BIC").extractOpt[String].getOrElse(EmptyStringField)

        Some(
          IbanChanges(
            webId.toLong,
            contactID.toLong,
            timestamp,
            idDimTemps,
            iban
          )
        )
      } else {
        None
      }

    } catch {
      case e : Throwable => {
        //RejectionHandler.handleRejection(FluxCrm, PARSING_ERROR, e.toString + " => " + e.getStackTrace.mkString("||"), EmptyStringField, logLine)
        logger.debug(FluxCrm, PARSING_ERROR, e.toString + " => " + e.getStackTrace.mkString("||"), EmptyStringField, logLine)
        None
      }
    }
  }
}

object IbanChangeParser extends IbanChangeParser