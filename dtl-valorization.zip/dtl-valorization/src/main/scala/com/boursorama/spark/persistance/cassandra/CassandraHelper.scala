package com.boursorama.spark.persistance.cassandra

import com.boursorama.cassandra.CassandraClient
import org.apache.spark.streaming.dstream.DStream
import com.boursorama.dtl.business.{EmailChanges, IbanChanges, TelChanges}
import com.boursorama.dtl.business.cassandra.{EmailChangesCassDto, IbanChangesCassDto, TelChangesCassDto}
import com.boursorama.utils.AppConf
import com.datastax.spark.connector.streaming.toDStreamFunctions

object CassandraHelper extends Serializable {

  /*
    Mail changes
   */
  def persisteMailChanges(MailChangesDStream: DStream[EmailChanges]): Unit = {
    MailChangesDStream
      .flatMap(EmailChanges => if (EmailChanges.old_info != EmailChanges.infos) {mapToDto(EmailChanges)} else None)
      .saveToCassandra(AppConf.CassandraReferentielKeySpace, "mail_changes")
  }

  def mapToDto(emailChanges: EmailChanges): Option[EmailChangesCassDto] = {
    try {
      Some(new EmailChangesCassDto(
        emailChanges.webID,
        emailChanges.contactID,
        emailChanges.timestamp,
        emailChanges.id_dim_temps,
        emailChanges.infos,
        emailChanges.old_info
      ))
    } catch {
      case e: java.util.NoSuchElementException =>
        //handleRejection(sortieFond.sys_origine, NONE_VALUE, e.toString + " => " + e.getStackTrace.mkString("||"), EmptyStringField, sortieFond.log)
        // persistence rejection
        None
    }
  }

  /*
    Tel changes
   */
  def persisteTelChanges(TelChangesDStream: DStream[TelChanges]): Unit = {
    TelChangesDStream
      .flatMap(TelChanges => if (TelChanges.old_info != TelChanges.infos) {mapToDto(TelChanges)} else None)
      .saveToCassandra(AppConf.CassandraReferentielKeySpace, "tel_changes")
  }

  def mapToDto(telChanges: TelChanges): Option[TelChangesCassDto] = {
    try {
      Some(new TelChangesCassDto(
        telChanges.webID,
        telChanges.contactID,
        telChanges.timestamp,
        telChanges.id_dim_temps,
        telChanges.infos,
        telChanges.old_info
      ))
    } catch {
      case e: java.util.NoSuchElementException =>
        //handleRejection(sortieFond.sys_origine, NONE_VALUE, e.toString + " => " + e.getStackTrace.mkString("||"), EmptyStringField, sortieFond.log)
        // persistence rejection
        None
    }
  }

  /*
    Iban changes
   */
  def persisteIbanChanges(IbanChangesDStream: DStream[IbanChanges]): Unit = {
    IbanChangesDStream
      .flatMap(IbanChanges => mapToDto(IbanChanges))
      .saveToCassandra(AppConf.CassandraReferentielKeySpace, "iban_changes")
  }

  def mapToDto(ibanChanges: IbanChanges): Option[IbanChangesCassDto] = {
    try {
      Some(new IbanChangesCassDto(
        ibanChanges.webID,
        ibanChanges.contactID,
        ibanChanges.timestamp,
        ibanChanges.id_dim_temps,
        ibanChanges.infos
      ))
    } catch {
      case e: java.util.NoSuchElementException =>
        //handleRejection(sortieFond.sys_origine, NONE_VALUE, e.toString + " => " + e.getStackTrace.mkString("||"), EmptyStringField, sortieFond.log)
        // persistence rejection
        None
    }
  }

  def getMailClient(idContact: Long): Option[String] = {
    CassandraClient.getMailClient(idContact)
  }

  def getTelClient(idContact: Long): Option[String] = {
    CassandraClient.getTelClient(idContact)
  }

  def getContactIdClient(idWeb: Long): Option[Long]= {
    CassandraClient.getContactIdClient(idWeb)
  }

}
