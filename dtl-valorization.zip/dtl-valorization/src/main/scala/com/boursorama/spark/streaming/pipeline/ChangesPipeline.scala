package com.boursorama.spark.streaming.pipeline

import com.boursorama.dtl.business.{EmailChanges, IbanChanges, TelChanges}
import com.boursorama.spark.persistance.cassandra.CassandraHelper
import org.apache.spark.streaming.dstream.DStream

trait ChangesPipeline extends Pipeline {

  /*
    Mail changes
   */
  def processMailChange(mailChangeDStream: DStream[EmailChanges]): Unit = {
    mailChangeDStream.persist(getStorageLevel)
    persisteMailChanges(mailChangeDStream)
  }

  def parseToMailChange(logDStream: DStream[String]): DStream[EmailChanges] = {
    logDStream.flatMap(log => parseToMailChange(log))
  }

  def parseToMailChange: String => Option[EmailChanges]

  def persisteMailChanges(mailChangeDStream: DStream[EmailChanges]): Unit = {
    CassandraHelper.persisteMailChanges(mailChangeDStream)
  }

  /*
    Tel changes
   */
  def processTelChange(telChangeDStream: DStream[TelChanges]): Unit = {
    telChangeDStream.persist(getStorageLevel)
    persisteTelChanges(telChangeDStream)
  }

  def parseToTelChange(logDStream: DStream[String]): DStream[TelChanges] = {
    logDStream.flatMap(log => parseToTelChange(log))
  }

  def parseToTelChange: String => Option[TelChanges]

  def persisteTelChanges(telChangeDStream: DStream[TelChanges]): Unit = {
    CassandraHelper.persisteTelChanges(telChangeDStream)
  }

  /*
    Iban changes
   */
  def processIbanChange(ibanChangeDStream: DStream[IbanChanges]): Unit = {
    ibanChangeDStream.persist(getStorageLevel)
    persisteIbanChanges(ibanChangeDStream)
  }

  def parseToIbanChange(logDStream: DStream[String]): DStream[IbanChanges] = {
    logDStream.flatMap(log => parseToIbanChange(log))
  }

  def parseToIbanChange: String => Option[IbanChanges]

  def persisteIbanChanges(ibanChangeDStream: DStream[IbanChanges]): Unit = {
    CassandraHelper.persisteIbanChanges(ibanChangeDStream)
  }

}
